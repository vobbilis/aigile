# Model Routing Ledger — cross-build learning for v4 dynamic routing

The write side of the /plan_to_build_v4 ↔ /build_v4 learning loop.

- **Read** by `/plan_to_build_v4` Phase A step 4a: apply entries whose
  "apply when:" condition matches the new spec's task shapes; cite the RL-NNN
  IDs in the spec's `### Prior-lesson adjustments`.
- **Written** by `/build_v4`'s spec-updater (Wave 2), transcribing the lead's
  post-build assessment: initial class per agent → what the build actually
  showed → verdict → lesson.
- **Append-only.** Never edit or delete prior entries; a lesson that later
  proves wrong gets a NEW entry superseding it by ID ("supersedes RL-NNN").
- Verdicts: `RIGHT` (class matched the work), `OVER-PROVISIONED` (a cheaper
  class would have done it — evidence: zero fix cycles, trivial diffs),
  `UNDER-PROVISIONED` (the class was too weak — evidence: capability-caused
  fix cycles, stalls, off-spec output).
- Every lesson MUST carry an `apply when:` condition concrete enough for a
  planner to match against task shapes. "Be careful with deepseek" is not a
  lesson; "apply when: a MECHANICAL task requires >10 sequential tool calls —
  observed the translation-shim model losing the thread past that" is.
- **Every entry MUST carry a `binding:` line** — the slot→physical-model
  mapping VERIFIED FROM TEAMMATE TRANSCRIPTS at build time (not from env
  vars; RL-001 records why). Lessons are keyed to their binding: a planner
  applies a lesson only when the target session's expected binding matches.
  Capability verdicts do not transfer across physical models.

## Entry format

```md
### RL-NNN <YYYY-MM-DD> <repo>/<specs/file-v4.md>
- binding: <slot→physical model, transcript-verified>
- <agent>: <class> → <verdict> — <one-line evidence>
- Lesson: <what to do differently> (apply when: <matchable condition>)
```

## Entries

### RL-001 2026-09-04 routing-cal/specs/routing-cal-m0-v4.md
- binding: opus→claude-opus-5, sonnet→claude-sonnet-4-5, haiku→claude-haiku-4-5 (stock harness slots; announced claude-multi shim binding fable/deepseek was NOT in effect — teammates do not inherit launcher env)
- builder-p1: REASONING → RIGHT — zero fix cycles WITH visible design judgment (probe hypothesis "RIGHT" confirmed)
- builder-p2: MECHANICAL → RIGHT — one-pass byte-exact transcription on claude-haiku-4-5 (probe hypothesis "RIGHT" confirmed)
- builder-p3: REASONING → OVER-PROVISIONED — byte-specified transcription; expensive slot added zero quality delta (deliberate miscalibration probe; hypothesis confirmed)
- builder-p4: MECHANICAL → RIGHT — hypothesis "UNDER-PROVISIONED" FALSIFIED; claude-haiku-4-5 cleared design judgment + long chain in one pass
- Lesson: byte-specified content with a drift-catching test is MECHANICAL regardless of file type (apply when: task body contains the full literal content AND a test/byte-compare catches any wrong byte)
- Lesson: the MECHANICAL rubric's ~10-call/zero-judgment ceiling is conservative for claude-haiku-4-5 (apply when: haiku slot = claude-haiku-4-5, single-file task, locked types/semantics, ≤5 named tests — cheap slot suffices; re-test before applying to shim-backed bindings)
- Lesson: verify teammates' PHYSICAL model from their session transcripts before trusting announced routing (apply when: any /build_v4 run under a shim launcher — grep '"model":' in the teammate .jsonl under ~/.claude/projects/)
