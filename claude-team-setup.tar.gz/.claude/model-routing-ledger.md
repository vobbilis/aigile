# Model Routing Ledger — cross-build learning for v4 dynamic routing

The write side of the /plan_to_build_v4 ↔ /build_v4 learning loop.

- **Read** by `/plan_to_build_v4` Phase A step 4a: apply entries whose
  "apply when:" condition matches the new spec's task shapes; cite the RL-NNN
  IDs in the spec's `### Prior-lesson adjustments`.
- **Written** by `/build_v4`'s spec-updater (Wave 2), transcribing the lead's
  post-build assessment: initial class per agent → what the build actually
  showed → verdict → lesson.
- **Append-only.** Never edit or delete prior entries; a lesson that later
  proves wrong gets a NEW entry superseding it by ID ("supersedes RL-NNN").
- Verdicts: `RIGHT` (class matched the work), `OVER-PROVISIONED` (a cheaper
  class would have done it — evidence: zero fix cycles, trivial diffs),
  `UNDER-PROVISIONED` (the class was too weak — evidence: capability-caused
  fix cycles, stalls, off-spec output).
- Every lesson MUST carry an `apply when:` condition concrete enough for a
  planner to match against task shapes. "Be careful with deepseek" is not a
  lesson; "apply when: a MECHANICAL task requires >10 sequential tool calls —
  observed the translation-shim model losing the thread past that" is.
- **Every entry MUST carry a `binding:` line** — the slot→physical-model
  mapping VERIFIED FROM TEAMMATE TRANSCRIPTS at build time (not from env
  vars; RL-001 records why). Lessons are keyed to their binding: a planner
  applies a lesson only when the target session's expected binding matches.
  Capability verdicts do not transfer across physical models.

## Entry format

```md
### RL-NNN <YYYY-MM-DD> <repo>/<specs/file-v4.md>
- binding: <slot→physical model, transcript-verified>
- <agent>: <class> → <verdict> — <one-line evidence>
- Lesson: <what to do differently> (apply when: <matchable condition>)
```

## Entries

### RL-001 2026-09-04 routing-cal/specs/routing-cal-m0-v4.md
- binding: opus→claude-opus-5, sonnet→claude-sonnet-4-5, haiku→claude-haiku-4-5 (stock harness slots; announced claude-multi shim binding fable/deepseek was NOT in effect — teammates do not inherit launcher env)
- builder-p1: REASONING → RIGHT — zero fix cycles WITH visible design judgment (probe hypothesis "RIGHT" confirmed)
- builder-p2: MECHANICAL → RIGHT — one-pass byte-exact transcription on claude-haiku-4-5 (probe hypothesis "RIGHT" confirmed)
- builder-p3: REASONING → OVER-PROVISIONED — byte-specified transcription; expensive slot added zero quality delta (deliberate miscalibration probe; hypothesis confirmed)
- builder-p4: MECHANICAL → RIGHT — hypothesis "UNDER-PROVISIONED" FALSIFIED; claude-haiku-4-5 cleared design judgment + long chain in one pass
- Lesson: byte-specified content with a drift-catching test is MECHANICAL regardless of file type (apply when: task body contains the full literal content AND a test/byte-compare catches any wrong byte)
- Lesson: the MECHANICAL rubric's ~10-call/zero-judgment ceiling is conservative for claude-haiku-4-5 (apply when: haiku slot = claude-haiku-4-5, single-file task, locked types/semantics, ≤5 named tests — cheap slot suffices; re-test before applying to shim-backed bindings)
- Lesson: verify teammates' PHYSICAL model from their session transcripts before trusting announced routing (apply when: any /build_v4 run under a shim launcher — grep '"model":' in the teammate .jsonl under ~/.claude/projects/)

### RL-002 2026-09-18 metrics-dashboard/specs/metric-units-v4.md
- binding: opus→claude-opus-5, sonnet→claude-sonnet-4-5-20250929, haiku→anthropic.claude-haiku-4-5 (transcript-verified from teammate .jsonl; haiku leg served via Bedrock-form model id). DEGRADED run: no tmux/task-board — direct Agent dispatch, task identity preserved.
- builder-1: MECHANICAL → RIGHT — two byte-specified tasks (5 production lines + 10 test-assertion edits) transcribed with zero drift, both validations first-pass on claude-haiku-4-5
- builder-2: STANDARD → RIGHT — 17 tests correct and red-verified first pass; BUT 6 ruff E501s in docstrings cost one fix cycle (style discipline, not capability)
- validator: STANDARD → NO VERDICT — agent stalled 30 min with no output and was killed; lead ran the 4 commands directly in ~10s. Orchestration failure, not a class failure.
- Lesson: a completion report only proves the gates it is forced to quote — require the last line of EVERY validation command (incl. lint) pasted verbatim in the report (apply when: any builder task whose validation command chains pytest AND a linter — observed the linter leg silently skipped)
- Lesson: for validators whose whole job is running listed commands, set a hard wall-clock budget and make the lead's escalation "kill + run the commands yourself", not ping-and-wait (apply when: validate-all is pure command execution with no investigation component)
- Lesson: teammates inherit neither env NOR cwd — panes open at $HOME; standing orders must mandate absolute paths for every file operation (apply when: any dispatch prompt that names files — extends RL-001's env lesson to the working directory)

### RL-003 2026-09-18 metrics-dashboard/specs/metric-units-r2-v4.md (delta re-build)
- binding: same session as RL-002 (opus→claude-opus-5, sonnet→claude-sonnet-4-5-20250929, haiku→claude-haiku-4-5, transcript-verified there)
- builder-1: MECHANICAL → RIGHT — 1-token AMENDED change first-pass, and executed validation-first claiming correctly on the UNCHANGED task (ran the validation command before any work, 114 green, skipped with quoted evidence)
- builder-2: STANDARD → RIGHT — amended 2 boundary tests and reasoned correctly about partial red (reported the test that could not go red for this delta instead of forcing it)
- validator: lead-run per RL-002's lesson — ~10s, zero stall, zero agents
- Lesson: an UNCHANGED task whose validation command is the FULL suite makes the skip decision depend on every other task's state, not its own; scope validation commands to the task's own surface so validation-first claiming stays precise (apply when: authoring `## Validation command` for tasks that may be UNCHANGED in a future re-plan)

### RL-004 2026-09-27 buildv4-spin/specs/spin-M0-v4.md
- binding: opus→claude-opus-5-5, sonnet→claude-sonnet-4-5-20250929, haiku→anthropic.claude-haiku-4-5-20251001-v1:0 (transcript-verified: 9c2 probes + 15b first-report checks)
- builder-budget: REASONING → RIGHT — 7/7 tests first-pass with exact messages/attributes/post-failure state verified via subTest; independently diagnosed broken baseline ruff.toml, proved code clean with --isolated run, stayed in scope, escalated fix. Zero fix cycles.
- builder-report: MECHANICAL → RIGHT (capability), with scope-discipline defect — report-render + report-tests first-pass byte-exact zero fix cycles, but made UNAUTHORIZED out-of-scope ruff.toml edit without asking (wrong intermediate attempt before right one, disclosed post-fact, paraphrased gates instead of quoting verbatim).
- validator: STANDARD → RIGHT, possibly OVER-PROVISIONED — PASSED in ~3 min with full AC table + Type Surface checks + repo config confirmation; pure command execution no judgment beyond confirming known deviation.
- spec-updater: MECHANICAL → scored by lead post-completion (on-disk Status flip + evidence check)
- Lesson: environment-blocked gates are where REASONING pays off even on small specs (apply when: a task's validation gate depends on repo config/tooling the spec asserted but never executed at baseline)
- Lesson: MECHANICAL/haiku dispatches must carry explicit "modify only the listed files; report blockers, do not fix them" rule (apply when: MECHANICAL/haiku builder AND its validation command touches shared repo config/tooling — observed unauthorized out-of-scope fix to unblock its gate)
- Lesson: validator stall (RL-002) did not recur with hard report clock; MECHANICAL trial for pure-command-execution validate-all may be cheaper (apply when: validate-all is pure command execution with no investigation — keep 10-min clock and consider trialling MECHANICAL on it)
- Lesson: plan-level — specs must execute their baseline validation commands during planning (apply when: /plan_to_build_v4 grounds a spec whose validation commands invoke in-repo linter/tool config — observed broken ruff.toml config that parses doesn't parse slipped through baseline, breaking every lint gate on arrival)

### RL-005 2026-09-27 buildv4-spin/specs/spin-M0-v4.md (correction to RL-004 — append-only)
- binding: same run as RL-004 (no new build)
- spec-updater: MECHANICAL → RIGHT — Status flipped to COMPLETE and Build Evidence written; lead verified on disk. ~12 min wall-clock was PreToolUse hook latency, not model capability.
- Correction: RL-004's plan-level lesson attributes the broken ruff.toml to /plan_to_build_v4. The spin-M0 spec and ruff.toml were HAND-WRITTEN by the assistant for the spin test; /plan_to_build_v4 did not run. The lesson stands, re-scoped: a spec's baseline validation commands must be executed before build (apply when: ANY spec — planner-produced or hand-written — whose validation commands invoke in-repo linter/tool config).
