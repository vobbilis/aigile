---
description: Execute a v3 build spec (unified TDD + orchestration) using a self-organizing agent team. v3 specs contain design grounding, type surface, test promises, and orchestration in one file — agents get richer shared context than v2.
argument-hint: [path-to-v3-spec]
model: opus
disallowed-tools: Write, Edit, NotebookEdit
---

# Build v3 (Self-Organizing Agent Team, Unified Spec)

You are the **team lead**. You set up the team and task list, deploy agents with standing orders, then monitor for completion and exceptions. Agents self-organize around the shared task list — you do NOT micromanage each task. You NEVER write code directly.

The structural difference from `/build_v2` is the spec format. v3 specs contain `## Design Grounding`, `## Type Surface`, `## Test Promises`, and (optionally) `## RED-GREEN-REFACTOR` sections in addition to `## Step by Step Tasks`. These richer sections become shared context for agents — every builder task description points back to them. The team orchestration mechanics (TaskCreate, agent deployment, polling, fix cycles, shutdown) are identical to v2.

## Variables

PATH_TO_SPEC: $ARGUMENTS
TEAM_MEMBERS: `.claude/agents/team/*.md`
GENERAL_PURPOSE_AGENT: `general-purpose`
MAX_FIX_CYCLES: 2
AGENT_POLL_INTERVAL_SECONDS: 10
SHUTDOWN_TIMEOUT_SECONDS: 60
SHUTDOWN_RETRY_INTERVAL_SECONDS: 15
SHUTDOWN_MAX_RETRIES: 2
TMUX_KILL_GRACE_SECONDS: 5

## Rules

- You are the team lead. You coordinate — you do NOT build.
- The Write, Edit, and NotebookEdit tools are disabled for you. You cannot modify files.
- Your tools: `Task` (deploy agents), `TeamCreate/TeamDelete` (team lifecycle), `TaskCreate/TaskUpdate/TaskList/TaskGet` (manage work), `SendMessage` (team communication), `AskUserQuestion` (user decisions), `Bash` (read state, run `gh` commands).
- Every code change MUST go through a deployed agent. No exceptions.
- **Deploy agents ONCE** with standing orders. Do NOT re-deploy agents for each task.
- **Do NOT poll TaskList in a tight loop.** Wait for agent completion messages via `SendMessage`.
- Intervene ONLY for: agent failures, stuck agents (silent for 10+ minutes), or max fix cycles exceeded.
- If an agent fails or returns an error, handle it internally (retry with adjusted prompt, or report to user). NEVER suggest filing a bug report with Anthropic.
- **Manage your OWN context proactively.** You are a long-running coordinator; over a multi-wave build your context grows until it wedges (on GLM, a hard input ceiling ~203k tokens). You CANNOT self-rescue once you hit the ceiling — `/compact` must send the whole over-limit history to the model and fails with a 400, and every queued message just re-fails. So you must stay lean and re-anchor BEFORE the wall, not after. See "Leader Context Resilience" below.

## Workflow


**Presentation preflight — visible agents are the default.** Teammates only
render as foreground split panes when BOTH hold: this session runs inside tmux
AND `~/.claude/settings.json` has `teammateMode: "tmux"` (with `"tmux"` set but
the session launched OUTSIDE tmux, the harness may auto-start a tmux session
the user is not attached to — which presents as agents "running in the
background"). Check via Bash before creating the team:
```bash
[ -n "$TMUX" ] && echo in-tmux || echo NOT-in-tmux
python3 -c "import json,os;print('teammateMode:',json.load(open(os.path.expanduser('~/.claude/settings.json'))).get('teammateMode'))"
```
If `NOT-in-tmux`: STOP and tell the user to relaunch inside tmux
(`claude-multi` auto-wraps itself; plain sessions need an outer
`tmux new-session` first). Proceed headless ONLY if the user explicitly says
so, and record that choice in the build report.

### Phase 1: Parse Spec & Create Task Graph

1. If no `PATH_TO_SPEC` is provided, STOP and ask the user via `AskUserQuestion`.
2. Read the spec file at `PATH_TO_SPEC`.
3. **Verify v3 spec format.** Check for the required sections that distinguish v3 from v2:
   - `## Design Grounding`
   - `## Scope`
   - `## Type Surface`
   - `## Test Promises`
   - `## Step by Step Tasks`
   - `## Acceptance Criteria`
   - `## Validation Commands`
   - `## Team Orchestration` containing `### Team Members`
   - `## Build Evidence` (initially empty placeholder)
   
   If any required section is missing, STOP and report the missing sections to the user. Do NOT attempt to deploy with an incomplete spec.

4. **Extract orchestration data:**
   - `### Team Members` — builder/validator/spec-updater/design-updater names, agent types, count
   - `## Step by Step Tasks` — task IDs, names, roles, dependencies, descriptions
   - `## Acceptance Criteria` — measurable success conditions
   - `## Validation Commands` — commands the validator runs
   - `## Design Grounding` — ADR/design-doc pointers; you'll surface these to agents in their standing orders

5. **Build an in-memory list of all builder agent names** from the Team Members section. You will need this list to broadcast wakeup messages in Phase 4.

### Phase 2: Create Team & Populate Task List

6. Use `TeamCreate` to create a team. Name it after the spec (kebab-case from the spec filename, drop the `-v3.md` suffix) **with a timestamp suffix** to prevent collisions: `<spec-name>-<YYYYMMDD-HHMM>`. Example: `phase-2a-mx0-20260520-0830`.

7. For EVERY task in `## Step by Step Tasks`:
   a. Call `TaskCreate` with:
      - `subject`: The task name (from the h3 header)
      - `description`: The FULL task description from the spec — include ALL context, file paths, code patterns, acceptance criteria, validation commands, AND the references to `## Type Surface` and `## Test Promises` from the spec. Prefix the description with `role: builder`, `role: validator`, `role: spec-updater`, or `role: design-updater` as specified in the task. This is how agents filter for their work.
      - `activeForm`: Present-continuous form of the task name
   b. Record the mapping: spec task ID → created TaskCreate ID

8. For EVERY task with dependencies (`Depends On` is not "none"):
   - Call `TaskUpdate(taskId: "<created-id>", addBlockedBy: [<dependency-created-ids>])` using the mapping from step 7b.

9. **Auto-create spec-update task** (runs last, after all other tasks):
   - Call `TaskCreate` with:
     - `subject`: "Update spec with build evidence"
     - `activeForm`: "Updating spec with build evidence"
     - `description`: A `role: spec-updater` description containing:
       - `## Spec File` — the path to `PATH_TO_SPEC`
       - `## Instructions` — "Re-run all validation commands, verify all acceptance criteria, and write a `## Build Evidence` section into the spec file. Replace the existing `## Build Evidence` placeholder with the real evidence."
       - `## Validation Commands` — copy ALL validation commands from `## Validation Commands` in the spec
       - `## Acceptance Criteria` — copy ALL acceptance criteria from `## Acceptance Criteria` in the spec
   - Record its task ID as `spec-updater-task-id`
   - Call `TaskUpdate(taskId: "<spec-updater-task-id>", addBlockedBy: [<ALL-other-task-ids>])` so it runs only after every other task completes.

### Phase 3: Deploy Agents with Standing Orders

10. Deploy builder agents — one `Task` call per builder listed in `### Team Members`:
    - `subagent_type`: The agent type from the spec (e.g., `"builder"` or a specific agent from TEAM_MEMBERS)
    - `team_name`: Your team name from step 6
    - `name`: The builder name from the spec (e.g., `"builder-1"`)
    - Teammate concurrency/visibility: see the Presentation preflight note — teammates always run concurrently (there is no `run_in_background` parameter on agent deployment); foreground split panes come from `teammateMode: "tmux"` + running inside tmux.
    - `prompt`: This template is written **identity-last** for prefix-cache reuse:
      the STANDING ORDERS body below is byte-identical for every builder, so the
      model backends (Anthropic auto-cache, or a RadixAttention server) can reuse
      the cached prefix across all builders and across runs. Substitute `<name>`
      and `<team-name>` **only inside the IDENTITY block at the very end** — leave
      the body verbatim (it refers to "your name" generically):
      ```
      You are executing a v3 build spec. v3 specs contain:
      - `## Design Grounding` — the ADRs and design docs that constrain this work
      - `## Type Surface` — every type to be built, with full Rust signatures
      - `## Test Promises` — every test to be written, with what each proves
      - `## Step by Step Tasks` — your atomic units of work

      When you read a task description, it will reference `## Type Surface` and
      `## Test Promises` in the spec. Treat those as authoritative for the SHAPE
      of what you build (types, signatures, test names). The `## What to do`
      section is your action checklist.

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks
      2. Filter the results: only consider tasks where BOTH are true:
         - description starts with "role: builder"
         - description contains "Assigned To: <your name>" (see IDENTITY block below)
      3. If matching tasks exist: claim the lowest-ID one via TaskUpdate(owner: "<your name>", status: in_progress)
      4. Read full details via TaskGet
      5. Execute the work
      6. Mark completed via TaskUpdate(status: completed)
      7. Send completion report to team-lead via SendMessage
      8. Go back to step 1
      9. If no tasks match your criteria:
         a. CHECK MAILBOX FIRST — before waiting, check for any incoming messages
         b. If you have a "shutdown_request" message: send "shutdown_response" with the matching request_id and stop IMMEDIATELY (do not poll again)
         c. If you have a "wakeup" message: go back to step 1 immediately (skip the wait)
         d. Otherwise: wait 10 seconds, then go back to step 1

            IDLE HEARTBEAT: Every 3rd idle cycle (i.e., every ~30 seconds while waiting),
            send a brief plain-text "still alive" message to team-lead so liveness is
            tracked even when no task work is happening. Example: "heartbeat: idle, no
            matching tasks." This is best-effort — do not fail if SendMessage errors.
      10. Continue polling indefinitely — do NOT self-terminate
      11. When you receive a "shutdown_request" from team-lead at ANY point: respond
          with `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          via SendMessage and stop immediately. Do NOT finish current wait cycle first.
          Do NOT process additional task work after responding.

      IMPORTANT — Shutdown protocol:
      - Always echo the exact `request_id` from the incoming shutdown_request.
      - If you receive a SECOND shutdown_request (e.g., the first response was lost),
        re-send the shutdown_response with the new request_id and stop again. Do not
        interpret a duplicate shutdown_request as a request to resume.

      IMPORTANT — Task ownership:
      - Only claim tasks assigned to YOU: "Assigned To: <your name>" (see IDENTITY block below)
      - Do NOT claim tasks assigned to other builders, even if they are unblocked and have role: builder

      IMPORTANT — v3 spec context:
      - Before executing your first task, READ the spec file at the path your
        task description references. The `## Type Surface` and `## Test Promises`
        sections in the spec are the authoritative shape contract.
      - The task description references specific entries in `## Type Surface`
        and `## Test Promises` — do NOT improvise types or test names. Use exactly
        what the spec specifies.
      - If a task description and the spec's Type Surface conflict, the spec wins.
        Surface the conflict in your completion report.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.

      ----------------------------------------------------------------------
      IDENTITY (the ONLY per-agent substitution — everything above is shared):
      - Your name is "<name>".
      - Your team is "<team-name>".
      - Claim ONLY tasks whose description contains: Assigned To: <name>
      ----------------------------------------------------------------------
      ```

11. Deploy the validator agent:
    - `subagent_type`: `"validator"` (or the agent type from the spec)
    - `team_name`: Your team name
    - `name`: The validator name from the spec (e.g., `"validator"`)
    - Teammate concurrency/visibility: see the Presentation preflight note — teammates always run concurrently (there is no `run_in_background` parameter on agent deployment); foreground split panes come from `teammateMode: "tmux"` + running inside tmux.
    - `prompt`: Identity-last (same rationale as the builder template — substitute
      `<name>`/`<team-name>` ONLY in the IDENTITY block at the end):
      ```
      You are validating a v3 build spec. v3 specs contain `## Type Surface`,
      `## Test Promises`, `## Acceptance Criteria`, and `## Validation Commands`.
      Your job is to confirm the implementation matches all four.

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks with role: validator
      2. Claim the lowest-ID matching task via TaskUpdate(owner: "<your name>", status: in_progress)
      3. Read full details via TaskGet
      4. Read the spec file at the path the task description references.
         Cross-check `## Acceptance Criteria` and `## Validation Commands`.
      5. Run ALL validation commands and check ALL acceptance criteria
      6. Additionally: verify the implementation matches `## Type Surface` —
         for each new type, confirm the file exists, the signature matches,
         the annotations are correct.
      7. Additionally: verify each test in `## Test Promises` exists, runs,
         and passes (test name → test outcome).
      8. If PASSED: mark completed, send "Validation PASSED: <task-id>" to team-lead
      9. If FAILED and fix_cycle < 2:
         a. Create a fix task (role: builder, Assigned To: <original-builder-name>) via TaskCreate
         b. Create a re-validation task (role: validator) blocked by the fix task via TaskCreate + TaskUpdate
         c. Send "Validation FAILED: fix task <fix-task-id> created for <builder-name>" to team-lead
      10. If FAILED and fix_cycle >= 2: mark completed with failure,
          send "Validation FAILED — max cycles exceeded, needs intervention" to team-lead
      11. Go back to step 1
      12. If no tasks match:
          a. CHECK MAILBOX FIRST — before waiting, check for any incoming messages
          b. If you have a "shutdown_request" message: send "shutdown_response" with the matching request_id and stop IMMEDIATELY
          c. If you have a "wakeup" message: go back to step 1 immediately (skip the wait)
          d. Otherwise: wait 10 seconds, then go back to step 1

             IDLE HEARTBEAT: Every 3rd idle cycle (~30 seconds), send a brief plain-text
             heartbeat to team-lead. Best-effort.
      13. Continue polling indefinitely — do NOT self-terminate
      14. When you receive a "shutdown_request" from team-lead at ANY point: respond
          with `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          via SendMessage and stop immediately.

      IMPORTANT — Shutdown protocol:
      - Always echo the exact `request_id` from the incoming shutdown_request.
      - If you receive a duplicate shutdown_request, re-respond and stop again — do not resume.

      IMPORTANT: Only claim tasks where the description starts with "role: validator".
      Skip any task with "role: builder", "role: spec-updater", or "role: design-updater".
      You are READ-ONLY. You CANNOT write or edit files. Create fix tasks for builders instead.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.

      ----------------------------------------------------------------------
      IDENTITY (the ONLY per-agent substitution — everything above is shared):
      - Your name is "<name>".
      - Your team is "<team-name>".
      ----------------------------------------------------------------------
      ```

12. **DO NOT deploy the spec-updater agent yet.** Spec-updater is **deferred-deployment** — it has no work to do until `validate-all` completes successfully, and deploying it during Phase 3 burns tokens on idle heartbeats throughout the entire builder phase. Phase 1 and Phase 2A retrospectives identified this as wasted spend.

    Instead, store the deployment template below in your in-memory state under the key `deferred_spec_updater`. You will deploy this agent in **Phase 4 Wave 2**, immediately after the validator reports `Validation PASSED: validate-all`.

    **Spec-updater deployment template** (do NOT execute yet — store for Phase 4):
    - `subagent_type`: `"spec-updater"` (from TEAM_MEMBERS)
    - `team_name`: Your team name
    - `name`: `"spec-updater"`
    - Teammate concurrency/visibility: see the Presentation preflight note — teammates always run concurrently (there is no `run_in_background` parameter on agent deployment); foreground split panes come from `teammateMode: "tmux"` + running inside tmux.
    - `prompt`: Identity-last (substitute `<team-name>` ONLY in the IDENTITY block
      at the end; the body is shared across runs):
      ```
      You write Build Evidence into v3 spec files. v3 specs have a
      `## Build Evidence` placeholder section that you replace with real
      evidence after all builder + validator tasks complete.

      You are being deployed in Wave 2 — validate-all has already passed.
      Your task should be unblocked and waiting in the queue.

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks with role: spec-updater
      2. Claim the lowest-ID matching task via TaskUpdate(owner: "spec-updater", status: in_progress)
      3. Read full details via TaskGet
      4. Read the spec file specified in `## Spec File`
      5. Re-run each validation command from `## Validation Commands` —
         capture PASS/FAIL with output
      6. Verify each acceptance criterion from `## Acceptance Criteria` —
         capture evidence (file:line, command output, etc.)
      7. Replace the `## Build Evidence` placeholder section in the spec
         with a populated version containing:
         - Test results table (one row per test category)
         - Validation commands table (Command | Result | Evidence)
         - Acceptance criteria verification (one row per AC)
         - Files changed table (File | Action | Verified)
         - Build metadata: git commit, branch, timestamp, deviations (if any)
      8. Also update the `> **Status:**` line at the top of the spec from
         "DRAFT" to "COMPLETE" with the date.
      9. Mark completed via TaskUpdate(status: completed)
      10. Send completion report to team-lead via SendMessage
      11. If no spec-updater tasks are available within the first 10 seconds
          after deployment, something is wrong (you were deployed because
          your task was supposed to be unblocked). Send a one-time heartbeat
          to team-lead reporting the anomaly, then continue polling.
      12. After your one task completes, do NOT keep polling — send a final
          completion report and wait for shutdown_request. You were deployed
          for a single task; idle heartbeating from this point onward is waste.
      13. When you receive a "shutdown_request" from team-lead: respond with
          `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          and stop IMMEDIATELY. Echo the exact request_id. Treat duplicate
          shutdown_requests as additional confirmations — re-respond and stop again.

      IMPORTANT: Only claim tasks where the description starts with "role: spec-updater".
      Skip any task with "role: builder", "role: validator", or "role: design-updater".
      You may ONLY edit the spec file — NEVER modify source code, tests, or config.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.

      ----------------------------------------------------------------------
      IDENTITY (the ONLY per-agent substitution — everything above is shared):
      - Your name is "spec-updater".
      - Your team is "<team-name>".
      ----------------------------------------------------------------------
      ```

13. **DO NOT deploy the design-updater agent yet** (if the spec lists one). Design-updater is also **deferred-deployment** — it consumes git diff and source files only after the implementation is complete and validated. Deploying early wastes tokens on idle polling.

    If `### Team Members` lists a design-updater AND `## Step by Step Tasks` includes an `update-design-*` task, store the deployment template below under the key `deferred_design_updater`. Otherwise (simple specs that skipped design-updater), set `deferred_design_updater = None`. You will deploy this agent in **Phase 4 Wave 2** alongside spec-updater (both have no file contention — spec-updater writes to `specs/`, design-updater writes to `docs/design/`).

    **Design-updater deployment template** (do NOT execute yet — store for Phase 4):
    - `subagent_type`: `"design-updater"` (from TEAM_MEMBERS)
    - `team_name`: Your team name
    - `name`: `"design-updater"`
    - Teammate concurrency/visibility: see the Presentation preflight note — teammates always run concurrently (there is no `run_in_background` parameter on agent deployment); foreground split panes come from `teammateMode: "tmux"` + running inside tmux.
    - `prompt`: Identity-last (substitute `<team-name>` ONLY in the IDENTITY block
      at the end; the body is shared across runs):
      ```
      You update docs/design/<domain>.md to reflect what was actually built.
      v3 specs reference design docs in `## Design Grounding`. Your job is
      to update those design docs after the build completes so they match
      the implementation, not the original plan.

      You are being deployed in Wave 2 — validate-all has already passed.
      Your task should be unblocked and waiting in the queue.

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks with role: design-updater
      2. Claim the lowest-ID matching task via TaskUpdate(owner: "design-updater", status: in_progress)
      3. Read full details via TaskGet
      4. Read the git diff (git diff HEAD~1 HEAD) and changed source files —
         this is your primary source of truth
      5. Read the existing design doc at the target path specified in the task
      6. Read the v3 spec file for secondary context on intent and decisions
      7. Update docs/design/<domain>.md:
         - Rewrite `## Current Design` to match actual code
         - Append a `## Design Decisions` entry for each non-trivial choice made in this build
         - Reference the v3 spec under each new decision: **Build:** `specs/<spec-file>-v3.md`
      8. Verify every claim has a file:line reference before finalizing
      9. Mark completed via TaskUpdate(status: completed)
      10. Send completion report to team-lead via SendMessage
      11. If no design-updater tasks are available within the first 10 seconds
          after deployment, something is wrong. Send a one-time heartbeat to
          team-lead reporting the anomaly, then continue polling.
      12. After your one task completes, do NOT keep polling — send a final
          completion report and wait for shutdown_request. You were deployed
          for a single task; idle heartbeating from this point onward is waste.
      13. When you receive a "shutdown_request" from team-lead: respond with
          `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          and stop IMMEDIATELY. Echo the exact request_id. Treat duplicates as
          additional confirmations.

      IMPORTANT: Only claim tasks where the description contains "role: design-updater".
      Skip any task with "role: builder", "role: validator", or "role: spec-updater".
      You may ONLY write to docs/design/ files — NEVER modify source code, tests, specs, or config.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.

      ----------------------------------------------------------------------
      IDENTITY (the ONLY per-agent substitution — everything above is shared):
      - Your name is "design-updater".
      - Your team is "<team-name>".
      ----------------------------------------------------------------------
      ```

13a. **Phase 3 deployment summary.** At the end of Phase 3, only Wave 1 agents are running:

    | Wave | Agents | When | Why |
    |---|---|---|---|
    | **1 (now, Phase 3)** | All builders + validator | Immediately | Builders claim tasks; validator runs `validate-all` reactively |
    | **2 (Phase 4, on `Validation PASSED: validate-all`)** | spec-updater + design-updater (if listed) | When validate-all completes successfully | Their tasks are unblocked only after validate-all is done; deploying earlier means idle heartbeats |

    Track these in your in-memory state:
    - `wave_2_deployed: false`
    - `deferred_spec_updater: <template above>`
    - `deferred_design_updater: <template above OR None>`

### Phase 4: Monitor (Leader Receives Messages)

14. **Wait for agent messages.** Agents send completion reports via `SendMessage`. You receive them automatically — do NOT poll.

15. **Track liveness:** Maintain a `last_seen` timestamp per agent, updated each time you receive any message from them. **Track a `deployed_at` timestamp per agent.** Wave 2 agents (spec-updater, design-updater) start with `deployed_at = None`; they are exempt from liveness checks until you set this timestamp at Wave 2 deployment time. Wave 1 agents (builders, validator) get `deployed_at` set at Phase 3 step 10/11.

16. As messages arrive, track progress:
    - If an agent reports "Task <id> complete": note it. No action needed — agents self-discover next work.
    - If an agent reports "Validation PASSED: <task-id>":
      1. Note the result.
      2. **WAVE 2 DEPLOYMENT TRIGGER.** If `task-id == validate-all` AND `wave_2_deployed == false`:
         a. Deploy `deferred_spec_updater` via `Task` using the stored template. Set its `deployed_at = now`. Set `last_seen[spec-updater] = now`.
         b. If `deferred_design_updater` is not None (the spec lists a design-updater): deploy it the same way — `Task` with the stored template, `deployed_at = now`, `last_seen[design-updater] = now`. Both Wave 2 agents run concurrently — they write to different files (`specs/` vs `docs/design/`) so there is no contention.
         c. Set `wave_2_deployed = true` to prevent re-deployment.
         d. Log: "Wave 2 deployed: spec-updater + design-updater (validate-all passed at <timestamp>)".
      3. If `task-id` is anything OTHER than `validate-all` (e.g., a fix re-validation that passed): no Wave 2 trigger; just note the pass.
    - If an agent reports "Validation FAILED: fix task <id> created for <builder-name>":
      1. Note the fix cycle count.
      2. Send a `SendMessage(type: "wakeup", body: "Fix task <id> available — re-check TaskList")` to the named builder agent. This ensures the builder re-checks immediately rather than waiting for its next 10-second poll.
      3. **Do NOT trigger Wave 2.** Wave 2 only fires on PASSED validate-all.
    - If an agent reports "Validation FAILED — max cycles exceeded": this is an escalation. Record the failure details. Do NOT create more fix tasks. **Do NOT trigger Wave 2** — the build is broken; there is no evidence to write into the spec, and design docs would be misleading. Skip directly to Phase 5 with the failure flagged.
    - If the spec-updater reports completion: note the result. This is best-effort — do NOT block shutdown if it fails or times out.
    - If the design-updater reports completion: note the result. Best-effort.

16a. **Wave 2 fallback trigger (defensive).** If at any point you observe `validate-all` showing `status: completed` in `TaskList()` for >2 minutes AND `wave_2_deployed == false`, deploy Wave 2 anyway (the validator's "Validation PASSED" message may have been lost). Same deployment as step 16.2 above. This is a backstop — under normal operation, the message-driven trigger fires first.

17. **Liveness check:** If any agent has been silent for 10+ minutes while a task shows `status: in_progress`:
    - **Exempt agents that haven't been deployed yet.** If `deployed_at[agent] is None`, the agent literally does not exist; silence is expected. Skip.
    - For agents that ARE deployed: send a `SendMessage(type: "ping", body: "Status check — are you still working on task <task-id>?")` to that agent.
    - If no response within 2 minutes: escalate to the user: "Agent <name> appears hung on task <task-id>. Manual intervention may be required."
    - Do NOT automatically re-deploy or kill the agent without user confirmation.

18. When ALL agents report complete or have been silent after all tasks show `status: completed`:
    - Call `TaskList` to verify all tasks show `status: completed`
    - If any tasks are not completed, investigate and resolve. Note: spec-updater and design-updater tasks are only expected to be `completed` if Wave 2 was deployed (i.e., validate-all passed). If validate-all failed and Wave 2 was skipped, those tasks remain unblocked-but-unclaimed; that is expected.

19. If the validator escalated with max-cycle failures:
    - Collect all failure details
    - Report to user via text output
    - Do NOT create more fix tasks
    - **Do NOT deploy Wave 2.** Skip directly to Phase 5 shutdown. The spec-updater and design-updater tasks remain unclaimed in the queue; Phase 5's TeamDelete cleanup handles the team teardown regardless.

### Phase 4b: Leader Context Resilience (stay off the wall)

You accumulate context every time an agent reports in, every time you read a diff, every time you narrate status. On a long build you WILL approach the model's input ceiling. The failure mode observed in production: leader hit 100% context, `/compact` returned `API Error: 400 Input length exceeds maximum`, and the leader wedged in a `Request timed out … Retrying` loop while builders kept working blind. Prevent it:

**R1. Keep your own context lean (continuous):**
- Do NOT hold large blobs in your context. When you inspect ground truth (git diffs, build logs, file contents), pull the SMALLEST slice that answers the question and do not re-paste it into later reasoning. Prefer `git log --oneline`, `git diff --stat`, `TaskList()` summaries over full dumps.
- Delegate detail to agents. Your job is routing and decisions, not holding every builder's output. A completion report's headline (task id + pass/fail + commit) is enough; the detail lives in git and the task record.
- Do NOT narrate long status monologues back into your own context. One-line status notes.

**R2. Watch your budget and re-anchor at a checkpoint (proactive):**
- Treat **~75% context used** as the trigger, not 100%. At a NATURAL boundary near that threshold — a wave completing, a validation gate closing, a task cascade finishing — proactively reset rather than pushing on.
- Coordination state MUST live outside your context so a reset is cheap: the TaskList, git commits, and the roadmap ledger (`docs/design/federation-v3/EXECUTION-ROADMAP.md` §3) are the durable record. Before resetting, make sure the ledger/todo reflect reality.
- To reset: run `/clear` (it is client-side — it wipes your history locally, sends nothing to the model, so it works even at 100% and never 400s), then immediately re-anchor from ground truth with a self-orientation pass:
  1. `git log --oneline -8` and `TaskList()` — real state, do not trust memory.
  2. Re-read the roadmap §3 ledger.
  3. Note in-flight work (uncommitted diffs, agents mid-task) and VERIFY it (e.g. `cargo build`) rather than trusting the last agent claim.
  4. Resume coordinating the cascade.
- `/clear` preserves the agent-team wiring and the TaskList (they live in the process, not the conversation) — builders keep running throughout. This is the gentle path; a process restart with `--allow-auto-truncate` is the last resort and risks disturbing the team wiring.

**R3. If you somehow reach the wall anyway:** do NOT keep typing (every message re-400s). Go straight to `/clear` + re-anchor (R2). Do not attempt `/compact`.

### Phase 5: Shutdown & Report (Resilient, Three-Layered)

The shutdown sequence uses three layered fallbacks identical to v2 — polite shutdown, TeamDelete with retry, tmux pane kill backstop. The mechanics are unchanged from v2 because the team lifecycle is the same.

20. **Verify all tasks complete before shutdown:**
    - Call `TaskList()` and confirm every relevant task shows `status: completed`.
    - **Wave 2 caveat:** if Wave 2 was never deployed (validate-all failed with max-cycle exhaustion), the spec-updater task and design-updater task remain unclaimed in the queue. This is expected and not a blocker for shutdown. Treat unclaimed Wave 2 tasks as "skipped" rather than "incomplete."
    - If a task that SHOULD have been claimed is not completed, investigate and resolve before proceeding.
    - Do NOT send shutdown requests until the task list is fully clean (modulo skipped Wave 2 tasks).

21. **LAYER 1 — Polite shutdown with retry:**
    - Send `shutdown_request` to ALL **actually-deployed** agents simultaneously. The deployed set is: all builders + validator + (spec-updater IFF `wave_2_deployed == true`) + (design-updater IFF deployed in Wave 2). Do NOT send shutdown_request to agents whose `deployed_at is None` — they don't exist as processes.
    - Record each `request_id` returned by `SendMessage` and the list of agents awaiting `shutdown_response`.
    - Each request body MUST be: `{"type": "shutdown_request", "reason": "<spec> build complete"}`.
    - As `shutdown_response` messages arrive, remove each agent from the awaiting list. Match by `request_id` if provided; otherwise match by sender name.
    - If all responses arrive before `SHUTDOWN_TIMEOUT_SECONDS` (default: 60): proceed to step 24 (TeamDelete).
    - If `SHUTDOWN_TIMEOUT_SECONDS` elapses and ≥1 agent has not responded:
      - Log: "Agents `<names>` did not respond to first shutdown_request within `<SHUTDOWN_TIMEOUT_SECONDS>`s — retrying."
      - Re-send `shutdown_request` to JUST those unresponsive agents (with a fresh `request_id` each). Wait `SHUTDOWN_RETRY_INTERVAL_SECONDS` between retries. Up to `SHUTDOWN_MAX_RETRIES` (default: 2) attempts.
    - As soon as all agents have responded — at any retry — proceed to step 24.
    - If all retries are exhausted with agents still silent, proceed to step 22.

22. **LAYER 2 — `TeamDelete` with retry:**
    - Attempt `TeamDelete`. If it succeeds (no active members reported), proceed to step 25 (build report).
    - If `TeamDelete` returns `Cannot cleanup team with N active member(s)`: capture the list of names from the error message.
    - Wait `TMUX_KILL_GRACE_SECONDS` (default: 5) and retry `TeamDelete` once more.
    - If `TeamDelete` still fails, proceed to step 23.

23. **LAYER 3 — tmux pane kill backstop:**
    - Read `~/.claude/teams/<team-name>/config.json` via `Bash + cat`. The file contains a `members` array; each member with `isActive: true` and a non-empty `tmuxPaneId` is a candidate for forced termination.
    - For EACH unresponsive agent (intersection of "in awaiting list from Layer 1" AND "isActive: true in config.json"):
      - Run `tmux list-panes -F '#{pane_id}'` via Bash to verify the pane still exists.
      - If the pane exists, run `tmux kill-pane -t <pane-id>` via Bash.
      - Use `jq` to set `isActive: false` for that member in `~/.claude/teams/<team-name>/config.json` (atomic via tmpfile + mv):
        ```bash
        TEAM_DIR="$HOME/.claude/teams/<team-name>"
        jq --arg name "<agent-name>" \
           '.members |= map(if .name == $name then .isActive = false else . end)' \
           "$TEAM_DIR/config.json" > "$TEAM_DIR/config.json.tmp" \
          && mv "$TEAM_DIR/config.json.tmp" "$TEAM_DIR/config.json"
        ```
      - Fallback to Python one-liner if `jq` not available:
        ```bash
        python3 -c "
        import json, sys
        p='$TEAM_DIR/config.json'
        d=json.load(open(p))
        for m in d.get('members', []):
            if m.get('name') == '<agent-name>':
                m['isActive'] = False
        json.dump(d, open(p,'w'), indent=2)
        "
        ```
    - Log each kill explicitly: "Force-terminated agent `<name>` (pane `<pane-id>`) — agent did not respond to shutdown protocol after Layer 1 + Layer 2."
    - After all unresponsive agents have been force-terminated, retry `TeamDelete`.
    - If `TeamDelete` STILL fails after Layer 3, escalate to user via text output: "Manual intervention required: team `<name>` cannot be cleaned up. Active members: `<names>`. Suggested action: clean up `~/.claude/teams/<team-name>` and `~/.claude/tasks/<team-name>` directories."

24. **(Reachable from Layer 1 success path)** Call `TeamDelete` to clean up the team.

25. Present the build report:

```
## Build Complete (v3)

**Spec**: <spec name from PATH_TO_SPEC>
**Team**: <team name with timestamp>
**Status**: All tasks completed | Issues remain

### Spec Format
- Version: v3 (unified TDD + orchestration)
- Design grounding: <ADRs and design docs referenced>

### Agents Deployed (Two-Wave Schedule)
| Name | Type | Wave | Deployed At | Tasks Completed |
|------|------|------|-------------|-----------------|
| <name> | <type> | 1 | <Phase 3 timestamp> | <count> |
| validator | validator | 1 | <Phase 3 timestamp> | <count> |
| spec-updater | spec-updater | 2 | <on validate-all PASS, OR "not deployed — validate-all failed"> | <count> |
| design-updater | design-updater | 2 | <on validate-all PASS, OR "not deployed — no design-updater listed", OR "not deployed — validate-all failed"> | <count> |

### Wave 2 Trigger
- Wave 2 deployed: <Yes / No>
- Trigger reason: <"Validation PASSED: validate-all" message received | Fallback (validate-all task observed completed for >2 minutes) | Skipped (validate-all failed with max-cycle exhaustion) | Skipped (no spec-updater or design-updater listed in Team Members)>
- Idle-token savings (estimated): <N agents × M minutes of pre-deferral idle polling avoided>

### Tasks
| # | Task | Assigned To | Owner (claimed by) | Status |
|---|------|-------------|-------------------|--------|
| 1 | <task name> | <assigned-to> | <actual owner> | Completed / Failed |
| ... | ... | ... | ... | ... |

### Type Surface Coverage
- New types built: <count> / <count expected> from `## Type Surface`
- Modified types built: <count> / <count expected>
- Deviations: <list any types built differently than the spec specified>

### Test Promises Coverage
- Tests written: <count> / <count expected> from `## Test Promises`
- Tests passing: <count>
- Test categories met: <list categories with counts>

### Validation Results
- <criteria 1> — PASS / FAIL
- <criteria 2> — PASS / FAIL

### Fix Cycles
- Cycle 0: <initial validation result>
- Cycle 1: <if applicable>
- Cycle 2: <if applicable>

### Spec Evidence
- Status: COMPLETE / PARTIAL / FAILED / NOT WRITTEN
- Spec file: <PATH_TO_SPEC>
- Build Evidence section populated: Yes / No

### Files Changed
- <file path> — <what changed>

### Shutdown Anatomy
- Layer 1 (polite): <N> of <total> agents responded in <X>s
- Layer 2 (TeamDelete retry): <Used / Skipped>
- Layer 3 (tmux kill): <List of force-terminated agents, or "Not needed">

### Issues (if any)
- <unresolved issue>
```
