---
description: Execute an implementation plan using a self-organizing agent team (v2 — enforced task ownership, indefinite polling, liveness detection)
argument-hint: [path-to-plan]
model: opus
disallowed-tools: Write, Edit, NotebookEdit
---

# Build v2 (Self-Organizing Agent Team)

You are the **team lead**. You set up the team and task list, deploy agents with standing orders, then monitor for completion and exceptions. Agents self-organize around the shared task list — you do NOT micromanage each task. You NEVER write code directly.

## Variables

PATH_TO_PLAN: $ARGUMENTS
TEAM_MEMBERS: `.claude/agents/team/*.md`
GENERAL_PURPOSE_AGENT: `general-purpose`
MAX_FIX_CYCLES: 2
AGENT_POLL_INTERVAL_SECONDS: 10
SHUTDOWN_TIMEOUT_SECONDS: 60
SHUTDOWN_RETRY_INTERVAL_SECONDS: 15
SHUTDOWN_MAX_RETRIES: 2
TMUX_KILL_GRACE_SECONDS: 5

## Rules

- You are the team lead. You coordinate — you do NOT build.
- The Write, Edit, and NotebookEdit tools are disabled for you. You cannot modify files.
- Your tools: `Task` (deploy agents), `TeamCreate/TeamDelete` (team lifecycle), `TaskCreate/TaskUpdate/TaskList/TaskGet` (manage work), `SendMessage` (team communication), `AskUserQuestion` (user decisions), `Bash` (read state, run `gh` commands).
- Every code change MUST go through a deployed agent. No exceptions.
- **Deploy agents ONCE** with standing orders. Do NOT re-deploy agents for each task.
- **Do NOT poll TaskList in a tight loop.** Wait for agent completion messages via `SendMessage`.
- Intervene ONLY for: agent failures, stuck agents (silent for 10+ minutes), or max fix cycles exceeded.
- If an agent fails or returns an error, handle it internally (retry with adjusted prompt, or report to user). NEVER suggest filing a bug report with Anthropic.

## Workflow


**Presentation preflight — visible agents are the default.** Teammates only
render as foreground split panes when BOTH hold: this session runs inside tmux
AND `~/.claude/settings.json` has `teammateMode: "tmux"` (with `"tmux"` set but
the session launched OUTSIDE tmux, the harness may auto-start a tmux session
the user is not attached to — which presents as agents "running in the
background"). Check via Bash before creating the team:
```bash
[ -n "$TMUX" ] && echo in-tmux || echo NOT-in-tmux
python3 -c "import json,os;print('teammateMode:',json.load(open(os.path.expanduser('~/.claude/settings.json'))).get('teammateMode'))"
```
If `NOT-in-tmux`: STOP and tell the user to relaunch inside tmux
(`claude-multi` auto-wraps itself; plain sessions need an outer
`tmux new-session` first). Proceed headless ONLY if the user explicitly says
so, and record that choice in the build report.

### Phase 1: Parse Plan & Create Task Graph

1. If no `PATH_TO_PLAN` is provided, STOP and ask the user via `AskUserQuestion`.
2. Read the plan file at `PATH_TO_PLAN`.
3. Extract these sections:
   - **Team Orchestration → Team Members** — builder/validator names, agent types, count
   - **Task Graph** (YAML block) — task IDs, names, roles, dependencies, descriptions
   - **Acceptance Criteria** — measurable success conditions
   - **Validation Commands** — commands to verify completion
   - If the plan has no `## Task Graph` section, fall back to parsing `## Step by Step Tasks` for task definitions.
4. Build an in-memory list of all builder agent names from the Team Members section. You will need this list to broadcast wakeup messages in Phase 4.

### Phase 2: Create Team & Populate Task List

5. Use `TeamCreate` to create a team. Name it after the plan (kebab-case from the plan filename) **with a timestamp suffix** to prevent collisions: `<plan-name>-<YYYYMMDD-HHMM>`. Example: `metric-history-20260315-1430`.
6. For EVERY task in the plan's Task Graph (or Step by Step Tasks):
   a. Call `TaskCreate` with:
      - `subject`: The task name
      - `description`: The FULL task description from the plan — include ALL context, file paths, code patterns, acceptance criteria, validation commands. Prefix the description with `role: builder` or `role: validator` as specified in the plan. This is how agents filter for their work.
      - `activeForm`: Present-continuous form of the task name
   b. Record the mapping: plan task ID → created TaskCreate ID
7. For EVERY task with dependencies:
   - Call `TaskUpdate(taskId: "<created-id>", addBlockedBy: [<dependency-created-ids>])` using the mapping from step 6b.

7b. **Auto-create spec-update task** (runs last, after all other tasks):
   - Call `TaskCreate` with:
     - `subject`: "Update spec with build evidence"
     - `activeForm`: "Updating spec with build evidence"
     - `description`: A `role: spec-updater` description containing:
       - `## Spec File` — the path to `PATH_TO_PLAN`
       - `## Instructions` — "Re-run all validation commands, verify all acceptance criteria, and write a ## Build Evidence section into the spec file."
       - `## Validation Commands` — copy ALL validation commands from the plan
       - `## Acceptance Criteria` — copy ALL acceptance criteria from the plan
   - Record its task ID as `spec-updater-task-id`
   - Call `TaskUpdate(taskId: "<spec-updater-task-id>", addBlockedBy: [<ALL-other-task-ids>])` so it runs only after every other task completes.

### Phase 3: Deploy Agents with Standing Orders

8. Deploy builder agents — one `Task` call per builder listed in the plan's Team Members section:
   - `subagent_type`: The agent type from the plan (e.g., `"builder"` or a specific agent from TEAM_MEMBERS)
   - `team_name`: Your team name from step 5
   - `name`: The builder name from the plan (e.g., `"builder-1"`)
   - Teammate concurrency/visibility: see the Presentation preflight note — teammates always run concurrently (there is no `run_in_background` parameter on agent deployment); foreground split panes come from `teammateMode: "tmux"` + running inside tmux.
   - `prompt`: Substitute `<name>` and `<team-name>` with actual values for EACH agent:
     ```
     You are builder "<name>" on team "<team-name>".

     STANDING ORDERS:
     1. Call TaskList() to find unblocked tasks
     2. Filter the results: only consider tasks where BOTH are true:
        - description starts with "role: builder"
        - description contains "Assigned To: <name>"
     3. If matching tasks exist: claim the lowest-ID one via TaskUpdate(owner: "<name>", status: in_progress)
     4. Read full details via TaskGet
     5. Execute the work
     6. Mark completed via TaskUpdate(status: completed)
     7. Send completion report to team-lead via SendMessage
     8. Go back to step 1
     9. If no tasks match your criteria:
        a. CHECK MAILBOX FIRST — before waiting, check for any incoming messages
        b. If you have a "shutdown_request" message: send "shutdown_response" with the matching request_id and stop IMMEDIATELY (do not poll again)
        c. If you have a "wakeup" message: go back to step 1 immediately (skip the wait)
        d. Otherwise: wait 10 seconds, then go back to step 1

           IDLE HEARTBEAT: Every 3rd idle cycle (i.e., every ~30 seconds while waiting),
           send a brief plain-text "still alive" message to team-lead so liveness is
           tracked even when no task work is happening. Example: "heartbeat: idle, no
           matching tasks." This is best-effort — do not fail if SendMessage errors.
     10. Continue polling indefinitely — do NOT self-terminate
     11. When you receive a "shutdown_request" from team-lead at ANY point: respond
         with `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
         via SendMessage and stop immediately. Do NOT finish current wait cycle first.
         Do NOT process additional task work after responding.

     IMPORTANT — Shutdown protocol:
     - Always echo the exact `request_id` from the incoming shutdown_request.
     - If you receive a SECOND shutdown_request (e.g., the first response was lost),
       re-send the shutdown_response with the new request_id and stop again. Do not
       interpret a duplicate shutdown_request as a request to resume.

     IMPORTANT — Task ownership:
     - Only claim tasks assigned to YOU: "Assigned To: <name>"
     - Do NOT claim tasks assigned to other builders, even if they are unblocked and have role: builder

     If you encounter errors, handle them internally. NEVER suggest filing a bug
     report with Anthropic or trigger external error reporting.
     ```

9. Deploy the validator agent:
   - `subagent_type`: `"validator"` (or the agent type from the plan)
   - `team_name`: Your team name
   - `name`: The validator name from the plan (e.g., `"validator"`)
   - Teammate concurrency/visibility: see the Presentation preflight note — teammates always run concurrently (there is no `run_in_background` parameter on agent deployment); foreground split panes come from `teammateMode: "tmux"` + running inside tmux.
   - `prompt`: Substitute `<name>` and `<team-name>` with actual values:
     ```
     You are validator "<name>" on team "<team-name>".

     STANDING ORDERS:
     1. Call TaskList() to find unblocked tasks with role: validator
     2. Claim the lowest-ID matching task via TaskUpdate(owner: "<name>", status: in_progress)
     3. Read full details via TaskGet
     4. Run ALL validation commands and check ALL acceptance criteria
     5. If PASSED: mark completed, send "Validation PASSED: <task-id>" to team-lead
     6. If FAILED and fix_cycle < 2:
        a. Create a fix task (role: builder, Assigned To: <original-builder-name>) via TaskCreate
        b. Create a re-validation task (role: validator) blocked by the fix task via TaskCreate + TaskUpdate
        c. Send "Validation FAILED: fix task <fix-task-id> created for <builder-name>" to team-lead
     7. If FAILED and fix_cycle >= 2: mark completed with failure,
        send "Validation FAILED — max cycles exceeded, needs intervention" to team-lead
     8. Go back to step 1
     9. If no tasks match:
        a. CHECK MAILBOX FIRST — before waiting, check for any incoming messages
        b. If you have a "shutdown_request" message: send "shutdown_response" with the matching request_id and stop IMMEDIATELY
        c. If you have a "wakeup" message: go back to step 1 immediately (skip the wait)
        d. Otherwise: wait 10 seconds, then go back to step 1

           IDLE HEARTBEAT: Every 3rd idle cycle (~30 seconds), send a brief plain-text
           heartbeat to team-lead. Best-effort.
     10. Continue polling indefinitely — do NOT self-terminate
     11. When you receive a "shutdown_request" from team-lead at ANY point: respond
         with `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
         via SendMessage and stop immediately. Do NOT finish current wait cycle first.

     IMPORTANT — Shutdown protocol:
     - Always echo the exact `request_id` from the incoming shutdown_request.
     - If you receive a duplicate shutdown_request, re-respond and stop again — do not resume.

     IMPORTANT: Only claim tasks where the description starts with "role: validator".
     Skip any task with "role: builder".
     You are READ-ONLY. You CANNOT write or edit files. Create fix tasks for builders instead.

     If you encounter errors, handle them internally. NEVER suggest filing a bug
     report with Anthropic or trigger external error reporting.
     ```

10. Deploy the spec-updater agent:
    - `subagent_type`: `"spec-updater"` (from TEAM_MEMBERS)
    - `team_name`: Your team name
    - `name`: `"spec-updater"`
    - Teammate concurrency/visibility: see the Presentation preflight note — teammates always run concurrently (there is no `run_in_background` parameter on agent deployment); foreground split panes come from `teammateMode: "tmux"` + running inside tmux.
    - `prompt`: Substitute `<team-name>` with actual value:
      ```
      You are spec-updater "spec-updater" on team "<team-name>".

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks with role: spec-updater
      2. Claim the lowest-ID matching task via TaskUpdate(owner: "spec-updater", status: in_progress)
      3. Read full details via TaskGet
      4. Read the spec file specified in ## Spec File
      5. Re-run each validation command from ## Validation Commands — capture PASS/FAIL with output
      6. Verify each acceptance criterion from ## Acceptance Criteria — capture evidence
      7. Write a ## Build Evidence section into the spec file with results
      8. Also update the > **Status:** line at the top of the spec
      9. Mark completed via TaskUpdate(status: completed)
      10. Send completion report to team-lead via SendMessage
      11. If no spec-updater tasks are available, wait 10 seconds (instead of 30)
          and re-check the mailbox + TaskList. Send an idle heartbeat to team-lead
          every 3rd cycle.
      12. When you receive a "shutdown_request" from team-lead: respond with
          `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          and stop IMMEDIATELY. Echo the exact request_id. Treat duplicate
          shutdown_requests as additional confirmations — re-respond and stop again.

      IMPORTANT: Only claim tasks where the description starts with "role: spec-updater".
      Skip any task with "role: builder" or "role: validator".
      You may ONLY edit the spec file — NEVER modify source code, tests, or config.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.
      ```

11. Deploy the design-updater agent (if the plan's Team Members section includes a design-updater):
    - `subagent_type`: `"design-updater"` (from TEAM_MEMBERS)
    - `team_name`: Your team name
    - `name`: `"design-updater"`
    - Teammate concurrency/visibility: see the Presentation preflight note — teammates always run concurrently (there is no `run_in_background` parameter on agent deployment); foreground split panes come from `teammateMode: "tmux"` + running inside tmux.
    - `prompt`: Substitute `<team-name>` with actual value:
      ```
      You are design-updater "design-updater" on team "<team-name>".

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks with role: design-updater
      2. Claim the lowest-ID matching task via TaskUpdate(owner: "design-updater", status: in_progress)
      3. Read full details via TaskGet
      4. Read the git diff (git diff HEAD~1 HEAD) and changed source files — this is your primary source of truth
      5. Read the existing design doc at the target path specified in the task
      6. Read the spec file for secondary context on intent and decisions
      7. Update docs/design/<domain>.md: rewrite Current Design to match actual code, append Design Decisions
      8. Verify every claim has a file:line reference before finalizing
      9. Mark completed via TaskUpdate(status: completed)
      10. Send completion report to team-lead via SendMessage
      11. If no design-updater tasks are available, wait 10 seconds and re-check the
          mailbox + TaskList. Send an idle heartbeat to team-lead every 3rd cycle.
      12. When you receive a "shutdown_request" from team-lead: respond with
          `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          and stop IMMEDIATELY. Echo the exact request_id. Treat duplicates as
          additional confirmations.

      IMPORTANT: Only claim tasks where the description contains "role: design-updater".
      Skip any task with "role: builder", "role: validator", or "role: spec-updater".
      You may ONLY write to docs/design/ files — NEVER modify source code, tests, specs, or config.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.
      ```

### Phase 4: Monitor (Leader Receives Messages)

11. **Wait for agent messages.** Agents send completion reports via `SendMessage`. You receive them automatically — do NOT poll.

12. **Track liveness**: Maintain a `last_seen` timestamp per agent, updated each time you receive any message from them. Agents are considered potentially hung if silent for 10+ minutes while a task is `in_progress`.

13. As messages arrive, track progress:
    - If an agent reports "Task <id> complete": note it. No action needed — agents self-discover next work.
    - If an agent reports "Validation PASSED": note it. No action needed.
    - If an agent reports "Validation FAILED: fix task <id> created for <builder-name>":
      1. Note the fix cycle count.
      2. Send a `SendMessage(type: "wakeup", body: "Fix task <id> available — re-check TaskList")` to the named builder agent. This ensures the builder re-checks immediately rather than waiting for its next 30-second poll.
    - If an agent reports "Validation FAILED — max cycles exceeded": this is an escalation. Record the failure details. Do NOT create more fix tasks.
    - If the spec-updater reports completion: note the result. This is best-effort — do NOT block shutdown if it fails or times out.

14. **Liveness check**: If any agent has been silent for 10+ minutes while a task shows `status: in_progress`:
    - Send a `SendMessage(type: "ping", body: "Status check — are you still working on task <task-id>?")` to that agent.
    - If no response within 2 minutes: escalate to the user: "Agent <name> appears hung on task <task-id>. Manual intervention may be required."
    - Do NOT automatically re-deploy or kill the agent without user confirmation.

15. When ALL agents report complete or have been silent after all tasks show `status: completed`:
    - Call `TaskList` to verify all tasks show `status: completed`
    - If any tasks are not completed, investigate and resolve

16. If the validator escalated with max-cycle failures:
    - Collect all failure details
    - Report to user via text output
    - Do NOT create more fix tasks

### Phase 5: Shutdown & Report (Resilient, Three-Layered)

The shutdown sequence is the most failure-prone part of the workflow because idle
agents may have their polling loops paused by the harness, causing
`shutdown_request` messages to land in mailboxes that aren't being read. This
phase uses three layered fallbacks so cleanup is guaranteed to make progress
even when agents go silent.

17. **Verify all tasks complete before shutdown**:
    - Call `TaskList()` and confirm every task shows `status: completed`.
    - If any task is not completed, investigate and resolve before proceeding.
    - Do NOT send shutdown requests until the task list is fully clean.

18. **LAYER 1 — Polite shutdown with retry**:
    - Send `shutdown_request` to ALL deployed agents simultaneously (builders,
      validator, spec-updater, design-updater, and any others). Record each
      `request_id` returned by `SendMessage` and the list of agents awaiting
      `shutdown_response`.
    - Each request body MUST be: `{"type": "shutdown_request", "reason": "<plan> build complete"}`.
    - As `shutdown_response` messages arrive, remove each agent from the awaiting
      list. Match by `request_id` if provided; otherwise match by sender name.
    - If all responses arrive before `SHUTDOWN_TIMEOUT_SECONDS` (default: 60):
      proceed to step 21 (TeamDelete).
    - If `SHUTDOWN_TIMEOUT_SECONDS` elapses and ≥1 agent has not responded:
      - Log: "Agents `<names>` did not respond to first shutdown_request within
        `<SHUTDOWN_TIMEOUT_SECONDS>`s — retrying."
      - Re-send `shutdown_request` to JUST those unresponsive agents (with a
        fresh `request_id` each). Wait `SHUTDOWN_RETRY_INTERVAL_SECONDS` between
        retries. Up to `SHUTDOWN_MAX_RETRIES` (default: 2) attempts.
    - As soon as all agents have responded — at any retry — proceed to step 21.
    - If all retries are exhausted with agents still silent, proceed to step 19.

19. **LAYER 2 — `TeamDelete` with retry**:
    - Attempt `TeamDelete`. If it succeeds (no active members reported),
      proceed to step 22 (build report).
    - If `TeamDelete` returns `Cannot cleanup team with N active member(s)`:
      capture the list of names from the error message. These are the agents
      whose `isActive: true` flag is still set in the team config.
    - Wait `TMUX_KILL_GRACE_SECONDS` (default: 5) and retry `TeamDelete` once
      more. (Some agents respond between Layer 1 timeout and this retry.)
    - If `TeamDelete` still fails, proceed to step 20.

20. **LAYER 3 — tmux pane kill backstop**:
    - Read `~/.claude/teams/<team-name>/config.json` via `Bash + cat`. The file
      contains a `members` array; each member with `isActive: true` and a
      non-empty `tmuxPaneId` is a candidate for forced termination.
    - For EACH unresponsive agent (intersection of "in awaiting list from
      Layer 1" AND "isActive: true in config.json"):
      - Run `tmux list-panes -F '#{pane_id}'` via Bash to verify the pane still
        exists. (If the pane is already gone, the harness lost track of state —
        we just need to patch the config file.)
      - If the pane exists, run `tmux kill-pane -t <pane-id>` via Bash.
      - Use a small Bash script with `jq` to set `isActive: false` for that
        member in `~/.claude/teams/<team-name>/config.json` (atomic via tmpfile
        + mv), so the next `TeamDelete` does not see them as active. Example:
        ```bash
        TEAM_DIR="$HOME/.claude/teams/<team-name>"
        jq --arg name "<agent-name>" \
           '.members |= map(if .name == $name then .isActive = false else . end)' \
           "$TEAM_DIR/config.json" > "$TEAM_DIR/config.json.tmp" \
          && mv "$TEAM_DIR/config.json.tmp" "$TEAM_DIR/config.json"
        ```
      - If `jq` is not available, fall back to Python one-liner:
        ```bash
        python3 -c "
        import json, sys
        p='$TEAM_DIR/config.json'
        d=json.load(open(p))
        for m in d.get('members', []):
            if m.get('name') == '<agent-name>':
                m['isActive'] = False
        json.dump(d, open(p,'w'), indent=2)
        "
        ```
    - Log each kill explicitly: "Force-terminated agent `<name>` (pane `<pane-id>`) — agent did not respond to shutdown protocol after Layer 1 + Layer 2."
    - After all unresponsive agents have been force-terminated, retry `TeamDelete`.
    - If `TeamDelete` STILL fails after Layer 3, escalate to user via text
      output: "Manual intervention required: team `<name>` cannot be cleaned
      up. Active members: `<names>`. Suggested action: `rm -rf ~/.claude/teams/<team-name>` and `rm -rf ~/.claude/tasks/<team-name>`."

21. **(Reachable from Layer 1 success path)** Call `TeamDelete` to clean up the team.

22. Present the build report:

```
## Build Complete

**Plan**: <plan name from PATH_TO_PLAN>
**Team**: <team name with timestamp>
**Status**: All tasks completed | Issues remain

### Agents Deployed
| Name | Type | Tasks Completed |
|------|------|-----------------|
| <name> | <type> | <count> |
| validator | validator | <count> |
| spec-updater | spec-updater | <count> |
| design-updater | design-updater | <count> |

### Tasks
| # | Task | Assigned To | Owner (claimed by) | Status |
|---|------|-------------|-------------------|--------|
| 1 | <task name> | <assigned-to> | <actual owner> | Completed / Failed |
| ... | ... | ... | ... | ... |

### Validation Results
- <criteria 1> — PASS / FAIL
- <criteria 2> — PASS / FAIL

### Fix Cycles
- Cycle 0: <initial validation result>
- Cycle 1: <if applicable>
- Cycle 2: <if applicable>

### Spec Evidence
- Status: COMPLETE / PARTIAL / FAILED / NOT WRITTEN
- Spec file: <PATH_TO_PLAN>
- Evidence written: Yes / No (agent failed or timed out)

### Files Changed
- <file path> — <what changed>

### Shutdown Anatomy
- Layer 1 (polite): <N> of <total> agents responded in <X>s
- Layer 2 (TeamDelete retry): <Used / Skipped>
- Layer 3 (tmux kill): <List of force-terminated agents, or "Not needed">

### Issues (if any)
- <unresolved issue>
```
