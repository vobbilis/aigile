---
description: Creates a unified TDD-grade build spec in a single file, derived from a design grounding (ADR + design doc + scope pointer). No separate TDD plan; design rationale, type definitions, test promises, RED-GREEN-REFACTOR rationale, AND build orchestration all live in one v3 spec ready for /build_v3.
argument-hint: "[user prompt with design grounding pointer (ADR/design-doc/scope) and task description]"
model: opus
context: fork
allowed-tools: Read, Grep, Glob, Bash, Write, Edit, WebSearch, WebFetch, TaskCreate, TaskUpdate, TaskList, TaskGet, AskUserQuestion
hooks:
  Stop:
    - hooks:
        - type: command
          command: >-
            uv run $HOME/.claude/hooks/validators/validate_new_file.py
            --directory specs
            --extension .md
        - type: command
          command: >-
            uv run $HOME/.claude/hooks/validators/validate_v3_spec.py
            --directory specs
            --extension .md
---

# Plan To Build v3 — Unified TDD-Grade Build Spec

Create a **single self-contained build spec** that combines the design rationale, type-level engineering content (formerly in TDD plans), and the build orchestration scaffolding (formerly in v2 specs) into one artifact. The output is consumable directly by `/build_v3` without a separate TDD intermediate.

This command supersedes the v2 two-stage pipeline (TDD plan → `/plan_to_build_v2` conversion → v2 spec). The v2 split was an accident of process; in v3, design-thinking content and build-execution content are co-located in a single file because they describe the same work.

## Variables

USER_PROMPT: $ARGUMENTS
SPEC_OUTPUT_DIRECTORY: `specs/`
DESIGN_OUTPUT_DIRECTORY: `docs/design/`
ADR_DIRECTORY: `docs/arch/adr/`
TEAM_MEMBERS: `.claude/agents/team/*.md`
GENERAL_PURPOSE_AGENT: `general-purpose`

## Instructions

- **PLANNING ONLY.** Do NOT build, write code, or deploy agents. Output is one v3 spec file plus (if needed) an updated design document.
- If no `USER_PROMPT` is provided, stop and ask the user via `AskUserQuestion`.
- The user prompt should contain a **design grounding pointer**: a path to an ADR, a design doc, a scope document, or a sub-task ID within an existing design. If the prompt is freeform without grounding, conduct a design study and produce/update a design document FIRST, then write the spec from it.
- Carefully analyze the user's requirements and determine task type (chore|feature|refactor|fix|enhancement) and complexity (simple|medium|complex).
- Think deeply (ultrathink) about the right approach before authoring.
- **Design-grounded**: every type, test name, file:line reference, validation command, and acceptance criterion must trace back to either the design doc, the ADR, or the existing code. No hallucinated APIs.
- Understand the codebase directly without subagents to verify file:line references and existing patterns.
- Generate a descriptive kebab-case filename based on the milestone or sub-task identifier.
- Save the spec before completing.
- Ensure the spec is detailed enough that `/build_v3` can deploy a team and the team can execute autonomously.
- Consider edge cases, error handling, and scalability concerns inside the Test Promises section.
- Understand how `/build_v3` executes specs. Refer to the `Team Orchestration` section in the Spec Format. Your spec must be complete enough for agents to work autonomously.
- **Include design-updater tasks** for any spec of medium or complex complexity. Each design-updater task targets a specific `docs/design/<domain>.md` and writes back what was actually built.

### What v3 changes from v2

- **One file, not two.** The v2 pipeline produced `<milestone>-tdd-plan.md` (design-thinking) and `<milestone>-v2.md` (build-orchestration). v3 produces only `<milestone>-v3.md` containing both.
- **Design-thinking content stays inline.** Type definitions with annotations, test names with what-they-prove rationale, RED-GREEN-REFACTOR walkthroughs (where they add value), full domain enumeration — all preserved in the v3 spec under explicit sections (`## Type Surface`, `## Test Promises`, `## RED-GREEN-REFACTOR`).
- **Build-execution content stays inline.** Task graph, role prefixes, agent assignments, validation commands, acceptance criteria, build evidence section — preserved.
- **No TDD plan file is produced.** Authors who previously thought in TDD-plan-then-spec terms now compose both views in one document.
- **Build evidence section is initially empty.** `/build_v3`'s spec-updater agent fills it in after the build completes.

### How /build_v3 Executes This Spec

`/build_v3` reads the spec, creates a self-organizing agent team, populates the task list from `## Step by Step Tasks`, deploys agents with standing orders, and monitors for completion. The flow is identical to `/build_v2`:

1. **Creates a team** via `TeamCreate` — name is `<spec-name>-<timestamp>`
2. **Populates the task list** — one `TaskCreate` per task in `## Step by Step Tasks`, with dependencies via `addBlockedBy`
3. **Deploys agents once** with standing orders — builders, validator, spec-updater, design-updater per `### Team Members`
4. **Agents self-organize** — they poll `TaskList`, claim tasks **assigned to their own name**, execute work, mark completed, and loop
5. **Validator auto-creates fix tasks** if validation fails (max 2 fix cycles)
6. **Spec-updater writes Build Evidence** into the spec file after all tasks complete
7. **Leader monitors** via `SendMessage` reports

#### What This Means for Spec Quality

Because agents work autonomously:
- **Task descriptions must be exhaustive** — agents cannot ask the leader for clarification
- **`Assigned To` is enforced** — every task must have an `Assigned To` matching a builder name from `### Team Members`; agents only claim tasks assigned to them
- **Dependencies must be correct** — agents trust `Depends On` to prevent premature starts
- **Team composition must be complete** — `/build_v3` deploys exactly what's listed
- **Validation must be specific** — the validator runs exactly the commands listed in `## Validation Commands`
- **Type surface and test promises are shared context** — every builder task should reference `## Type Surface` and `## Test Promises` so agents know what to build and what to prove

## Workflow

IMPORTANT: **PLANNING ONLY** — do not execute, build, or deploy. Output is one v3 spec file (and optionally an updated design doc).

### Phase A: Requirements & Grounding Analysis

1. **Parse the prompt.** Identify the milestone or sub-task identifier (e.g., `phase-2a-MX.0`, `bug-fix-cedar-staleness`), the design grounding pointer (ADR path, design doc path, scope section), and the scope of work.

2. **Read the design grounding documents.**
   - Read every ADR referenced in the prompt.
   - Read the design doc the prompt points to.
   - Extract the locked decisions (D-NNN), type definitions, sub-task tables, sequencing notes, and acceptance gates that apply to this work.
   - If the prompt says "amended" — read the amendment carefully; amendments are authoritative over the original body.

3. **Read existing related design docs.** Glob `docs/design/` for documents touching the same domain. Cross-reference for established patterns.

4. **Read existing related ADRs.** Glob `docs/arch/adr/` for ADRs that bind decisions in this domain.

5. **Understand the codebase directly.** Without subagents, verify the `file:line` references that the design grounding documents make. Confirm types, function signatures, and module structures exist where the design says they do. If any reference has drifted (file moved, function renamed), note it.

### Phase B: Conditional Design Study

If the prompt has full design grounding (ADR + design doc with locked decisions), **skip to Phase C**. Otherwise:

6. **Conduct a design study** following the design-study-expert methodology:
   - **Full Domain Enumeration** — all operations the work touches, categorized by complexity
   - **Security Analysis** — vulnerabilities, attack surfaces, data exposure
   - **Correctness Analysis** — logic errors, race conditions, edge cases
   - **Performance Analysis** — hot paths, allocations, algorithmic complexity
   - **Scalability Analysis** — behavior at 10x/100x load
   - **Industry Comparison** — at least 2 leading systems
   - **10x Opportunities** — at least one significant improvement opportunity

7. **Write/update the design document** at `docs/design/<domain>.md` per the format in the v2 plan_to_build (preserved for backward compatibility — same Design Document Format applies).

This phase produces `docs/design/<domain>.md` if a design study was needed. If the prompt was already fully grounded, no new design doc is produced; the spec references the existing one.

### Phase C: Spec Authoring (the load-bearing phase)

8. **Generate the spec filename.** Use the milestone or sub-task identifier in kebab-case: `phase-2a-MX.0-v3.md`, `bug-cedar-staleness-fix-v3.md`. Suffix is always `-v3.md`.

9. **Author the spec** following the **Spec Format** below. Every section is required unless explicitly marked optional.

   **Critical sections that v2 specs lacked but v3 specs MUST have:**

   - **`## Type Surface`** — all types this milestone introduces, with full Rust signatures, `// proposed for <milestone>, built by this spec` annotations, file:line targets where they will live, and brief rationale per type.
   - **`## Test Promises`** — every test name with what it proves. Categorize as Unit / Negative / Edge / Corner / Adversarial / Property / Integration / Bench / Loom / Compile-fail. Include enough detail that the validator can run the test and tell PASS from FAIL.
   - **`## RED-GREEN-REFACTOR`** (optional but recommended for non-trivial milestones) — for the load-bearing test, walk through the failing test → minimum implementation → refactor cycle. Skip for simple specs where it adds no value.
   - **`## Design Grounding`** — explicit pointers to the binding ADR(s) and design doc(s), with the specific D-NNN decisions and §sections that constrain this work. Every architectural choice in the spec MUST trace to a D-NNN here.

10. **Save the spec in stages — never as one giant Write.** A single Write call carrying a full v3 spec body (often 50–90 KB / 15–30K output tokens) streams for 8–20+ minutes and is the dominant failure mode for this skill (an oversized streaming Write looks identical to a hang, and any interrupt loses all output). Assemble the spec on disk in sequenced calls so each call streams ≤5K output tokens, every call leaves a recoverable artifact on disk, and the user sees visible progress between calls.

    **Required sequence:**

    a. **Write the skeleton.** A single `Write` call to `SPEC_OUTPUT_DIRECTORY/<spec-filename>-v3.md` containing ONLY:
       - Title heading
       - The Status / Spec Version / Author / Date / Code Baseline block
       - The EXECUTION DIRECTIVE block
       - All required `## ★` section headers with a single-line `<!-- to be filled in step 10b -->` placeholder under each
       - The `## Build Evidence` placeholder section with `> **Status:** DRAFT (will be filled by spec-updater after /build_v3 completes)`

       Output budget: ≤2KB. This call must complete in seconds. After it returns, the file exists on disk; the Stop-hook validator will block on missing content but the skeleton itself is recoverable across crashes.

    b. **Fill each major section with its own `Edit` call.** Replace the placeholder under each section header. One `Edit` per section, in this order: Design Grounding → Scope → Type Surface → Test Promises → (RED-GREEN-REFACTOR if used) → Step by Step Tasks → Acceptance Criteria → Validation Commands → Team Orchestration. Between calls, emit a short single-line status to the user (e.g., `wrote § Type Surface (12 types)`) so the user can distinguish progress from a hang.

       Output budget per call: target ≤5K tokens. If a section would exceed that (typically `## Step by Step Tasks` and `## Test Promises` for medium/complex specs), split it into multiple sequential `Edit` calls — first replace the placeholder with the early subsections, then `Edit` again to append later subsections. Never let a single tool call carry more than ~5K tokens of new content.

    c. **Verify spec internal consistency.** After all sections are filled, re-read the spec and check:
       - Every type in `## Type Surface` has a corresponding `## Step by Step Tasks` task that builds it
       - Every test in `## Test Promises` has a corresponding task or is bundled into a clear test-construction task
       - Every validation command in `## Validation Commands` is something the validator agent can execute
       - Every acceptance criterion in `## Acceptance Criteria` has either a validation command that proves it OR a manual verification step explicitly noted
       - Every task has an `Assigned To` matching a name in `### Team Members`
       - Every task that should run after another has a `Depends On` reference
       - No `<!-- to be filled -->` placeholders remain

       Fix any drift via additional targeted `Edit` calls.

11. **Report.** Follow the `Report` section below.

## Spec Format

The v3 spec format. Required sections marked with **★**.

```md
# <Milestone or sub-task title>

> **Status:** DRAFT
> **Spec Version:** v3 (unified TDD + build orchestration)
> **Author:** plan_to_build_v3
> **Date:** YYYY-MM-DD
> **Code Baseline:** <git short SHA from `git rev-parse --short HEAD`>

> **EXECUTION DIRECTIVE**: This is a team-orchestrated spec.
> **FORBIDDEN**: Direct implementation (Edit, Write, NotebookEdit) by the main agent. If you are the main conversation agent and a user asks you to implement this spec, you MUST invoke `/build_v3 specs/<this-filename>.md` -- do NOT implement it yourself.
> **REQUIRED**: Execute ONLY via the `/build_v3` command, which deploys team agents.

## ★ Design Grounding

- **Binding ADRs:**
  - <ADR path> — D-NNN decisions that constrain this spec: <list>
- **Design Doc:**
  - <design doc path>, sections §X.Y — <what this section locks>
- **Amendments / Drift:**
  - <if any amendments apply, point to them and note authority>
- **Code Baseline:**
  - This spec is grounded in commit <git short SHA>. file:line references below are verified at this commit.

## ★ Scope

### What this spec builds
<Crisp 3-5 sentences. Use active voice. Reference the design grounding for "why."

Example: "Builds the IamSubsystem foundation for OpsRamp's agent identity surface (per ADR-009 D-001). Introduces IamError, IamConfig, IamSubsystem types in tests/fakes/src/iam/ and refactors FakeWorld::router() into a builder pattern. Acceptance: cargo build clean, cargo clippy -D warnings clean, legacy FakeWorld::start() callers continue to work.">

### What this spec does NOT build
<Explicit deferrals. Reference future milestones or specs that will pick up the deferred work.

Example: "Does not implement the multi-issuer signing registry (deferred to MX.1). Does not implement DPoP verification (MX.3). Does not implement RFC 8693 token exchange (MX.2).">

### Estimated complexity
- **LOC:** <range, e.g., ~300-400>
- **Tests:** <count, e.g., 4 tests across 1 unit module>
- **Time:** <range, e.g., 0.5-1 day>
- **Complexity flag:** <foundation | medium | complex | edge>

## ★ Type Surface

All types this spec introduces, with full Rust signatures and target locations. **For every type with a non-trivial failure surface, you MUST include a `### <TypeName> — Failure Surface` block immediately after the type's signature (see "Failure Surface enumeration" below).** The validator blocks the spec if a failure-surface-bearing type lacks its enumeration.

### `<TypeName>` (proposed for <milestone>, built by this spec)

```rust
// Target: tests/fakes/src/iam/error.rs (new file)
// Verified design grounding: ADR-009 §3.2.10, phase-2a-MX-design.md §3.2.10

#[derive(Debug, thiserror::Error)]
pub enum IamError {
    #[error("missing required parameter: {0}")]
    MissingParameter(String),
    // ... all variants with full annotations
}

impl IamError {
    /// OAuth-RFC-compliant error code (returned to the client).
    pub fn code(&self) -> &'static str { ... }

    /// HTTP status code per design §9.2.
    pub fn status(&self) -> u16 { ... }
}

impl axum::response::IntoResponse for IamError {
    fn into_response(self) -> axum::response::Response { ... }
}
```

**Why this type:** <1-2 sentences explaining the role>. **Rationale:** <reference to D-NNN>.

### `<TypeName>` — Failure Surface

<Mandatory whenever the type has a non-trivial failure surface. Enumerate every way the type can fail, be misused, or interact pathologically with state. Each bullet maps to one test in `## Test Promises`. Do NOT describe happy-path behavior here.>

Example for `IamError`:
- malformed: empty error code string (must be rejected at construction)
- malformed: error code with non-OAuth-grammar characters
- variant-specific: `WWW-Authenticate: DPoP` header set ONLY on the `UseDpopNonce` variant, not all errors
- exhaustiveness: every variant has a status() match arm (compile-fail test if missing)

Example for `IamConfig`:
- TTL of zero is rejected at load
- TTL exceeding sanity bound (e.g., > 1 year) is rejected
- signing key path that doesn't exist returns a clear error
- iss URL that is not HTTPS is rejected
- iss URL that is malformed is rejected

Example for `IamSubsystem`:
- two cleanup tasks fire concurrently — registry serializes correctly
- cleanup task panics — subsystem survives, panic is logged
- legacy `FakeWorld::start()` called concurrently with router builder — no double-init

<Repeat for each new type. Skip the Failure Surface block ONLY for types with truly trivial failure surfaces (e.g., a `pub type Foo = u32;` alias or a marker struct).>

<Repeat the type signature + Failure Surface block for each new type the spec introduces.>

### Existing types this spec consumes (not modified)
- `<existing type>` at `<file:line>` — used because <reason>
- ...

### Existing types this spec extends (modified)
- `<existing type>` at `<file:line>` — extension is <description of change>; preserves the existing API contract per <D-NNN reference>

## ★ Test Promises

All tests this spec adds, organized by category. Every test name follows the convention `<milestone>_<descriptor>` (e.g., `mx0_iamerror_oauth_codes_are_rfc_compliant`).

### Unit tests (<count>)
| Test name | Target file | What it proves |
|---|---|---|
| `<test_name_1>` | `<test file path>` | <one-sentence proof statement> |
| ... | ... | ... |

### Negative tests (<count>) — RFC non-conformance, malformed input
| Test name | Target file | What it proves |
|---|---|---|
| ... | ... | ... |

### Edge tests (<count>) — boundary conditions
<table>

### Corner tests (<count>) — concurrent / multi-resource scenarios
<table>

### Adversarial tests (<count>) — security properties
<table>

### Property tests (<count>) — invariants
<table>

### Integration tests (<count>) — cross-module
<table>

### Bench tests (<count>) — perf budgets
<table>

### Loom tests (<count>) — concurrency interleavings
<table>

### Compile-fail tests (<count>) — type-system enforcement
<table>

### Total: <sum>

## RED-GREEN-REFACTOR (optional)

For load-bearing tests where the test-first cycle adds value, walk through:

### `<load_bearing_test_name>`

**RED — write the failing test:**
```rust
// tests/<file>.rs
#[test]
fn <test_name>() {
    // ... test body that exercises the unbuilt API
}
```

**GREEN — minimum implementation to pass:**
<describe the smallest code that makes the test pass — types, functions, error variants>

**REFACTOR — extract shared helpers:**
<describe what gets factored after green — error helpers, test fixtures, etc.>

**Why test-first matters here:** <1-2 sentences explaining what writing the test first surfaces that hand-coding wouldn't>.

(Skip this section entirely for simple specs where RGR adds nothing.)

## ★ Step by Step Tasks

These tasks are executed by self-organizing agents. Agents discover and claim tasks autonomously from the shared task list. Each task description must be exhaustive — agents cannot ask for clarification.

Every task MUST have:
- **Task ID** (kebab-case, unique within this spec)
- **Role** (`builder` | `validator` | `spec-updater` | `design-updater`)
- **Depends On** (Task IDs or "none")
- **Assigned To** (matching a name in `### Team Members`)
- **Description** containing `## Type Surface Reference`, `## Test Promises Reference`, `## What to do`, `## Files to modify`, `## Acceptance criteria`, `## Validation command`

### 1. <First Task Name>
- **Task ID**: <unique-kebab-case-id>
- **Role**: builder
- **Depends On**: none
- **Assigned To**: <builder name from Team Members>
- **Description**: |
    <EXHAUSTIVE description — everything the agent needs to complete this task autonomously>

    ## Design Grounding
    - ADRs: <list>
    - Design doc sections: <list>
    - Specifically: <D-NNN decisions that constrain this task>

    ## Type Surface Reference
    - From `## Type Surface` section above:
      - `<TypeName>` — at `<target file:line>` with full signature
      - <list every type this task creates>

    ## Test Promises Reference
    - From `## Test Promises` section above, this task produces:
      - `<test_name_1>` — `<test file>` — <one-line>
      - <list every test this task creates>

    ## What to do
    <step-by-step actions>

    ## Files to modify
    - `<file path>` — <exact changes>

    ## Code patterns to follow
    <reference established patterns from design doc and existing similar code, e.g., "Phase 1 IdentityError pattern at src/identity/error.rs:96-145">

    ## Acceptance criteria
    - <specific, verifiable criterion>

    ## Validation command
    `<command to verify this specific task>`

### 2. <Second Task Name>
<same exhaustive format>

### N. Validate-all
- **Task ID**: validate-all
- **Role**: validator
- **Depends On**: <all previous builder Task IDs>
- **Assigned To**: <validator name from Team Members>
- **Description**: |
    Run all validation commands and verify all acceptance criteria.

    ## Design Grounding
    - This validation enforces every D-NNN constraint listed in `## Design Grounding`.

    ## Validation Commands
    <list every command from `## Validation Commands`>

    ## Acceptance Criteria
    <list every criterion from `## Acceptance Criteria`>

### N+1. Update design doc (if medium/complex)
- **Task ID**: update-design-<domain>
- **Role**: design-updater
- **Depends On**: validate-all
- **Assigned To**: design-updater
- **Description**: |
    Update `docs/design/<domain>.md` to reflect what was actually built.

    ## Target Design Doc
    <path>

    ## Spec File
    specs/<this-spec-filename>.md

    ## Scope
    <which sections of the design doc need updating>

    ## What to Record
    Read git diff HEAD~1 HEAD, then changed source files, then existing design doc.
    Update `## Current Design` to match implementation.
    Append a `## Design Decisions` entry per non-trivial choice made in this build.
    Every claim must cite file:line from actual code.

## ★ Acceptance Criteria

<Numbered, measurable criteria. Each must be verifiable by either a validation command or explicit manual check.>

- AC-1: <criterion>
- AC-2: <criterion>
- ...

## ★ Validation Commands

Execute these commands to validate the spec is complete:

```bash
# Build clean
cargo build --workspace
# All tests pass
cargo test --workspace
# Clippy clean
cargo clippy --workspace -- -D warnings
# Specific tests for this spec
cargo test --test <test_target> -- <test_pattern>
# Specific custom checks
<other commands>
```

Each command's expected outcome is clear from the acceptance criteria.

## ★ Team Orchestration

`/build_v3` deploys exactly what is listed in `### Team Members`. Agents self-organize around the task list.

### ★ Team Members

- Builder
  - Name: <unique name, e.g., "builder-1">
  - Role: <focus area>
  - Agent Type: builder (or specialized type from `.claude/agents/team/`)
- <add more builders for parallel work>
- Validator
  - Name: validator
  - Role: Validates all acceptance criteria and runs validation commands
  - Agent Type: validator
- Spec Updater
  - Name: spec-updater
  - Role: Writes Build Evidence into this spec file after all tasks complete
  - Agent Type: spec-updater
- Design Updater (optional, for medium/complex specs)
  - Name: design-updater
  - Role: Updates docs/design/<domain>.md after build completes
  - Agent Type: design-updater

## Build Evidence

> **Status:** DRAFT (will be filled by spec-updater after /build_v3 completes)

<This section is initially empty. After `/build_v3` runs, the spec-updater agent fills it with:
- Test results table
- Validation commands table (PASS/FAIL with evidence)
- Acceptance criteria verification
- Files changed table
- Build metadata (git commit, branch, timestamp)
- Deviations from spec, if any>

## Notes

<Optional. Anything that doesn't fit elsewhere — known risks, follow-up work, related specs.>
```

## Authoring Heuristics

These guide the spec author (you) when writing v3 specs:

### Type Surface — be precise

- Use full Rust signatures, not pseudocode
- Annotate every new type with `// proposed for <milestone>, built by this spec`
- Cite the design doc section that locks each type's shape
- Distinguish "new types" (introduced) from "modified types" (extended)
- **Every failure-surface-bearing type MUST have a `### <TypeName> — Failure Surface` block** (see next heuristic). The validator blocks specs that introduce error types, config types, or stateful aggregators without these blocks.

### Failure Surface Inventory — author this BEFORE Test Promises

This is the load-bearing discipline that prevents happy-path-only specs.

**For every type with a non-trivial failure surface, enumerate every way it can fail or be misused before you write any tests.** Then `## Test Promises` is derived from this inventory — one test per non-trivial entry.

**A type has a non-trivial failure surface if any of these is true:**
- It is a `thiserror::Error` enum (every error variant has a corresponding "what produces this error" failure mode)
- It has an `IntoResponse` impl (HTTP status / header semantics can be wrong)
- It is a `Config` struct with TTL / path / URL / time fields (boundary inputs matter)
- It is a `Subsystem` or stateful aggregator (concurrency / panic isolation / lifecycle)
- It exposes a builder method like `router()` / `build()` (misuse / collision / back-compat)
- It implements cryptographic verification or signing (adversarial input)
- It bounds memory or has TTL eviction (capacity / eviction correctness)

**For each such type, write a `### <TypeName> — Failure Surface` block in `## Type Surface` listing failure modes as bullets.** Examples:

```
### IamError — Failure Surface
- malformed: empty error code string
- malformed: code with non-OAuth-grammar characters
- variant-specific: WWW-Authenticate header set ONLY for UseDpopNonce variant
- exhaustiveness: every variant has a status() match arm

### IamConfig — Failure Surface
- TTL of zero rejected at load
- signing key path missing returns clear error
- iss URL malformed rejected
- iss URL not HTTPS rejected

### IamSubsystem — Failure Surface
- two cleanup tasks fire concurrently — registry serializes
- cleanup task panic — subsystem survives
```

**Each non-trivial bullet must map to a test row in `## Test Promises`.** The hook validator detects failure-surface signals (thiserror::Error, Config, Subsystem, etc.) and blocks the spec if the matching test categories are empty.

### Test Promises — name every test, cover the failure surface

- Tests are named, not described in prose. Every test gets a row in a table.
- Name format: `<milestone>_<descriptor>`. Example: `mx0_iamerror_oauth_codes_are_rfc_compliant`.
- Categorize aggressively. Unit, Negative, Edge, Corner, Adversarial, Property, Integration, Bench, Loom, Compile-fail are distinct categories with distinct purposes.
- Total test count appears at the bottom of the section.
- **Every failure-mode bullet from the Failure Surface Inventory must have a corresponding test row.** Use the appropriate category — typically:
  - "malformed input rejected" → **Negative** test
  - "boundary value handled correctly" (TTL=0, capacity limit) → **Edge** test
  - "concurrent interleaving correct" → **Corner** test
  - "tampered/adversarial input rejected" → **Adversarial** test
  - "invariant holds across all inputs" → **Property** test
- **Target ≥30% of tests in failure-path categories** (Negative + Edge + Corner + Adversarial + Property combined). The validator emits a WARNING below this threshold; specs that introduce failure-surface-bearing types are HARD-BLOCKED if the matching category has zero tests.

### RED-GREEN-REFACTOR — only when it adds value

- Skip RGR for simple foundation specs where the test cycle is mechanical
- Include RGR for the load-bearing test in complex specs where the test design surfaces non-obvious requirements
- Don't write RGR walkthroughs for every test — pick the one or two that matter

### Step by Step Tasks — exhaustive descriptions

- Every task description must include `## Type Surface Reference`, `## Test Promises Reference`, `## Files to modify`, `## Validation command`
- The validator agent depends on the validation commands in `## Validation Commands` matching what tasks claim
- Tasks must be small enough that a single builder agent completes one in a single attempt

### Acceptance Criteria — verifiable

- Each criterion is either runnable (validation command proves it) or explicit-manual (the manual check is described inline)
- "It compiles" is fine. "It works" is not. Be specific.

### Prefix-cache-friendly section ordering — stable content first, volatile last

`/build_v3` deploys N builders that each `Read` this spec concurrently, and re-read it
across polling cycles. Model backends (Anthropic auto-cache; a RadixAttention inference
server) cache on the longest common **token prefix from position 0** — one differing token
early discards the cache for everything after it. So author the spec **stable-first,
volatile-last**:

- Keep the immutable header (title, Spec Version, Author, Code Baseline) and the stable
  design content (`## Design Grounding`, `## Type Surface`, `## Test Promises`) at the top,
  in that order. These are what every builder shares — they must be byte-stable for the
  whole build.
- Keep the sections that get mutated during the build at the **bottom**. `## Build Evidence`
  is last by design (spec-updater rewrites it at the end). Do NOT introduce new
  mutated-during-build content above the stable design sections.
- Do NOT interpolate anything per-run (timestamps, run IDs, agent names) into the spec body
  above `## Build Evidence`. The `> **Status:**` line stays at the top and flips DRAFT→
  COMPLETE exactly once, post-validation — that single late edit is acceptable because every
  builder has finished reading by then; do not add other top-of-file mutations.

### Design grounding — every claim traceable

- If a spec says "use Ed25519 signing," the design grounding section MUST cite the D-NNN that locked Ed25519
- If a spec creates a new type, the design grounding MUST point to the §section that designed it
- If a spec deviates from the design, the deviation gets its own callout and rationale

## Report

After saving the spec, provide a concise report:

```
v3 Build Spec Created

Spec File:
  Path: specs/<filename>-v3.md
  Milestone: <name>
  Complexity: <flag>
  LOC budget: <range>
  Test count: <n>
  Time estimate: <range>

Design Grounding:
  - <ADR path> (D-NNN decisions: <list>)
  - <design doc path> (§sections: <list>)

Type Surface:
  - <count> new types
  - <count> modified types

Test Promises:
  - Unit: <n>, Negative: <n>, Edge: <n>, Corner: <n>, Adversarial: <n>
  - Property: <n>, Integration: <n>, Bench: <n>, Loom: <n>, Compile-fail: <n>
  - Total: <sum>

Team Composition:
  - <n> builders: <names>
  - 1 validator
  - 1 spec-updater
  - 1 design-updater (or "skipped — simple spec")

Task Graph:
  - <n> builder tasks
  - 1 validate-all task
  - 1 update-design task (or skipped)
  - 1 spec-update task (auto-added by /build_v3)

Next Step:
  /build_v3 specs/<filename>-v3.md
```
