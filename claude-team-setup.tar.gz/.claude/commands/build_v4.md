---
description: Execute a v4 build spec (unified TDD + orchestration + dynamic model routing) using an agent team — self-organizing off the shared task board when the session has one, lead-dispatched over SendMessage when it does not. v4 adds Model Routing — each agent deploys on the model slot its Model Class maps to, so one build can span Bedrock and local models; the leader resolves the binding, probes slot liveness, and applies a promote-only fallback before deploying.
argument-hint: [path-to-v3-spec]
model: opus
disallowed-tools: Write, Edit, NotebookEdit
---

# Build v4 (Agent Team, Unified Spec, Dynamic Model Routing)

You are the **team lead**. You build the task graph, deploy agents, then monitor for completion and exceptions. In task-board mode agents self-organize around the shared task list and you do NOT micromanage each task; in message-driven mode you hold the graph and dispatch each task (see step 2a). You NEVER write code directly.

The structural difference from `/build_v3` is **dynamic model routing**. v4 specs carry a `## Model Routing` section assigning every agent a Model Class (REASONING | STANDARD | MECHANICAL, derived from task shapes at planning time); you resolve class → model slot → physical backend at deploy time and pass `model: <slot>` on every agent deployment. One build can therefore span backends — e.g. REASONING builders on Bedrock, MECHANICAL agents on a local model — with the binding owned by the session's launcher, not the spec. v4 runs are also **delta-aware**: a freshness gate (Phase 1 step 2b) refuses COMPLETE or stale specs, and when a re-planned spec carries a `## Re-plan Delta`, builders validate UNCHANGED tasks before working them and skip the ones already green.

**Team lifecycle is implicit (harness change, verified against docs 2026-09-25, CLI ≥2.1.28x).** There are no `TeamCreate`/`TeamDelete` tools anymore. While `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` is set (settings.json `env` — re-read at every spawn, no restart needed), **any `Agent` call that passes a `name` launches that agent as a teammate** in the session's one implicit team (named `session-<first 8 chars of session id>`, directories auto-created under `~/.claude/teams/` and `~/.claude/tasks/`). Teams are torn down automatically when the session ends. The shared task board (`TaskCreate`/`TaskList`/`TaskUpdate`/`TaskGet`) is **conditionally available** — some sessions have it, some don't — so this command runs in one of two coordination modes, chosen at preflight (step 2a): **task-board mode** (agents self-organize off the shared list — the original v4 flow) or **message-driven mode** (the lead holds the task graph and dispatches each task over `SendMessage` when its dependencies complete — the docs-sanctioned coordination for sessions without Task tools). Model routing, binding verification, fix cycles, the retro, and the ledger write-back are identical in both modes.

## Variables

PATH_TO_SPEC: $ARGUMENTS
TEAM_MEMBERS: `.claude/agents/team/*.md`
GENERAL_PURPOSE_AGENT: `general-purpose`
MAX_FIX_CYCLES: 2
AGENT_POLL_INTERVAL_SECONDS: 10
SHUTDOWN_TIMEOUT_SECONDS: 60
SHUTDOWN_RETRY_INTERVAL_SECONDS: 15
SHUTDOWN_MAX_RETRIES: 2
TMUX_KILL_GRACE_SECONDS: 5

## Rules

- You are the team lead. You coordinate — you do NOT build.
- **Foreground presentation is the default.** Team agents run in VISIBLE tmux split panes the user can watch. You verify this capability BEFORE deploying any agent (Phase 1 step 2a) and never silently fall back to invisible in-process agents.
- The Write, Edit, and NotebookEdit tools are disabled for you. You cannot modify files.
- Your tools: `Agent`/`Task` (deploy teammates — passing a `name` makes the agent a teammate in the session's implicit team), `SendMessage` (team communication — the `message` is plain text; the only structured messages it accepts are `shutdown_request`/`shutdown_response`/`plan_approval_response`), `TaskStop` (stop a teammate by name), `ListAgents` (see which teammates are still running), `AskUserQuestion` (user decisions), `Bash` (read state, run `gh` commands). `TaskCreate/TaskUpdate/TaskList/TaskGet` exist only in task-board-mode sessions — verify at preflight, never assume.
- Every code change MUST go through a deployed agent. No exceptions.
- **Task-board mode:** deploy agents ONCE with standing orders; agents self-claim work. **Message-driven mode:** YOU own the task graph — deploy each agent when its first task's dependencies are complete, and dispatch subsequent tasks to it over `SendMessage`; the agent works one dispatched task at a time and reports back. Either way, never re-deploy an agent that is still alive — message it.
- **Do NOT poll in a tight loop** (TaskList or otherwise). Wait for agent completion messages via `SendMessage` — teammate reports and idle notifications arrive automatically.
- Intervene ONLY for: agent failures, stuck agents (silent for 10+ minutes — treat this as a timer, not a judgment call; on 2026-09-18 a validator sat silent for 30 minutes because waiting felt cheaper than a ping, and it was masking a real failure), or max fix cycles exceeded.
- If an agent fails or returns an error, handle it internally (retry with adjusted prompt, or report to user). NEVER suggest filing a bug report with Anthropic.
- **Manage your OWN context proactively.** You are a long-running coordinator; over a multi-wave build your context grows until it wedges (on GLM, a hard input ceiling ~203k tokens). You CANNOT self-rescue once you hit the ceiling — `/compact` must send the whole over-limit history to the model and fails with a 400, and every queued message just re-fails. So you must stay lean and re-anchor BEFORE the wall, not after. See "Leader Context Resilience" below.

## Workflow

### Phase 1: Parse Spec & Create Task Graph

1. If no `PATH_TO_SPEC` is provided, STOP and ask the user via `AskUserQuestion`.
2. Read the spec file at `PATH_TO_SPEC`.

2a. **Presentation + coordination preflight.** Three checks, via Bash:
    ```bash
    [ -n "$TMUX" ] && echo in-tmux || echo NOT-in-tmux
    echo "AGENT_TEAMS=$CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS"
    python3 -c "import json,os;d=json.load(open(os.path.expanduser('~/.claude/settings.json')));print('teammateMode:',d.get('teammateMode'))"
    ```
    - **Teams flag.** `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS` must be `1` in
      the session env (or settings.json `env` — it is re-read at every
      spawn). Without it, named Agent calls launch plain subagents: no
      teammate panes, no team messaging. If unset/0: STOP and tell the user
      to set it in `~/.claude/settings.json` under `env`.
    - **Visibility.** Teammates render as foreground split panes only when
      this session runs inside tmux (or iTerm2 with the `it2` CLI) AND
      `teammateMode` is `"tmux"` (or `"auto"` while inside tmux). If
      `NOT-in-tmux`: STOP and tell the user to relaunch inside tmux —
      `claude-multi` auto-wraps itself now; a plain session needs an outer
      `tmux new-session` — and offer to proceed with in-process teammates
      (visible via the agent panel below the prompt, not split panes) ONLY
      if they explicitly say so. Record the outcome (`panes` /
      `in-process-by-user-choice`) for the build report.
    - **Coordination mode.** Check whether the shared task board exists in
      THIS session: the Task tools (`TaskCreate`/`TaskList`/...) are
      conditionally registered. If your tool registry has them → run
      **task-board mode** (Phase 2/3/4 as written). If not → run
      **message-driven mode** (Phase 2-M, plus the Phase 3-M overrides to
      Phases 3–5 below); do NOT stop — this
      is a documented, supported configuration, not a degraded run.
      Announce the chosen mode to the user in one line.

    Also confirm `~/.claude/model-routing-ledger.md` is readable (the Read
    tool can be permission-blocked outside the repo — fall back to `cat`
    via Bash).

2b. **Freshness gate — refuse stale or already-built specs.**
    - If the spec's `> **Status:**` is COMPLETE, this spec was already built.
      STOP and report it, UNLESS the user's invocation says `rebuild: force`,
      OR the spec carries a `## Re-plan Delta` whose new baseline is not yet
      reflected in `## Build Evidence` — that is a legitimate delta re-run.
    - Compare the spec's `Code Baseline` to `git rev-parse --short HEAD`. If
      they differ, re-resolve the spec's `file:line` pins at HEAD via grep —
      all of them if ≤20, otherwise a 20-pin sample weighted toward Type
      Surface targets. Every pin resolving → record "baseline drifted
      <old>→<new>, pins verified" for the build report and proceed. ANY pin
      broken → the spec is stale: STOP and tell the user to re-run
      `/plan_to_build_v4` in re-plan mode pointing at this spec. Never deploy
      a team against a baseline the spec was not grounded on.
    - If the spec has a `## Re-plan Delta`, extract the task→Delta Status map
      now; you will thread it into task descriptions in Phase 2 and summarize
      delta execution in the build report.
3. **Verify v4 spec format.** Check for the required sections that distinguish v3 from v2:
   - `## Design Grounding`
   - `## Scope`
   - `## Type Surface`
   - `## Test Promises`
   - `## Model Routing` (v4 marker — if absent this is a v3 spec; STOP and tell the user to run it with /build_v3 or re-plan with /plan_to_build_v4)
   - `## Step by Step Tasks`
   - `## Acceptance Criteria`
   - `## Validation Commands`
   - `## Team Orchestration` containing `### Team Members`
   - `## Build Evidence` (initially empty placeholder)
   
   If any required section is missing, STOP and report the missing sections to the user. Do NOT attempt to deploy with an incomplete spec.

4. **Extract orchestration data:**
   - `### Team Members` — builder/validator/spec-updater/design-updater names, agent types, count
   - `## Step by Step Tasks` — task IDs, names, roles, dependencies, descriptions
   - `## Acceptance Criteria` — measurable success conditions
   - `## Validation Commands` — commands the validator runs
   - `## Design Grounding` — ADR/design-doc pointers; you'll surface these to agents in their standing orders
   - `## Model Routing` — the agent→Model Class assignment table and the fallback policy; every task's `**Model Class**` field must agree with its agent's class (if they conflict, STOP and report — the spec failed its own validator's contract)

5. **Build an in-memory list of all builder agent names** from the Team Members section. You will need this list for wakeup messages (task-board mode) and dispatches (message-driven mode) in Phase 4.

### Phase 2: Populate Task List (task-board mode only — message-driven mode: skip to Phase 2-M)

6. **There is no TeamCreate.** The session's one implicit team already exists (`session-<id-prefix>`, auto-created at session start while the teams flag is on). Confirm its directory exists via `ls ~/.claude/teams/` and record the team name for the build report. Do not pre-author or hand-edit its `config.json` — the harness owns it.

7. For EVERY task in `## Step by Step Tasks`:
   a. Call `TaskCreate` with:
      - `subject`: The task name (from the h3 header)
      - `description`: The FULL task description from the spec — include ALL context, file paths, code patterns, acceptance criteria, validation commands, AND the references to `## Type Surface` and `## Test Promises` from the spec. Prefix the description with `role: builder`, `role: validator`, `role: spec-updater`, or `role: design-updater` as specified in the task. This is how agents filter for their work. When the spec carries a `## Re-plan Delta`, also include the task's `Delta Status: <UNCHANGED|AMENDED|NEW>` line — builders key validation-first skipping off it.
      - `activeForm`: Present-continuous form of the task name
   b. Record the mapping: spec task ID → created TaskCreate ID

8. For EVERY task with dependencies (`Depends On` is not "none"):
   - Call `TaskUpdate(taskId: "<created-id>", addBlockedBy: [<dependency-created-ids>])` using the mapping from step 7b.

9. **Auto-create spec-update task** (runs last, after all other tasks):
   - Call `TaskCreate` with:
     - `subject`: "Update spec with build evidence"
     - `activeForm`: "Updating spec with build evidence"
     - `description`: A `role: spec-updater` description containing:
       - `## Spec File` — the path to `PATH_TO_SPEC`
       - `## Instructions` — "Re-run all validation commands, verify all acceptance criteria, and write a `## Build Evidence` section into the spec file. Replace the existing `## Build Evidence` placeholder with the real evidence."
       - `## Validation Commands` — copy ALL validation commands from `## Validation Commands` in the spec
       - `## Acceptance Criteria` — copy ALL acceptance criteria from `## Acceptance Criteria` in the spec
   - Record its task ID as `spec-updater-task-id`
   - Call `TaskUpdate(taskId: "<spec-updater-task-id>", addBlockedBy: [<ALL-other-task-ids>])` so it runs only after every other task completes.

### Phase 2-M: Build the Task Graph In-Memory (message-driven mode only)

6-M. No task board exists, so YOU are the task board. Build an in-memory task
     graph from `## Step by Step Tasks`: for each task record
     `{task_id, role, assigned_to, model_class, depends_on, delta_status,
     full_description, validation_command, state}` where state starts at
     `pending`. Keep it as a compact table you re-derive from the SPEC (which
     is on disk) rather than a blob you carry verbatim — per Phase 4b, the
     durable record is the spec + git, not your context.

7-M. Dispatch discipline replaces self-claiming:
     - A task becomes DISPATCHABLE when every `depends_on` entry is
       `completed`.
     - You dispatch a task by `SendMessage` to its assigned agent (deploying
       the agent first if this is its first task — see Phase 3-M). The
       dispatch message contains the task ID, its Delta Status (if any), and
       the pointer: "Full description in the spec at <PATH_TO_SPEC>, task
       <task-id> under ## Step by Step Tasks — read it from the spec, do not
       work from this message alone."
     - The agent reports completion via SendMessage; you mark the task
       `completed`, check what became dispatchable, and dispatch next.
     - One in-flight task per agent at a time. Delta rules still apply:
       dispatch an UNCHANGED task with the instruction to run its validation
       command first and skip-green if it passes.

8-M. The auto spec-update task (step 9's content) is simply the LAST entry in
     your in-memory graph, blocked by all others — same content, no
     TaskCreate.

### Phase 2b: Resolve Model Routing (class → slot → live backend)

9a. **Map classes to slots** (fixed): REASONING→`opus`, STANDARD→`sonnet`,
    MECHANICAL→`haiku`. From `## Model Routing`, build the in-memory table
    `agent → class → slot`.

9b. **Discover the physical binding.** Via Bash:
    `env | grep -E 'ANTHROPIC_(BASE_URL|MODEL|SMALL_FAST_MODEL|DEFAULT_(OPUS|SONNET|HAIKU)_MODEL)' | sort`
    Record what each slot resolves to. Unset `ANTHROPIC_DEFAULT_*` vars mean
    the slots resolve to the provider's stock models — a valid all-one-backend
    binding (classes then express cost tiering only), not an error.

9c. **Probe slot liveness — proxy sessions only.** If `ANTHROPIC_BASE_URL`
    points at a local proxy (`127.0.0.1`/`localhost`), probe each DISTINCT
    bound model with a 1-token request:
    ```bash
    curl -s -o /dev/null -w '%{http_code}' --max-time 20 \
      -X POST "$ANTHROPIC_BASE_URL/v1/messages" \
      -H "x-api-key: $ANTHROPIC_AUTH_TOKEN" \
      -H "anthropic-version: 2023-06-01" -H "content-type: application/json" \
      -d '{"model":"<bound-model>","max_tokens":1,"messages":[{"role":"user","content":"ping"}]}'
    ```
    `200` = live. Non-200 = that slot's backend is down. A 401/403 on a
    Bedrock-backed route usually means expired SSO — surface the exact fix to
    the user: `aws sso login --profile ClaudeCode`. When the session is
    direct-to-provider (no local proxy), skip probing — slot liveness equals
    session liveness.

9c2. **Verify the binding empirically — teammates are the ground truth.**
    Steps 9b/9c observe only the LEAD's session. Teammates are separate
    processes and may NOT inherit the launcher's env (`ANTHROPIC_BASE_URL`,
    `ANTHROPIC_DEFAULT_*`) — observed 2026-09-04 (routing-cal, ledger RL-001):
    under `claude-multi` the lead's curl probes reached deepseek-v4-flash,
    while teammates deployed with `model: haiku` actually ran on stock
    `claude-haiku-4-5`. The announced binding was fiction until a human
    noticed. So measure what a teammate REALLY gets before announcing:
    - For each DISTINCT slot the spec uses, spawn a one-shot UNNAMED probe
      subagent on that slot (`model: <slot>`, NO `name` — while the teams
      flag is on, a named Agent call becomes a persistent teammate and
      would occupy a pane; an unnamed probe runs and exits clean. Prompt:
      "Run `true` via Bash, report done, do nothing else."). It costs
      seconds and a few hundred tokens.
    - Read the probe's ACTUAL model from its session transcript — the only
      reliable source (model self-report is not; the team config records
      only the slot label):
      ```bash
      cd ~/.claude/projects/<project-dir> && \
        grep -o '"model":"[^"]*"' "$(ls -t *.jsonl | head -1)" | sort | uniq -c
      ```
      Match transcript to probe by recency, or by grepping for the probe's
      prompt text when several agents ran concurrently.
    - Freeze `slot → physical model` from THESE observations, not from 9b.
      A probe that fails to spawn or errors marks that slot dead for 9d.
    - If all slots resolve to the SAME physical model, do not abort: record
      "single-backend binding — classes express cost tiering only" and note
      in `routing_signals` that calibration verdicts are correspondingly
      weakened. This is the common case for users without a multi-backend
      launcher, and the flow works unchanged.

9d. **Apply the fallback policy — promote, never demote.** For each class
    whose slot is dead: move its agents one class up
    (MECHANICAL→STANDARD→REASONING), re-checking liveness per step and
    honoring spec-specific overrides in `### Fallback policy`. If a capped
    agent (one the spec forbids promoting) has no live slot, STOP and ask the
    user. If the REASONING slot itself is dead, STOP and report — there is
    nothing safe to promote into. Log every promotion explicitly:
    `agent builder-2: MECHANICAL→STANDARD (haiku slot upstream dead)`.
    Freeze the resolved table `agent → class → slot → physical model
    (transcript-verified per 9c2)` for Phase 3 and the build report.

9e. **Announce the routing to the user BEFORE deploying** — transparency at
    the moment of choice, not after. Print one compact table: agent, class,
    slot, physical model (transcript-verified per 9c2 — never announce an
    unverified binding as fact), and the spec's one-line rationale (from the
    `## Model Routing` assignment table), plus any promotions applied in 9d
    and any ledger lessons the spec says it applied
    (`### Prior-lesson adjustments`). Also start an in-memory
    `routing_signals` log — you will append to it all through Phase 4 and it
    becomes the retro.

### Phase 3: Deploy Agents with Standing Orders

Every agent prompt in this phase MUST carry this line near the top: "Your
shell starts in the HOME directory — teammates inherit neither the lead's
environment (RL-001) nor its working directory. Use absolute paths for every
command and file operation." Observed 2026-09-18: panes open at `$HOME`, and
a relative write lands the work there, not in the repo.

10. Deploy builder agents — one `Agent` call per builder listed in `### Team Members`:
    - `subagent_type`: The agent type from the spec (e.g., `"builder"` or a specific agent from TEAM_MEMBERS)
    - `name`: The builder name from the spec (e.g., `"builder-1"`). **The `name` is what makes this a teammate** — the harness's `team_name` param is deprecated/ignored; the session has one implicit team and every named agent joins it. Do NOT pass `isolation` (it forces a plain subagent).
    - `model`: this builder's RESOLVED slot from Phase 2b (e.g., `haiku`). This is the entire routing mechanism at deploy time — do not omit it, or the agent silently inherits the session model and the routing plan is fiction.
    - **Message-driven mode:** deploy a builder only when its FIRST task is dispatchable, with the prompt assembled per Phase 3-M (MESSAGE-DRIVEN ORDERS instead of STANDING ORDERS, first dispatch in a DISPATCH block).
    - Teammates always run CONCURRENTLY in their own sessions — deployment never blocks the lead. Visibility is governed by `teammateMode` (verified in the presentation preflight), NOT by any deployment flag: with `teammateMode: "tmux"` and the session inside tmux, this agent appears in its own FOREGROUND split pane.
    - `prompt`: This template is written **identity-last** for prefix-cache reuse:
      the STANDING ORDERS body below is byte-identical for every builder, so the
      model backends (Anthropic auto-cache, or a RadixAttention server) can reuse
      the cached prefix across all builders and across runs. Substitute `<name>`
      and `<team-name>` **only inside the IDENTITY block at the very end** — leave
      the body verbatim (it refers to "your name" generically):
      ```
      You are executing a v4 build spec. v4 specs contain:
      - `## Design Grounding` — the ADRs and design docs that constrain this work
      - `## Type Surface` — every type to be built, with full Rust signatures
      - `## Test Promises` — every test to be written, with what each proves
      - `## Step by Step Tasks` — your atomic units of work

      When you read a task description, it will reference `## Type Surface` and
      `## Test Promises` in the spec. Treat those as authoritative for the SHAPE
      of what you build (types, signatures, test names). The `## What to do`
      section is your action checklist.

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks
      2. Filter the results: only consider tasks where BOTH are true:
         - description starts with "role: builder"
         - description contains "Assigned To: <your name>" (see IDENTITY block below)
      3. If matching tasks exist: claim the lowest-ID one via TaskUpdate(owner: "<your name>", status: in_progress)
      4. Read full details via TaskGet
      4a. VALIDATION-FIRST for unchanged work: if the task description contains
          "Delta Status: UNCHANGED", run the task's `## Validation command`
          BEFORE doing any work. If it passes: mark the task completed via
          TaskUpdate and report "task <id>: already satisfied — validation
          green, no work performed", then go back to step 1. If it fails:
          note the failed command output in one line and execute the task
          normally — the UNCHANGED claim was wrong, and your completion
          report MUST flag it as "wrong UNCHANGED claim".
      5. Execute the work
      6. Mark completed via TaskUpdate(status: completed)
      7. Send completion report to team-lead via SendMessage. Paste the LAST
         LINE of EVERY leg of your validation command verbatim — the test
         runner AND the linter. A report only proves the gates it quotes: on
         2026-09-18 a builder reported done on a green test suite while six
         unquoted lint errors waited to cost a fix cycle.
      8. Go back to step 1
      9. If no tasks match your criteria:
         a. CHECK MAILBOX FIRST — before waiting, check for any incoming messages
         b. If you have a "shutdown_request" message: send "shutdown_response" with the matching request_id and stop IMMEDIATELY (do not poll again)
         c. If you have a "wakeup" message: go back to step 1 immediately (skip the wait)
         d. Otherwise: wait 10 seconds, then go back to step 1

            IDLE HEARTBEAT: Every 3rd idle cycle (i.e., every ~30 seconds while waiting),
            send a brief plain-text "still alive" message to team-lead so liveness is
            tracked even when no task work is happening. Example: "heartbeat: idle, no
            matching tasks." This is best-effort — do not fail if SendMessage errors.
      10. Continue polling indefinitely — do NOT self-terminate
      11. When you receive a "shutdown_request" from team-lead at ANY point: respond
          with `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          via SendMessage and stop immediately. Do NOT finish current wait cycle first.
          Do NOT process additional task work after responding.

      IMPORTANT — Shutdown protocol:
      - Always echo the exact `request_id` from the incoming shutdown_request.
      - If you receive a SECOND shutdown_request (e.g., the first response was lost),
        re-send the shutdown_response with the new request_id and stop again. Do not
        interpret a duplicate shutdown_request as a request to resume.

      IMPORTANT — Task ownership:
      - Only claim tasks assigned to YOU: "Assigned To: <your name>" (see IDENTITY block below)
      - Do NOT claim tasks assigned to other builders, even if they are unblocked and have role: builder

      IMPORTANT — v4 spec context:
      - Before executing your first task, READ the spec file at the path your
        task description references. The `## Type Surface` and `## Test Promises`
        sections in the spec are the authoritative shape contract.
      - The task description references specific entries in `## Type Surface`
        and `## Test Promises` — do NOT improvise types or test names. Use exactly
        what the spec specifies.
      - If a task description and the spec's Type Surface conflict, the spec wins.
        Surface the conflict in your completion report.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.

      ----------------------------------------------------------------------
      IDENTITY (the ONLY per-agent substitution — everything above is shared):
      - Your name is "<name>".
      - Your team is "<team-name>".
      - Claim ONLY tasks whose description contains: Assigned To: <name>
      ----------------------------------------------------------------------
      ```

11. Deploy the validator agent:
    - `subagent_type`: `"validator"` (or the agent type from the spec)
    - `name`: The validator name from the spec (e.g., `"validator"`) — named ⇒ teammate, same as builders
    - `model`: the validator's resolved slot from Phase 2b (STANDARD→`sonnet` unless promoted)
    - **Message-driven mode:** do NOT deploy the validator at Phase 3 at all — deploy it when `validate-all` becomes dispatchable (all builder tasks complete), with its prompt assembled per Phase 3-M. This extends the Wave-2 deferred-deployment logic one agent further; the RL-002 10-minute wall-clock rule still applies from its deploy time.
    - Teammates always run CONCURRENTLY in their own sessions — deployment never blocks the lead. Visibility is governed by `teammateMode` (verified in the presentation preflight), NOT by any deployment flag: with `teammateMode: "tmux"` and the session inside tmux, this agent appears in its own FOREGROUND split pane.
    - `prompt`: Identity-last (same rationale as the builder template — substitute
      `<name>`/`<team-name>` ONLY in the IDENTITY block at the end):
      ```
      You are validating a v4 build spec. v4 specs contain `## Type Surface`,
      `## Test Promises`, `## Acceptance Criteria`, and `## Validation Commands`.
      Your job is to confirm the implementation matches all four.

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks with role: validator
      2. Claim the lowest-ID matching task via TaskUpdate(owner: "<your name>", status: in_progress)
      3. Read full details via TaskGet
      4. Read the spec file at the path the task description references.
         Cross-check `## Acceptance Criteria` and `## Validation Commands`.
      5. Run ALL validation commands and check ALL acceptance criteria.
         Report something to team-lead within 10 minutes of claiming — a
         verdict, a partial result, or the exact command you are stuck on.
         Past that the lead kills you and runs the commands itself.
      6. Additionally: verify the implementation matches `## Type Surface` —
         for each new type, confirm the file exists, the signature matches,
         the annotations are correct.
      7. Additionally: verify each test in `## Test Promises` exists, runs,
         and passes (test name → test outcome).
      8. If PASSED: mark completed, send "Validation PASSED: <task-id>" to team-lead
      9. If FAILED and fix_cycle < 2:
         a. Create a fix task (role: builder, Assigned To: <original-builder-name>) via TaskCreate
         b. Create a re-validation task (role: validator) blocked by the fix task via TaskCreate + TaskUpdate
         c. Send "Validation FAILED: fix task <fix-task-id> created for <builder-name>" to team-lead
      10. If FAILED and fix_cycle >= 2: mark completed with failure,
          send "Validation FAILED — max cycles exceeded, needs intervention" to team-lead
      11. Go back to step 1
      12. If no tasks match:
          a. CHECK MAILBOX FIRST — before waiting, check for any incoming messages
          b. If you have a "shutdown_request" message: send "shutdown_response" with the matching request_id and stop IMMEDIATELY
          c. If you have a "wakeup" message: go back to step 1 immediately (skip the wait)
          d. Otherwise: wait 10 seconds, then go back to step 1

             IDLE HEARTBEAT: Every 3rd idle cycle (~30 seconds), send a brief plain-text
             heartbeat to team-lead. Best-effort.
      13. Continue polling indefinitely — do NOT self-terminate
      14. When you receive a "shutdown_request" from team-lead at ANY point: respond
          with `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          via SendMessage and stop immediately.

      IMPORTANT — Shutdown protocol:
      - Always echo the exact `request_id` from the incoming shutdown_request.
      - If you receive a duplicate shutdown_request, re-respond and stop again — do not resume.

      IMPORTANT: Only claim tasks where the description starts with "role: validator".
      Skip any task with "role: builder", "role: spec-updater", or "role: design-updater".
      You are READ-ONLY. You CANNOT write or edit files. Create fix tasks for builders instead.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.

      ----------------------------------------------------------------------
      IDENTITY (the ONLY per-agent substitution — everything above is shared):
      - Your name is "<name>".
      - Your team is "<team-name>".
      ----------------------------------------------------------------------
      ```

12. **DO NOT deploy the spec-updater agent yet.** Spec-updater is **deferred-deployment** — it has no work to do until `validate-all` completes successfully, and deploying it during Phase 3 burns tokens on idle heartbeats throughout the entire builder phase. Phase 1 and Phase 2A retrospectives identified this as wasted spend.

    Instead, store the deployment template below in your in-memory state under the key `deferred_spec_updater`. You will deploy this agent in **Phase 4 Wave 2**, immediately after the validator reports `Validation PASSED: validate-all`.

    **Spec-updater deployment template** (do NOT execute yet — store for Phase 4):
    - `subagent_type`: `"spec-updater"` (from TEAM_MEMBERS)
    - `name`: `"spec-updater"` (named ⇒ teammate)
    - `model`: spec-updater's resolved slot from Phase 2b (MECHANICAL→`haiku` unless promoted)
    - Teammates always run CONCURRENTLY in their own sessions — deployment never blocks the lead. Visibility is governed by `teammateMode` (verified in the presentation preflight), NOT by any deployment flag: with `teammateMode: "tmux"` and the session inside tmux, this agent appears in its own FOREGROUND split pane.
    - `prompt`: Identity-last (substitute `<team-name>` ONLY in the IDENTITY block
      at the end; the body is shared across runs):
      ```
      You write Build Evidence into v4 spec files. v4 specs have a
      `## Build Evidence` placeholder section that you replace with real
      evidence after all builder + validator tasks complete.

      You are being deployed in Wave 2 — validate-all has already passed.
      Your task should be unblocked and waiting in the queue.

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks with role: spec-updater
      2. Claim the lowest-ID matching task via TaskUpdate(owner: "spec-updater", status: in_progress)
      3. Read full details via TaskGet
      4. Read the spec file specified in `## Spec File`
      5. Re-run each validation command from `## Validation Commands` —
         capture PASS/FAIL with output
      6. Verify each acceptance criterion from `## Acceptance Criteria` —
         capture evidence (file:line, command output, etc.)
      7. Replace the `## Build Evidence` placeholder section in the spec
         with a populated version containing:
         - Test results table (one row per test category)
         - Validation commands table (Command | Result | Evidence)
         - Acceptance criteria verification (one row per AC)
         - Files changed table (File | Action | Verified)
         - Build metadata: git commit, branch, timestamp, deviations (if any)
         - When the spec carries a `## Re-plan Delta`: a `### Delta Execution`
           subsection — executed (AMENDED/NEW) vs skipped-green (UNCHANGED) vs
           wrong-UNCHANGED counts, copied from your task description
         - A `### Model Routing Retro` subsection: transcribe VERBATIM the
           `## Model Routing Retro (lead's assessment — transcribe verbatim)`
           block from your task description (initial choice → observed →
           verdict → lesson, per agent). Do not soften or re-judge it.
      7a. Append the retro's distilled lessons to
          `~/.claude/model-routing-ledger.md` (create it in that file's own
          documented format if missing): one `### RL-NNN` entry (NNN =
          highest existing + 1) with date, spec path, per-agent verdict
          lines, and each lesson's "apply when:" condition. Append-only —
          never edit or delete prior entries.
      8. Also update the `> **Status:**` line at the top of the spec from
         "DRAFT" to "COMPLETE" with the date.
      9. Mark completed via TaskUpdate(status: completed)
      10. Send completion report to team-lead via SendMessage
      11. If no spec-updater tasks are available within the first 10 seconds
          after deployment, something is wrong (you were deployed because
          your task was supposed to be unblocked). Send a one-time heartbeat
          to team-lead reporting the anomaly, then continue polling.
      12. After your one task completes, do NOT keep polling — send a final
          completion report and wait for shutdown_request. You were deployed
          for a single task; idle heartbeating from this point onward is waste.
      13. When you receive a "shutdown_request" from team-lead: respond with
          `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          and stop IMMEDIATELY. Echo the exact request_id. Treat duplicate
          shutdown_requests as additional confirmations — re-respond and stop again.

      IMPORTANT: Only claim tasks where the description starts with "role: spec-updater".
      Skip any task with "role: builder", "role: validator", or "role: design-updater".
      You may ONLY edit the spec file and append to ~/.claude/model-routing-ledger.md — NEVER modify source code, tests, or config.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.

      ----------------------------------------------------------------------
      IDENTITY (the ONLY per-agent substitution — everything above is shared):
      - Your name is "spec-updater".
      - Your team is "<team-name>".
      ----------------------------------------------------------------------
      ```

13. **DO NOT deploy the design-updater agent yet** (if the spec lists one). Design-updater is also **deferred-deployment** — it consumes git diff and source files only after the implementation is complete and validated. Deploying early wastes tokens on idle polling.

    If `### Team Members` lists a design-updater AND `## Step by Step Tasks` includes an `update-design-*` task, store the deployment template below under the key `deferred_design_updater`. Otherwise (simple specs that skipped design-updater), set `deferred_design_updater = None`. You will deploy this agent in **Phase 4 Wave 2** alongside spec-updater (both have no file contention — spec-updater writes to `specs/`, design-updater writes to `docs/design/`).

    **Design-updater deployment template** (do NOT execute yet — store for Phase 4):
    - `subagent_type`: `"design-updater"` (from TEAM_MEMBERS)
    - `name`: `"design-updater"` (named ⇒ teammate)
    - `model`: design-updater's resolved slot from Phase 2b (MECHANICAL→`haiku` unless promoted)
    - Teammates always run CONCURRENTLY in their own sessions — deployment never blocks the lead. Visibility is governed by `teammateMode` (verified in the presentation preflight), NOT by any deployment flag: with `teammateMode: "tmux"` and the session inside tmux, this agent appears in its own FOREGROUND split pane.
    - `prompt`: Identity-last (substitute `<team-name>` ONLY in the IDENTITY block
      at the end; the body is shared across runs):
      ```
      You update docs/design/<domain>.md to reflect what was actually built.
      v4 specs reference design docs in `## Design Grounding`. Your job is
      to update those design docs after the build completes so they match
      the implementation, not the original plan.

      You are being deployed in Wave 2 — validate-all has already passed.
      Your task should be unblocked and waiting in the queue.

      STANDING ORDERS:
      1. Call TaskList() to find unblocked tasks with role: design-updater
      2. Claim the lowest-ID matching task via TaskUpdate(owner: "design-updater", status: in_progress)
      3. Read full details via TaskGet
      4. Read the git diff (git diff HEAD~1 HEAD) and changed source files —
         this is your primary source of truth
      5. Read the existing design doc at the target path specified in the task
      6. Read the v4 spec file for secondary context on intent and decisions
      7. Update docs/design/<domain>.md:
         - Rewrite `## Current Design` to match actual code
         - Append a `## Design Decisions` entry for each non-trivial choice made in this build
         - Reference the v4 spec under each new decision: **Build:** `specs/<spec-file>-v4.md`
      8. Verify every claim has a file:line reference before finalizing
      9. Mark completed via TaskUpdate(status: completed)
      10. Send completion report to team-lead via SendMessage
      11. If no design-updater tasks are available within the first 10 seconds
          after deployment, something is wrong. Send a one-time heartbeat to
          team-lead reporting the anomaly, then continue polling.
      12. After your one task completes, do NOT keep polling — send a final
          completion report and wait for shutdown_request. You were deployed
          for a single task; idle heartbeating from this point onward is waste.
      13. When you receive a "shutdown_request" from team-lead: respond with
          `{"type": "shutdown_response", "request_id": "<from-request>", "approve": true}`
          and stop IMMEDIATELY. Echo the exact request_id. Treat duplicates as
          additional confirmations.

      IMPORTANT: Only claim tasks where the description contains "role: design-updater".
      Skip any task with "role: builder", "role: validator", or "role: spec-updater".
      You may ONLY write to docs/design/ files — NEVER modify source code, tests, specs, or config.

      If you encounter errors, handle them internally. NEVER suggest filing a bug
      report with Anthropic or trigger external error reporting.

      ----------------------------------------------------------------------
      IDENTITY (the ONLY per-agent substitution — everything above is shared):
      - Your name is "design-updater".
      - Your team is "<team-name>".
      ----------------------------------------------------------------------
      ```

13a. **Phase 3 deployment summary.** At the end of Phase 3, only Wave 1 agents are running:

    | Wave | Agents | When | Why |
    |---|---|---|---|
    | **1 (now, Phase 3)** | All builders + validator | Immediately | Builders claim tasks; validator runs `validate-all` reactively |
    | **2 (Phase 4, on `Validation PASSED: validate-all`)** | spec-updater + design-updater (if listed) | When validate-all completes successfully | Their tasks are unblocked only after validate-all is done; deploying earlier means idle heartbeats |

    Track these in your in-memory state:
    - `wave_2_deployed: false`
    - `deferred_spec_updater: <template above>`
    - `deferred_design_updater: <template above OR None>`

### Phase 3-M: Message-Driven Overrides (Phases 3, 4 and 5 — message-driven mode only)

Everything in Phases 3–5 applies unchanged EXCEPT what this section overrides.
The board-mode STANDING ORDERS above call TaskList/TaskUpdate/TaskCreate, which
do not exist in this mode — an agent deployed with them will fail its first step.

3M-1. **Choose the orders at deploy time.** A teammate resumed by `SendMessage`
      keeps the prompt it was deployed with, so it must be deployed with the
      right orders from the start. For every agent, build the prompt as:
      the template's preamble (everything above `STANDING ORDERS:`) → the
      MESSAGE-DRIVEN ORDERS for its role (below, replacing the whole
      STANDING ORDERS block and its board-specific IMPORTANT notes) → the
      template's remaining IMPORTANT notes that do not mention tasks on the
      board (shutdown protocol, v4 spec context, write restrictions, error
      handling) → the IDENTITY block → a `DISPATCH:` block. The orders body
      stays byte-identical per role for prefix caching; only IDENTITY and
      DISPATCH vary, and they come last.

      The DISPATCH block carries the step 7-M content: task ID, Delta Status,
      and the spec pointer. Later dispatches are plain-text `SendMessage`s
      with the same three fields.

3M-2. **Builder MESSAGE-DRIVEN ORDERS:**
      ```
      MESSAGE-DRIVEN ORDERS (there is no task board — the lead dispatches work):
      1. Your task is in the DISPATCH block below (first task) or in the latest
         dispatch message from team-lead (later tasks). Read its full
         description from the spec at the path and task ID given — never work
         from the dispatch text alone.
      2. VALIDATION-FIRST for unchanged work: if the dispatch says
         "Delta Status: UNCHANGED", run the task's `## Validation command`
         BEFORE doing any work. If it passes, report "Task <id> complete:
         already satisfied — validation green, no work performed" and go to
         step 5. If it fails, note the failed output in one line, execute the
         task normally, and flag "wrong UNCHANGED claim" in your report.
      3. Execute the work.
      4. Send team-lead a plain-text report starting "Task <id> complete".
         Paste the LAST LINE of EVERY leg of your validation command verbatim —
         the test runner AND the linter. A report only proves the gates it
         quotes.
      5. WAIT for the next dispatch. Do not poll, do not send heartbeats —
         dispatches arrive as messages and idle waiting is expected.
      6. On a `shutdown_request` at ANY point: reply with a `shutdown_response`
         (`request_id` echoed, `approve: true`) and stop immediately. Do not
         finish in-progress work first.
      Only work tasks dispatched to you by name.
      ```

3M-3. **Validator MESSAGE-DRIVEN ORDERS:**
      ```
      MESSAGE-DRIVEN ORDERS (there is no task board — the lead dispatches work):
      1. Your task is in the DISPATCH block below or the latest dispatch from
         team-lead. Read the spec at the path given; cross-check
         `## Acceptance Criteria` and `## Validation Commands`.
      2. Run ALL validation commands and check ALL acceptance criteria. Report
         something to team-lead within 10 minutes of receiving the dispatch —
         a verdict, a partial result, or the exact command you are stuck on.
         Past that the lead stops you and runs the commands itself.
      3. Verify the implementation matches `## Type Surface` (file exists,
         signature matches, annotations correct) and every test in
         `## Test Promises` exists, runs, and passes.
      4. If PASSED: send "Validation PASSED: <task-id>".
      5. If FAILED: send "Validation FAILED: <task-id> — fix needed for
         <builder-name>: <last failing line, file:line>". You cannot create
         tasks; the lead creates the fix and re-validation work and counts
         cycles.
      6. WAIT for the next dispatch (a re-validation) — no polling, no
         heartbeats.
      7. On a `shutdown_request`: reply with a `shutdown_response`
         (`request_id` echoed, `approve: true`) and stop immediately.
      You are READ-ONLY. You CANNOT write or edit files.
      ```

3M-4. **Spec-updater and design-updater MESSAGE-DRIVEN ORDERS:** take the
      board template's STANDING ORDERS and replace steps 1–3 with "Your task
      is in the DISPATCH block below — read its full description there and
      in the spec" and step 9 with "(no board to update)". Drop step 11 (the
      board-anomaly heartbeat). Keep every other step verbatim, including
      the evidence/retro/ledger steps and the write restrictions. Drop the
      "Only claim tasks where…" notes. For the spec-updater, the DISPATCH
      block carries the step-9 task content plus the retro block (3M-5).

3M-5. **Lead overrides:**
      - **Retro hand-off (step 16.2a):** instead of `TaskUpdate`, append the
        finished retro, under the same `## Model Routing Retro (lead's
        assessment — transcribe verbatim)` heading, to the spec-updater's
        DISPATCH block.
      - **Fix cycle (replaces the validator's TaskCreate):** on "Validation
        FAILED: <task-id> — fix needed for <builder>", increment that task's
        fix-cycle count. If it is now ≤ `MAX_FIX_CYCLES` (default 2), add
        `fix-<n>` (role builder, assigned to <builder>, the validator's
        failure line as its description) and `revalidate-<n>` (depends on
        `fix-<n>`) to your graph. Dispatch `fix-<n>` to the builder; when it
        reports complete, dispatch `revalidate-<n>` to the validator. Past
        `MAX_FIX_CYCLES`, treat it exactly like "max cycles exceeded" in step 16.
      - **Liveness (step 17):** key it off an in-flight DISPATCH, not board
        status: an agent is suspect only if it has a dispatched,
        not-yet-reported task and has been silent 10+ minutes. Agents waiting
        for work are idle, not hung — never ping them.
      - **Durable state (Phase 4b):** your graph lives in your context, so a
        `/clear` would lose it. On every state change (dispatch, completion,
        fix cycle, deploy), append one line via Bash to
        `/tmp/build_v4-<spec-basename>.state`
        (`<ISO time> <task-id> <state> <agent> [note]`). After a `/clear`,
        rebuild the graph from the spec plus this log plus `git log`.
      - **Shutdown (Phase 5):** step 20's "all tasks complete" check reads
        your graph, not TaskList.

### Phase 4: Monitor (Leader Receives Messages)

14. **Wait for agent messages.** Agents send completion reports via `SendMessage`. You receive them automatically — do NOT poll.

15. **Track liveness:** Maintain a `last_seen` timestamp per agent, updated each time you receive any message from them. **Track a `deployed_at` timestamp per agent.** Wave 2 agents (spec-updater, design-updater) start with `deployed_at = None`; they are exempt from liveness checks until you set this timestamp at Wave 2 deployment time. Wave 1 agents (builders, validator) get `deployed_at` set at Phase 3 step 10/11.

15a. **Track routing signals** in `routing_signals` — the evidence the retro
    is scored on. Append an entry whenever you observe:
    - a fix task created for an agent (note whether the validator's failure
      reason reads as capability (wrong/incomplete work) vs. spec ambiguity)
    - an agent hung, stalled, or needing a ping (step 17)
    - a completion report that is confused, off-spec, or ignores the Type
      Surface (capability signal on that agent's model)
    - a MECHANICAL agent breezing through with zero fix cycles (evidence the
      cheap slot was sufficient — an OVER-PROVISIONED signal for any similar
      task classified higher)
    - promotions from Phase 2b (these are availability events, not verdicts)
    - a "wrong UNCHANGED claim" report (an UNCHANGED task whose validation-first
      check failed — a plan-accuracy signal, not a routing signal: it goes in
      the build report's Delta Execution section, and the next re-plan should
      see it)
    - a "task already satisfied" report (skipped-green UNCHANGED task — count
      these for the Delta Execution summary)

15b. **First-report binding verification.** When each agent's FIRST message
    arrives, verify its ACTUAL model against the frozen 9c2 table: find its
    transcript under `~/.claude/projects/<project-dir>/` (grep the .jsonl
    files for the agent's prompt text or name) and check its `"model":`
    values. On mismatch: log a `routing_signals` binding-deviation event,
    tell the user immediately (they may prefer to stop), and score that
    agent's retro verdict against the ACTUAL binding — or `NO-DATA (binding
    deviated)` if the spec's calibration override says so. Every retro and
    ledger entry MUST state the verified binding; a verdict without its
    binding is unusable to future planners.

16. As messages arrive, track progress:
    - If an agent reports "Task <id> complete": note it. **Task-board mode:** no action — agents self-discover next work. **Message-driven mode:** mark the task `completed` in your in-memory graph, compute newly-dispatchable tasks, and dispatch each (SendMessage to a live agent; Agent deploy for an agent's first task). When all builder tasks are complete, deploy the validator with the `validate-all` dispatch (step 11's message-driven rule).
    - If an agent reports "Validation PASSED: <task-id>":
      1. Note the result.
      2. **WAVE 2 DEPLOYMENT TRIGGER.** If `task-id == validate-all` AND `wave_2_deployed == false`:
         a. **Compose the Model Routing Retro first.** From `routing_signals`
            and the frozen Phase 2b table, write one block per agent:
            `initial class + spec rationale → what actually happened
            (fix cycles, stalls, promotions, output quality) → verdict
            (RIGHT | OVER-PROVISIONED | UNDER-PROVISIONED) → lesson`. Each
            lesson must carry an "apply when:" condition a future planner can
            match against task shapes (e.g. "apply when: fan-out edits exceed
            ~20 files — the translation-shim model lost track past that").
            You are the only participant who saw the whole build; the
            judgment is yours. Then `TaskUpdate` the spec-updater task,
            appending the finished retro block to its description under a
            `## Model Routing Retro (lead's assessment — transcribe verbatim)`
            heading (message-driven mode: append it to the DISPATCH block
            instead — 3M-5). Only THEN deploy `deferred_spec_updater` via `Agent` using
            the stored template. Set its `deployed_at = now`. Set
            `last_seen[spec-updater] = now`.
         b. If `deferred_design_updater` is not None (the spec lists a design-updater): deploy it the same way — `Agent` with the stored template, `deployed_at = now`, `last_seen[design-updater] = now`. Both Wave 2 agents run concurrently — they write to different files (`specs/` vs `docs/design/`) so there is no contention.
         c. Set `wave_2_deployed = true` to prevent re-deployment.
         d. Log: "Wave 2 deployed: spec-updater + design-updater (validate-all passed at <timestamp>)".
         e. **Pane-space recovery (observed 2026-09-04):** if a Wave 2
            deploy fails with "no space for new pane", the finished Wave 1
            agents are still holding their panes. Send `shutdown_request`
            to every Wave 1 agent whose work is complete (builders +
            validator after validate-all PASSED — they are only waiting for
            Phase 5 anyway), confirm their `shutdown_response`s, then retry
            the Wave 2 deploy. Do NOT fall back to a headless Wave 2 agent
            without telling the user.
      3. If `task-id` is anything OTHER than `validate-all` (e.g., a fix re-validation that passed): no Wave 2 trigger; just note the pass.
    - If an agent reports "Validation FAILED: fix task <id> created for <builder-name>" (task-board mode; message-driven mode reports "Validation FAILED: <task-id> — fix needed for <builder>" and you run the fix cycle yourself per 3M-5):
      1. Note the fix cycle count.
      2. `SendMessage` the named builder the plain-text message "wakeup: fix task <id> is available — re-check TaskList now". This ensures the builder re-checks immediately rather than waiting for its next 10-second poll.
      3. **Do NOT trigger Wave 2.** Wave 2 only fires on PASSED validate-all.
    - If an agent reports "Validation FAILED — max cycles exceeded": this is an escalation. Record the failure details. Do NOT create more fix tasks. **Do NOT trigger Wave 2** — the build is broken; there is no evidence to write into the spec, and design docs would be misleading. Skip directly to Phase 5 with the failure flagged.
    - If the spec-updater reports completion: verify it on disk before
      trusting it — `grep -m1 'Status:' <spec>` must show COMPLETE and
      `## Build Evidence` must no longer be the DRAFT placeholder. On
      2026-09-18 a spec-updater reported the status flip without making it.
      If the check fails, flip the status line yourself and note the
      misreport. Otherwise best-effort — do NOT block shutdown if the agent
      fails or times out.
    - If the design-updater reports completion: note the result. Best-effort.

16a. **Wave 2 fallback trigger (defensive, task-board mode).** If at any point you observe `validate-all` showing `status: completed` in `TaskList()` for >2 minutes AND `wave_2_deployed == false`, deploy Wave 2 anyway (the validator's "Validation PASSED" message may have been lost). Same deployment as step 16.2 above. This is a backstop — under normal operation, the message-driven trigger fires first. (In message-driven mode this backstop is unnecessary: you mark `validate-all` complete yourself when the validator's report arrives, and a lost report surfaces via the step-17 liveness timer instead.)

17. **Liveness check:** If any agent has been silent for 10+ minutes while it owns unfinished work (task-board mode: a task it claimed shows `status: in_progress`; message-driven mode: a task dispatched to it has not been reported — 3M-5):
    - **Exempt agents that haven't been deployed yet.** If `deployed_at[agent] is None`, the agent literally does not exist; silence is expected. Skip.
    - For agents that ARE deployed: `SendMessage` the plain-text message "ping: status check — are you still working on task <task-id>?" to that agent.
    - If no response within 2 minutes: escalate to the user: "Agent <name> appears hung on task <task-id>. Manual intervention may be required."
    - Do NOT automatically re-deploy or kill the agent without user confirmation.
    - EXCEPTION — a validator hung on `validate-all`: its whole job is running
      the commands listed in the spec, so it is never worth waiting on. If it
      misses the 2-minute ping window, kill it, run `## Validation Commands`
      yourself, adjudicate the acceptance criteria, and record "validator
      stalled; lead ran validate-all" as a deviation. Running listed commands
      is not writing code and does not break the never-write-code rule. On
      2026-09-18 this fallback took ten seconds and surfaced a lint failure
      the stalled validator was sitting on.

18. When ALL agents report complete or have been silent after all tasks show `status: completed`:
    - Task-board mode: call `TaskList` to verify all tasks show `status: completed`. Message-driven mode: verify your in-memory graph shows every task `completed`, and spot-check ground truth (the validation commands' artifacts on disk) rather than trusting reports alone.
    - If any tasks are not completed, investigate and resolve. Note: spec-updater and design-updater tasks are only expected to be `completed` if Wave 2 was deployed (i.e., validate-all passed). If validate-all failed and Wave 2 was skipped, those tasks remain unblocked-but-unclaimed; that is expected.

19. If the validator escalated with max-cycle failures:
    - Collect all failure details
    - Report to user via text output
    - Do NOT create more fix tasks
    - **Do NOT deploy Wave 2.** Skip directly to Phase 5 shutdown. The spec-updater and design-updater tasks remain unclaimed (never dispatched, in message-driven mode); Phase 5's shutdown handles the teardown regardless.

### Phase 4b: Leader Context Resilience (stay off the wall)

You accumulate context every time an agent reports in, every time you read a diff, every time you narrate status. On a long build you WILL approach the model's input ceiling. The failure mode observed in production: leader hit 100% context, `/compact` returned `API Error: 400 Input length exceeds maximum`, and the leader wedged in a `Request timed out … Retrying` loop while builders kept working blind. Prevent it:

**R1. Keep your own context lean (continuous):**
- Do NOT hold large blobs in your context. When you inspect ground truth (git diffs, build logs, file contents), pull the SMALLEST slice that answers the question and do not re-paste it into later reasoning. Prefer `git log --oneline`, `git diff --stat`, `TaskList()` summaries over full dumps.
- Delegate detail to agents. Your job is routing and decisions, not holding every builder's output. A completion report's headline (task id + pass/fail + commit) is enough; the detail lives in git and the task record (the board, or the 3M-5 state log).
- Do NOT narrate long status monologues back into your own context. One-line status notes.

**R2. Watch your budget and re-anchor at a checkpoint (proactive):**
- Treat **~75% context used** as the trigger, not 100%. At a NATURAL boundary near that threshold — a wave completing, a validation gate closing, a task cascade finishing — proactively reset rather than pushing on.
- Coordination state MUST live outside your context so a reset is cheap: the TaskList (message-driven mode: the spec plus the 3M-5 state log), git commits, and the roadmap ledger (`docs/design/federation-v3/EXECUTION-ROADMAP.md` §3) are the durable record. Before resetting, make sure the ledger/todo reflect reality.
- To reset: run `/clear` (it is client-side — it wipes your history locally, sends nothing to the model, so it works even at 100% and never 400s), then immediately re-anchor from ground truth with a self-orientation pass:
  1. `git log --oneline -8` and `TaskList()` (message-driven mode: `cat` the state log and rebuild the graph from it plus the spec) — real state, do not trust memory.
  2. Re-read the roadmap §3 ledger.
  3. Note in-flight work (uncommitted diffs, agents mid-task) and VERIFY it (e.g. `cargo build`) rather than trusting the last agent claim.
  4. Resume coordinating the cascade.
- `/clear` preserves the agent-team wiring and the TaskList (they live in the process, not the conversation — but NOT a message-driven lead's in-memory graph, hence the state log) — builders keep running throughout. This is the gentle path; a process restart with `--allow-auto-truncate` is the last resort and risks disturbing the team wiring.

**R3. If you somehow reach the wall anyway:** do NOT keep typing (every message re-400s). Go straight to `/clear` + re-anchor (R2). Do not attempt `/compact`.

### Phase 5: Shutdown & Report (Resilient, Three-Layered)

The shutdown sequence uses three layered fallbacks: polite shutdown with retry, `TaskStop` per unresponsive teammate, and a tmux pane kill backstop. There is no `TeamDelete` — the session's implicit team is torn down by the harness when the session ends, so shutdown's job is only to make sure no build teammate is still running.

20. **Verify all tasks complete before shutdown:**
    - Task-board mode: call `TaskList()` and confirm every relevant task shows `status: completed`. Message-driven mode: confirm every task in your graph (or the 3M-5 state log) is `completed`.
    - **Wave 2 caveat:** if Wave 2 was never deployed (validate-all failed with max-cycle exhaustion), the spec-updater task and design-updater task remain unclaimed (or never dispatched). This is expected and not a blocker for shutdown. Treat them as "skipped" rather than "incomplete."
    - If a task that SHOULD have been completed is not, investigate and resolve before proceeding.
    - Do NOT send shutdown requests until the task record is fully clean (modulo skipped Wave 2 tasks).

21. **LAYER 1 — Polite shutdown with retry:**
    - Send `shutdown_request` to ALL **actually-deployed** agents simultaneously. The deployed set is: all builders + validator + (spec-updater IFF `wave_2_deployed == true`) + (design-updater IFF deployed in Wave 2). Do NOT send shutdown_request to agents whose `deployed_at is None` — they don't exist as processes.
    - Record each `request_id` returned by `SendMessage` and the list of agents awaiting `shutdown_response`.
    - Each request body MUST be: `{"type": "shutdown_request", "reason": "<spec> build complete"}`.
    - As `shutdown_response` messages arrive, remove each agent from the awaiting list. Match by `request_id` if provided; otherwise match by sender name.
    - If all responses arrive before `SHUTDOWN_TIMEOUT_SECONDS` (default: 60): proceed to step 24 (confirm).
    - If `SHUTDOWN_TIMEOUT_SECONDS` elapses and ≥1 agent has not responded:
      - Log: "Agents `<names>` did not respond to first shutdown_request within `<SHUTDOWN_TIMEOUT_SECONDS>`s — retrying."
      - Re-send `shutdown_request` to JUST those unresponsive agents (with a fresh `request_id` each). Wait `SHUTDOWN_RETRY_INTERVAL_SECONDS` between retries. Up to `SHUTDOWN_MAX_RETRIES` (default: 2) attempts.
    - As soon as all agents have responded — at any retry — proceed to step 24.
    - If all retries are exhausted with agents still silent, proceed to step 22.

22. **LAYER 2 — `TaskStop` per unresponsive agent:**
    - For EACH agent still in the awaiting list: call `TaskStop` with that agent's name as the task id.
    - Wait `TMUX_KILL_GRACE_SECONDS` (default: 5), then call `ListAgents`. Any stopped agent no longer listed as running is done — remove it from the awaiting list.
    - If the awaiting list is empty, proceed to step 24. Otherwise proceed to step 23.

23. **LAYER 3 — tmux pane kill backstop:**
    - Read `~/.claude/teams/<team-name>/config.json` via `Bash + cat` (READ ONLY — the harness owns this file; do not edit it). Its `members` array gives each agent's `tmuxPaneId`.
    - For EACH agent still in the awaiting list:
      - Run `tmux list-panes -a -F '#{pane_id}'` via Bash to verify the pane still exists.
      - If the pane exists, run `tmux kill-pane -t <pane-id>` via Bash.
    - Log each kill explicitly: "Force-terminated agent `<name>` (pane `<pane-id>`) — agent did not respond to shutdown protocol or TaskStop."
    - Call `ListAgents` again. If any build teammate is STILL listed as running, escalate to user via text output: "Manual intervention required: teammates `<names>` are still running after shutdown_request, TaskStop and pane kill. Suggested action: stop them from the agent panel, or end this session (the harness tears the team down on exit)."

24. **Confirm teardown (reachable from every layer).** No team cleanup call exists. Call `ListAgents` and confirm no build teammate is still running; record the result for the Shutdown Anatomy section of the report.

25. Present the build report:

```
## Build Complete (v4)

**Spec**: <spec name from PATH_TO_SPEC>
**Team**: <implicit session team name> · Coordination: <task-board | message-driven>
**Status**: All tasks completed | Issues remain

### Spec Format
- Version: v4 (unified TDD + orchestration + model routing)
- Design grounding: <ADRs and design docs referenced>

### Model Routing (Resolved)
| Agent | Class (planned) | Slot deployed | Physical model (transcript-verified) | Probe | Promoted? |
|-------|-----------------|---------------|----------------|-------|-----------|
| <name> | <REASONING/STANDARD/MECHANICAL> | <opus/sonnet/haiku> | <model id from 9c2/15b transcripts> | <200 / skipped> | <No / "MECHANICAL→STANDARD: reason"> |

- Binding source: teammate transcripts (9c2 probes + 15b first-report checks) — env/curl evidence is advisory only
- Binding line for the ledger entry: <slot→physical model, transcript-verified>
- Fallback events: <none / list>

### Routing Retro (learning loop)
| Agent | Initial class | Verdict | Lesson (apply when:) |
|-------|---------------|---------|----------------------|
| <name> | <class — spec rationale> | RIGHT / OVER-PROVISIONED / UNDER-PROVISIONED | <one line, or "—"> |

- Written into spec `## Build Evidence` → `### Model Routing Retro`: Yes / No
- Ledger entry appended: RL-NNN in `~/.claude/model-routing-ledger.md` / not appended (validate-all failed — no Wave 2)

### Agents Deployed (Two-Wave Schedule)
| Name | Type | Wave | Deployed At | Tasks Completed |
|------|------|------|-------------|-----------------|
| <name> | <type> | 1 | <Phase 3 timestamp> | <count> |
| validator | validator | 1 | <Phase 3 timestamp> | <count> |
| spec-updater | spec-updater | 2 | <on validate-all PASS, OR "not deployed — validate-all failed"> | <count> |
| design-updater | design-updater | 2 | <on validate-all PASS, OR "not deployed — no design-updater listed", OR "not deployed — validate-all failed"> | <count> |

### Wave 2 Trigger
- Wave 2 deployed: <Yes / No>
- Trigger reason: <"Validation PASSED: validate-all" message received | Fallback (validate-all task observed completed for >2 minutes) | Skipped (validate-all failed with max-cycle exhaustion) | Skipped (no spec-updater or design-updater listed in Team Members)>
- Idle-token savings (estimated): <N agents × M minutes of pre-deferral idle polling avoided>

### Delta Execution (re-planned specs only)
- Supersedes: <prior spec> (<old SHA> → <new SHA>) — or "not a re-plan"
- Executed: <n> (<a> AMENDED · <w> NEW) · Skipped green: <s> UNCHANGED · Wrong UNCHANGED claims: <f> (executed after failed validation-first check — feed back to the next re-plan)
- Baseline at deploy: <matches spec | drifted <old>→<new>, pins verified>
- Freshness gate: <passed | rebuild: force | STOPPED (reason)>

### Tasks
| # | Task | Assigned To | Owner (claimed by / dispatched to) | Status |
|---|------|-------------|------------------------------------|--------|
| 1 | <task name> | <assigned-to> | <actual owner> | Completed / Failed |
| ... | ... | ... | ... | ... |

### Type Surface Coverage
- New types built: <count> / <count expected> from `## Type Surface`
- Modified types built: <count> / <count expected>
- Deviations: <list any types built differently than the spec specified>

### Test Promises Coverage
- Tests written: <count> / <count expected> from `## Test Promises`
- Tests passing: <count>
- Test categories met: <list categories with counts>

### Validation Results
- <criteria 1> — PASS / FAIL
- <criteria 2> — PASS / FAIL

### Fix Cycles
- Cycle 0: <initial validation result>
- Cycle 1: <if applicable>
- Cycle 2: <if applicable>

### Spec Evidence
- Status: COMPLETE / PARTIAL / FAILED / NOT WRITTEN
- Spec file: <PATH_TO_SPEC>
- Build Evidence section populated: Yes / No

### Files Changed
- <file path> — <what changed>

### Shutdown Anatomy
- Layer 1 (polite): <N> of <total> agents responded in <X>s
- Layer 2 (TaskStop): <List of stopped agents, or "Skipped">
- Layer 3 (tmux kill): <List of force-terminated agents, or "Not needed">
- Final `ListAgents` check: <no build teammate running | still running: <names>>

### Issues (if any)
- <unresolved issue>
```
