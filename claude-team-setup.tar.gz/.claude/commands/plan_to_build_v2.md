---
description: Creates a concise engineering implementation plan with team orchestration and saves it to specs directory (v2 — design-first planning with enforced task ownership)
argument-hint: "[user prompt] [orchestration prompt]"
model: opus
context: fork
allowed-tools: Read, Grep, Glob, Bash, Write, Edit, WebSearch, WebFetch, TaskCreate, TaskUpdate, TaskList, TaskGet, AskUserQuestion
hooks:
  Stop:
    - hooks:
        - type: command
          command: >-
            uv run $HOME/.claude/hooks/validators/validate_new_file.py
            --directory specs
            --extension .md
        - type: command
          command: >-
            uv run $HOME/.claude/hooks/validators/validate_file_contains.py
            --directory specs
            --extension .md
            --contains '## Task Description'
            --contains '## Objective'
            --contains '## Relevant Files'
            --contains '## Step by Step Tasks'
            --contains '## Acceptance Criteria'
            --contains '## Team Orchestration'
            --contains '### Team Members'
            --contains '## Design Document'
---

# Plan To Build v2

Create a detailed implementation plan based on the user's requirements provided through the `USER_PROMPT` variable. Before writing the plan, conduct a comprehensive design study and produce a design document. The design document becomes the foundation from which all plan tasks are derived. Follow the `Instructions` and work through the `Workflow` to create both artifacts.

## Variables

USER_PROMPT: $ARGUMENTS
PLAN_OUTPUT_DIRECTORY: `specs/`
DESIGN_OUTPUT_DIRECTORY: `docs/design/`
TEAM_MEMBERS: `.claude/agents/team/*.md`
GENERAL_PURPOSE_AGENT: `general-purpose`

## Instructions

- **PLANNING ONLY**: Do NOT build, write code, or deploy agents. Your outputs are: (1) a design document saved to `DESIGN_OUTPUT_DIRECTORY`, and (2) a plan document saved to `PLAN_OUTPUT_DIRECTORY`.
- If no `USER_PROMPT` is provided, stop and ask the user to provide it.
- If the user prompt includes orchestration guidance (team composition, task granularity, parallel/sequential preferences), use it to guide the plan design.
- Carefully analyze the user's requirements provided in the USER_PROMPT variable
- Determine the task type (chore|feature|refactor|fix|enhancement) and complexity (simple|medium|complex)
- Think deeply (ultrathink) about the best approach to implement the requested functionality or solve the problem
- **Design-first**: You MUST complete the full Design Study and Design Document phases BEFORE writing any plan tasks. The plan is derived from the design, not the other way around.
- Understand the codebase directly without subagents to understand existing patterns and architecture
- Follow the Plan Format below to create a comprehensive implementation plan
- Include all required sections and conditional sections based on task type and complexity
- Generate a descriptive, kebab-case filename based on the main topic of the plan
- Save both artifacts before completing
- Ensure the plan is detailed enough that another developer could follow it to implement the solution
- Include code examples or pseudo-code where appropriate to clarify complex concepts
- Consider edge cases, error handling, and scalability concerns
- Understand how `/build_v2` executes plans. Refer to the `Team Orchestration` section in the Plan Format for details. Your plan must be complete enough for agents to work autonomously.
- **Include design-updater tasks** — for any plan of medium or complex complexity, or any plan that makes non-trivial architectural decisions, include one or more `design-updater` tasks at the end of the task graph (after validate-all). Each task targets a specific `docs/design/<domain>.md`. The planner decides how many design-updater tasks are needed and where in the dependency graph they belong.

### How /build_v2 Executes This Plan

The `/build_v2` command creates a **self-organizing agent team**:

1. **Creates a team** via `TeamCreate` — name is `<plan-name>-<timestamp>` to prevent collisions
2. **Populates the task list** — one `TaskCreate` per task in this plan, with dependencies via `addBlockedBy`
3. **Deploys agents once** with standing orders — builders, validators, and support agents listed in Team Members
4. **Agents self-organize** — they poll `TaskList`, claim tasks **assigned to their own name**, execute work, mark completed, and loop
5. **Validator auto-creates fix tasks** if validation fails — builders pick them up automatically (max 2 fix cycles); leader sends a wakeup so builders re-check immediately
6. **Leader monitors** via `SendMessage` reports — pings agents silent for 10+ minutes, only intervenes for escalations

#### What This Means for Plan Quality

Because agents work autonomously:
- **Task descriptions must be exhaustive** — agents cannot ask the leader for clarification
- **`Assigned To` is enforced** — every task must have an `Assigned To` matching a builder name from Team Members; agents only claim tasks assigned to them
- **Dependencies must be correct** — agents trust `blockedBy` to prevent premature starts
- **Team composition must be complete** — `/build_v2` deploys exactly what's listed, no more
- **Validation must be specific** — the validator runs exactly the commands listed
- **Design doc is the blueprint** — every task should reference the design doc for architectural context, patterns, and decisions that informed the task

## Workflow

IMPORTANT: **PLANNING ONLY** - Do not execute, build, or deploy. Outputs are a design document and a plan document.

### Phase A: Requirements & Codebase Analysis

1. **Analyze Requirements** — Parse the USER_PROMPT to understand the core problem and desired outcome. Identify the primary domain(s) this work touches (e.g., "API routing", "storage engine", "plugin system").

2. **Read Existing Design Docs** — Glob `docs/design/` for existing design documents. Read any that are relevant to the domains this plan touches. Extract prior decisions and established patterns — these become constraints for the design study.

3. **Understand Codebase** — Without subagents, directly explore existing patterns, architecture, and relevant files. Read source code in the affected domains. Map dependencies and data flows.

### Phase B: Design Study (Full Depth)

Conduct a comprehensive design study following the design-study-expert methodology. This is NOT optional — it is the foundation for everything that follows.

4. **Full Domain Enumeration** — Enumerate ALL operations/features in the problem domain, not just the ones requested. Categorize by complexity (simple/medium/complex/edge). Reference authoritative specs or industry standards where applicable.

5. **Security Analysis** — Identify vulnerabilities, unsafe patterns, attack surfaces, and data exposure risks in the affected code paths. Document findings with file:line references.

6. **Correctness Analysis** — Identify logic errors, race conditions, data integrity issues, and edge cases. Trace execution paths through the code. Document assumptions (explicit and implicit).

7. **Performance Analysis** — Identify hot paths, unnecessary allocations, cache efficiency issues, and algorithmic complexity concerns. Note O(n) characteristics of key operations.

8. **Scalability Analysis** — Assess behavior at 10x/100x load or data scale. Identify bottlenecks, single points of failure, and resource exhaustion risks.

9. **Industry Comparison** — Compare the proposed approach against at least 2 industry-leading systems or established open-source projects. Identify patterns worth adopting and quantify gaps where possible.

10. **10x Opportunities** — Identify at least one opportunity for a significant improvement beyond the immediate request. Back it with evidence.

### Phase C: Design Document Generation

11. **Write Design Document** — Create or update `docs/design/<domain>.md` using the Design Document Format below. Two paths:

    - **Path A — Doc exists at `docs/design/<domain>.md`**: Use Edit to update it. Rewrite `## Current Design` to reflect the system as it exists NOW plus the proposed changes. Append new entries to `## Design Decisions` for each architectural choice this plan will make. Add `**Superseded by:**` annotations to any old decisions this plan overrides.

    - **Path B — No existing doc**: Use Write to create `docs/design/<domain>.md` from scratch using the full Design Document Format.

    The design document MUST include:
    - Architecture overview with Mermaid diagram
    - Key files table
    - Established patterns builders must follow
    - Data flow description
    - All design decisions with options considered, rationale, and tradeoffs
    - Security considerations section
    - Performance characteristics section
    - Scalability notes

12. **Verify Design Document** — Re-read the design doc and verify:
    - Every statement about current code has a `file:line` reference that exists
    - Every design decision has clear rationale and tradeoffs
    - The proposed architecture is consistent with existing patterns or explicitly documents deviations
    - All domain cases from step 4 are covered

### Phase D: Plan Generation (Derived from Design Doc)

13. **Define Team Members** — Determine team composition: builder count, names, agent types, one validator, one spec-updater, and one design-updater (for medium/complex plans). Identify from `.claude/agents/team/*.md` or use `general-purpose`. Document in plan.

14. **Define Step by Step Tasks** — Derive tasks FROM the design document. Every task must:
    - Reference the design doc (`docs/design/<domain>.md`) in its description
    - Follow patterns documented in the design doc's `## Patterns` section
    - Respect constraints documented in `## Design Decisions`
    - Have an `Assigned To` matching a name in Team Members
    - Be fully self-contained with exhaustive context
    - Include role (builder/validator/design-updater)

15. **Generate Filenames** — Create descriptive kebab-case filenames for both artifacts.

16. **Save Plan** — Write the plan to `PLAN_OUTPUT_DIRECTORY/<filename>.md`

17. **Save & Report** — Follow the `Report` section to provide a summary of both artifacts.

## Design Document Format

Every design document follows this structure. Write to `docs/design/<domain>.md`:

```md
# Design: <Domain Name>

> **Last Updated:** YYYY-MM-DD
> **Updated By:** plan_to_build_v2 (pre-build design study)
> **Code Baseline:** <git short SHA from `git rev-parse --short HEAD`>

## Executive Summary

<2-3 sentences: what this domain does, what problem it solves, and the key architectural approach. Written for a builder who has never touched this codebase.>

## Current Design

### Overview
<1-2 paragraphs: what this domain does, why it exists, key responsibilities. Active voice. No jargon without definition.>

### Architecture

```mermaid
graph TD
    ...
```

<Only include components that exist in the code — no aspirational architecture. For proposed new components, use dashed lines and annotate with "(proposed)".>

### Key Files
| File | Role |
|------|------|
| `path/to/file.rs` | <What it does — one line> |

### Patterns
Established patterns builders MUST follow in this domain:

- **<Pattern Name>**: <Description>. See `file:line` for the canonical example.

### Data Flow
<How data enters this domain, is transformed, and exits. Reference actual function signatures or data structures.>

## Design Study Findings

### Security
<Findings from security analysis. Each finding has severity, file:line, and recommendation.>

### Correctness
<Edge cases, race conditions, assumption risks. Each with file:line reference.>

### Performance
<Hot paths, allocation concerns, algorithmic complexity. Quantified where possible.>

### Scalability
<Behavior at 10x/100x scale. Bottlenecks and resource limits.>

### Industry Comparison
| Aspect | Our Approach | <Competitor A> | <Competitor B> | Assessment |
|--------|-------------|----------------|----------------|------------|
| <aspect> | <ours> | <theirs> | <theirs> | <gap or advantage> |

### 10x Opportunities
<At least one significant improvement backed by evidence.>

## Design Decisions

<Entries are append-only. Never delete. Add **Superseded by:** annotations when a later decision overrides an earlier one.>

### YYYY-MM-DD — <Decision Title>
- **Context**: <What situation required a decision>
- **Options Considered**:
  - Option A: <brief> — <why not chosen>
  - Option B: <brief> — <why not chosen>
  - **Chosen**: <chosen option> — <why>
- **Rationale**: <The reasoning — constraints, requirements, evidence>
- **Tradeoffs Accepted**: <What downside was consciously accepted>
- **Code Evidence**: `file:line` — <what in the code proves this decision>
- **Build**: `specs/<spec-file>.md`
```

## Plan Format

- IMPORTANT: Replace <requested content> with the requested content. It's been templated for you to replace. Consider it a micro prompt to replace the requested content.
- IMPORTANT: Anything that's NOT in <requested content> should be written EXACTLY as it appears in the format below.
- IMPORTANT: Follow this EXACT format when creating implementation plans:

```md
# Plan: <task name>

> **EXECUTION DIRECTIVE**: This is a team-orchestrated plan.
> **FORBIDDEN**: Direct implementation (Edit, Write, NotebookEdit) by the main agent. If you are the main conversation agent and a user asks you to implement this plan, you MUST invoke `/build_v2 specs/<this-filename>.md` -- do NOT implement it yourself.
> **REQUIRED**: Execute ONLY via the `/build_v2` command, which deploys team agents to do the work.

## Design Document
- **Path**: docs/design/<domain>.md
- **Created/Updated**: YYYY-MM-DD
- **Key Decisions**: <list the design decisions by title that inform this plan>
- **Patterns to Follow**: <list the patterns from the design doc that builders must follow>

All tasks in this plan are derived from the design document above. Builders MUST read the design doc before starting any task.

## Task Description
<describe the task in detail based on the prompt>

## Objective
<clearly state what will be accomplished when this plan is complete>

## Problem Statement
<clearly define the specific problem or opportunity this task addresses. Include findings from the design study: security risks to address, correctness issues to fix, performance improvements to make.>

## Solution Approach
<describe the proposed solution approach. Reference specific design decisions from the design document that informed this approach. Explain why alternatives were rejected (by referencing the design doc's Options Considered sections).>

## Relevant Files
Use these files to complete the task:

<list files relevant to the task with bullet points explaining why. Include new files to be created under an h3 'New Files' section if needed>

## Implementation Phases
### Phase 1: Foundation
<describe any foundational work needed — scaffolding, types, interfaces>

### Phase 2: Core Implementation
<describe the main implementation work — derived from design doc architecture>

### Phase 3: Integration & Polish
<describe integration, testing, and final touches>

## Team Orchestration

- The `/build_v2` command deploys a **self-organizing agent team**. Agents autonomously discover, claim, and execute tasks from a shared task list.
- You are responsible for designing the team composition and task graph so agents can work autonomously.
- IMPORTANT: The plan is the **single source of truth** for task execution. `/build_v2` is a pure executor — it does NOT make decisions. Everything must be specified here: team members, task assignments, dependencies, and exhaustive task descriptions.
- **`Assigned To` is enforced**: `/build_v2` injects each agent's name into their standing orders. Agents only claim tasks where `Assigned To` matches their own name. Every task MUST have an `Assigned To`.
- Agents cannot ask for clarification mid-task. Every task description must be fully self-contained with all context needed for autonomous execution.
- **Design doc is shared context**: Every builder task description should include a reference to the design doc so agents can consult architecture, patterns, and decisions.

### Team Members
<list ALL team members. The plan specifies exact count, names, and types. /build_v2 deploys exactly what's listed here.>

- Builder
  - Name: <unique name, e.g., "builder-1". Multiple builders get unique names: "builder-1", "builder-2", etc.>
  - Role: <the focus area for this builder, e.g., "API implementation", "database schema">
  - Agent Type: <agent type from TEAM_MEMBERS files or GENERAL_PURPOSE_AGENT. Must be "builder" unless a specialized agent is needed.>
- <add more builders if parallel work is possible. Each gets a unique name.>
- Validator
  - Name: <typically "validator">
  - Role: Validates all acceptance criteria and runs validation commands
  - Agent Type: validator
- Spec Updater
  - Name: spec-updater
  - Role: Writes build evidence into the spec file after all tasks complete
  - Agent Type: spec-updater
- Design Updater
  - Name: design-updater
  - Role: Updates docs/design/<domain>.md with code-aligned design decisions after build completes
  - Agent Type: design-updater

## Step by Step Tasks

- These tasks are executed by self-organizing agents. Agents discover and claim tasks autonomously from the shared task list.
- Each task maps directly to a `TaskCreate` call made by `/build_v2`.
- Task descriptions must be **exhaustive** — agents cannot ask for clarification. Include ALL context: file paths, code patterns, acceptance criteria, and validation commands.
- Every task MUST have an `Assigned To` matching a name in Team Members. This is enforced — tasks without a valid `Assigned To` will not be claimed.
- Every builder task MUST include a `## Design Reference` section pointing to the design doc and the specific patterns/decisions relevant to that task.
- Start with foundational work, then core implementation, then validation.

<list step by step tasks as h3 headers>

### 1. <First Task Name>
- **Task ID**: <unique kebab-case identifier, e.g., "setup-database">
- **Role**: builder
- **Depends On**: <Task ID(s) this depends on, or "none" if no dependencies>
- **Assigned To**: <builder name from Team Members section>
- **Description**: |
    <EXHAUSTIVE description — everything the agent needs to complete this task autonomously>

    ## Design Reference
    - Design doc: docs/design/<domain>.md
    - Relevant patterns: <list patterns from design doc this task must follow>
    - Relevant decisions: <list design decisions that constrain this task>

    ## What to do
    <step-by-step actions>

    ## Files to modify
    - <file path> — <exact changes to make>

    ## Code patterns to follow
    <existing patterns in the codebase to match — reference design doc Patterns section>

    ## Acceptance criteria
    - <specific, verifiable criterion>

    ## Validation command
    <command to verify this specific task>

### 2. <Second Task Name>
- **Task ID**: <unique-id>
- **Role**: builder
- **Depends On**: <previous Task ID, e.g., "setup-database">
- **Assigned To**: <builder name>
- **Description**: |
    <same exhaustive format as above, including ## Design Reference>

### 3. <Continue Pattern>

### N. <Final Validation Task>
- **Task ID**: validate-all
- **Role**: validator
- **Depends On**: <all previous builder Task IDs>
- **Assigned To**: <validator name from Team Members section>
- **Description**: |
    Run all validation commands and verify all acceptance criteria.

    ## Design Reference
    - Design doc: docs/design/<domain>.md
    - Verify implementation matches the architecture described in the design doc

    ## Validation Commands
    <list every command from the Validation Commands section>

    ## Acceptance Criteria
    <list every criterion from the Acceptance Criteria section>

### N+1. <Design Doc Update>
- **Task ID**: update-design-<domain>
- **Role**: design-updater
- **Depends On**: validate-all
- **Assigned To**: design-updater
- **Description**: |
    Update the living design document for the <domain> domain to reflect
    what was actually built in this plan.

    ## Target Design Doc
    docs/design/<domain>.md

    ## Spec File
    specs/<this-plan-filename>.md

    ## Scope
    <describe which domain areas changed — e.g., "API routing layer, pagination
    pattern, new endpoint structure">

    ## Prior Decisions to Check
    <list any prior decisions from the existing design doc that may be affected
    by this build — e.g., "cursor-based pagination decision from 2026-01-28">

    ## What to Record
    Read git diff HEAD~1 HEAD, then the changed source files, then the existing
    design doc. Update Current Design to match the implementation. Append a
    Design Decision entry for each non-trivial architectural choice made in
    this build. Every claim must cite a file:line from the actual code.

<continue with additional tasks as needed>

## Acceptance Criteria
<list specific, measurable criteria that must be met for the task to be considered complete>

## Validation Commands
Execute these commands to validate the task is complete:

<list specific commands to validate the work. Be precise about what to run>
- Example: `cargo test --workspace` - Run all tests
- Example: `cargo clippy --workspace -- -D warnings` - Ensure no clippy warnings

## Notes
<optional additional context, considerations, or dependencies>
```

## Report

After creating and saving both artifacts, provide a concise report with the following format:

```
Design & Implementation Plan Created

Design Document:
  File: docs/design/<domain>.md
  Key Findings:
  - Security: <1-line summary>
  - Correctness: <1-line summary>
  - Performance: <1-line summary>
  - Scalability: <1-line summary>
  Design Decisions: <count> decisions documented

Implementation Plan:
  File: PLAN_OUTPUT_DIRECTORY/<filename>.md
  Topic: <brief description of what the plan covers>
  Key Components:
  - <main component 1>
  - <main component 2>
  - <main component 3>

  Team Task List:
  - <list of tasks, and owner (concise)>

  Team Members:
  - <list of team members and their roles (concise)>

When you're ready, you can execute the plan in a new agent by running:
/build_v2 <replace with path to plan>
```
