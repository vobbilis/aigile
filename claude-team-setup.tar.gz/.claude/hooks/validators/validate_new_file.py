#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.8"
# ///

"""
Stop hook: Validates that a new/modified file exists in the specified directory.

Used by /plan_w_team to ensure a plan file was actually created before
the session ends.

Usage:
  uv run validate_new_file.py --directory specs --extension .md

Exit codes:
  0 = file found (allow)
  2 = no file found (block)
"""

import argparse
import glob
import os
import sys
import time


def main():
    parser = argparse.ArgumentParser(description="Validate a new file exists")
    parser.add_argument("--directory", required=True, help="Directory to check")
    parser.add_argument("--extension", required=True, help="File extension to look for (e.g., .md)")
    args = parser.parse_args()

    # Read and discard stdin (hook protocol sends event data)
    try:
        sys.stdin.read()
    except Exception:
        pass

    directory = args.directory
    extension = args.extension

    # Check if directory exists
    if not os.path.isdir(directory):
        print(
            f"BLOCKED: Directory '{directory}' does not exist.\n"
            f"You must create a plan file in '{directory}/' before completing.",
            file=sys.stderr,
        )
        sys.exit(2)

    # Find files matching the extension
    pattern = os.path.join(directory, f"*{extension}")
    matching_files = glob.glob(pattern)

    if not matching_files:
        print(
            f"BLOCKED: No {extension} files found in '{directory}/'.\n"
            f"You must save your plan to '{directory}/<plan-name>{extension}' before completing.",
            file=sys.stderr,
        )
        sys.exit(2)

    # Check if any file was modified in the last 4 hours. 30 minutes proved too
    # narrow for v4 planning sessions: the Phase C.5 critic panel plus finding
    # adjudication routinely runs past it, false-blocking a session whose spec
    # was long since saved and validated (observed twice, 2026-09-18).
    recent_threshold = time.time() - (240 * 60)
    recent_files = [f for f in matching_files if os.path.getmtime(f) > recent_threshold]

    if not recent_files:
        # The working tree is not the only place a fresh spec can live: a
        # session that authors a spec, commits it, and switches branches
        # (observed 2026-09-18) leaves no recent mtime behind. A commit
        # touching the directory inside the same window is stronger proof
        # the plan was saved than an mtime is.
        import subprocess
        try:
            out = subprocess.run(
                ["git", "log", "--all", "--since", "4 hours ago",
                 "--name-only", "--pretty=format:", "--", directory],
                capture_output=True, text=True, timeout=10,
            ).stdout
            committed = [
                ln for ln in out.splitlines()
                if ln.strip().endswith(extension) and ln.startswith(directory)
            ]
        except Exception:
            committed = []
        if committed:
            print(
                f"OK: no recently modified {extension} files in the working "
                f"tree, but {len(set(committed))} file(s) under "
                f"'{directory}/' were committed within the last 4 hours "
                f"(branch switch after commit) — plan was saved: "
                f"{sorted(set(committed))[0]}"
            )
            sys.exit(0)
        print(
            f"BLOCKED: No recently modified {extension} files in '{directory}/'.\n"
            f"Existing files were not modified this session. Save your plan before completing.",
            file=sys.stderr,
        )
        sys.exit(2)

    # Sort by modification time, newest first
    recent_files.sort(key=os.path.getmtime, reverse=True)
    newest = recent_files[0]
    print(f"Plan file found: {newest}", file=sys.stderr)
    sys.exit(0)


if __name__ == "__main__":
    main()
