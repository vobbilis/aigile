#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.8"
# ///

"""
Stop hook: Validates that the most recently modified v4 spec file in a directory
satisfies the structural TDD guarantees required by /plan_to_build_v4.

v4 = v3 + dynamic model routing: the spec must carry a `## Model Routing`
section, every task must declare a `**Model Class**` (REASONING | STANDARD |
MECHANICAL), and every Team Member must carry a `Model Class:` field. Each
agent's assigned task set must be homogeneous in model class (an agent is one
process with one model for its lifetime).

A v4 spec is single-file artifact combining design rationale (formerly TDD plans)
with build orchestration (formerly v2 specs). This validator enforces that the
spec has:

1. Required SECTIONS — every named section exists
2. Required SUBSECTIONS — Team Members has builder/validator/spec-updater entries
3. Type Surface has CODE — at least one ```rust code block
4. Test Promises has TABLES — at least N test tables with named tests
5. Step by Step Tasks have STRUCTURE — every task has Task ID, Role, Depends On,
   Assigned To, Description, Acceptance criteria, Validation command
6. Acceptance Criteria are NUMBERED — at least N criteria, each labeled AC-N
7. Validation Commands have COMMANDS — at least one ```bash code block with content
8. Build Evidence section exists as PLACEHOLDER — initially DRAFT status
9. Design Grounding cites SPECIFIC documents — at least one ADR or design doc path
10. Filename ends with -v4.md
11. Model Routing section exists; every task and team member has a valid
    Model Class; per-agent task sets are class-homogeneous

Used by /plan_to_build_v4 as a Stop hook to enforce structural TDD fidelity.

Usage:
  uv run validate_v4_spec.py --directory specs --extension .md

Exit codes:
  0 = all guarantees satisfied (allow)
  2 = structural violations found (block)
"""

import argparse
import glob
import os
import re
import sys


REQUIRED_SECTIONS = [
    "## Design Grounding",
    "## Scope",
    "## Type Surface",
    "## Test Promises",
    "## Model Routing",
    "## Step by Step Tasks",
    "## Acceptance Criteria",
    "## Validation Commands",
    "## Team Orchestration",
    "### Team Members",
    "## Build Evidence",
]

# Test categories tracked in `## Test Promises` (subsection name → category key).
# These match the headers /plan_to_build_v3 instructs the author to use.
TEST_CATEGORIES = [
    ("Unit tests", "unit"),
    ("Negative tests", "negative"),
    ("Edge tests", "edge"),
    ("Corner tests", "corner"),
    ("Adversarial tests", "adversarial"),
    ("Property tests", "property"),
    ("Integration tests", "integration"),
    ("Bench tests", "bench"),
    ("Loom tests", "loom"),
    ("Compile-fail tests", "compile_fail"),
]

# Failure-path categories — coverage of these is what differentiates
# a thorough spec from a happy-path-only spec.
FAILURE_PATH_CATEGORIES = {"negative", "edge", "corner", "adversarial", "property"}

# Minimum counts for structural elements
MIN_BUILDER_AGENTS = 1
MIN_TASKS = 2  # at least 1 builder task + 1 validate-all
MIN_ACCEPTANCE_CRITERIA = 2
MIN_VALIDATION_COMMANDS = 1
MIN_TYPE_SURFACE_CODE_BLOCKS = 1  # at least one rust block in Type Surface
MIN_TEST_PROMISE_ROWS = 2  # at least 2 named tests across categories
MIN_DESIGN_GROUNDING_REFS = 1  # at least one ADR or design doc cited

# Coverage discipline thresholds
WARN_FAILURE_PATH_FRACTION = 0.30  # warn if <30% of tests are failure-path


def find_section(content: str, header: str) -> tuple:
    """Return (start_line_idx, end_line_idx) of a section by header.
    end_line_idx is the line of the next sibling header (same level or higher), or len(lines).
    Returns (-1, -1) if header not found.
    """
    lines = content.split("\n")
    header_level = len(header) - len(header.lstrip("#"))
    start = -1
    for i, line in enumerate(lines):
        if line.strip() == header:
            start = i
            break
    if start == -1:
        return (-1, -1)
    # Find end: next header at same or higher level
    end = len(lines)
    for j in range(start + 1, len(lines)):
        line = lines[j]
        if line.startswith("#"):
            this_level = len(line) - len(line.lstrip("#"))
            if this_level <= header_level and line[this_level:this_level+1] == " ":
                end = j
                break
    return (start, end)


def section_text(content: str, header: str) -> str:
    """Return the text between a section header and the next sibling header."""
    start, end = find_section(content, header)
    if start == -1:
        return ""
    lines = content.split("\n")
    return "\n".join(lines[start:end])


def count_tests_per_category(test_promises_text: str) -> dict:
    """Count test rows under each `### <Category> tests` subsection.

    Returns dict mapping category key (e.g. 'unit', 'negative') to row count.
    A row is a markdown table row that contains a backticked test name and
    is not a header/separator row.
    """
    counts = {key: 0 for _, key in TEST_CATEGORIES}

    lines = test_promises_text.split("\n")
    current_category = None

    for line in lines:
        stripped = line.strip()

        # Detect category subheader (### Unit tests, ### Negative tests, etc.)
        if stripped.startswith("### "):
            current_category = None
            for header_text, key in TEST_CATEGORIES:
                # Match "### Unit tests", "### Unit tests (4)", "### Negative tests — ...", etc.
                if re.match(rf"###\s+{re.escape(header_text)}\b", stripped, re.IGNORECASE):
                    current_category = key
                    break
            continue

        if current_category is None:
            continue

        # Skip non-table lines, separator rows
        if not stripped.startswith("|"):
            continue
        if "---" in stripped:
            continue
        # Skip header row (typical: | Test name | Target file | What it proves |)
        # Header rows have field names; data rows have backticked test names.
        # Heuristic: a data row contains a backticked identifier in the first cell.
        first_cell = stripped.split("|", 2)[1] if stripped.count("|") >= 2 else ""
        if not re.search(r"`[a-z][a-z0-9_]+`", first_cell):
            # Sometimes test names appear unbracketed
            if not re.match(r"^\|\s*[a-z][a-z0-9_]+\s*\|", stripped):
                continue

        counts[current_category] += 1

    return counts


def detect_failure_surface_signals(type_surface_text: str) -> list:
    """Detect signals in `## Type Surface` that imply specific failure paths
    must be tested.

    Returns list of (signal_name, required_test_categories, hint) tuples.
    """
    signals = []
    text = type_surface_text

    # 1. thiserror::Error enum → Negative tests required
    if "thiserror::Error" in text or re.search(r"#\[derive\([^)]*Error[^)]*\)\]", text):
        signals.append((
            "thiserror::Error enum (error type)",
            {"negative"},
            "Errors must have at least one Negative test proving malformed/invalid "
            "input is rejected with the correct error code and HTTP status.",
        ))

    # 2. IntoResponse impl → Negative test required (HTTP correctness)
    if re.search(r"impl\s+(?:axum::response::)?IntoResponse\s+for", text):
        signals.append((
            "IntoResponse impl (HTTP error mapping)",
            {"negative"},
            "IntoResponse impls must have at least one Negative test proving "
            "header semantics (e.g., WWW-Authenticate is set ONLY for the right "
            "variants, not all error responses).",
        ))

    # 3. Config struct with TTL/path/URL fields → Edge tests required
    has_config_struct = re.search(r"pub\s+struct\s+\w*Config\b", text)
    has_ttl_field = re.search(r"\b(ttl|timeout|expir|grace)\w*:\s*", text, re.IGNORECASE)
    has_path_field = re.search(r"\b(path|file|dir):\s*(?:&str|String|PathBuf|Path)", text, re.IGNORECASE)
    has_url_field = re.search(r"\b(url|endpoint|issuer|iss):\s*(?:&str|String|Url|reqwest::Url)", text, re.IGNORECASE)
    if has_config_struct and (has_ttl_field or has_path_field or has_url_field):
        boundary_kinds = []
        if has_ttl_field:
            boundary_kinds.append("zero/negative TTL")
        if has_path_field:
            boundary_kinds.append("missing/unreadable path")
        if has_url_field:
            boundary_kinds.append("malformed URL")
        signals.append((
            "Config struct with TTL/path/URL fields",
            {"edge", "negative"},
            f"Config types must have at least one Edge or Negative test for boundary "
            f"conditions: {', '.join(boundary_kinds)}.",
        ))

    # 4. Subsystem / aggregator with state → Corner OR Adversarial test required
    if re.search(r"pub\s+struct\s+\w*Subsystem\b", text) or "aggregat" in text.lower():
        signals.append((
            "Subsystem / stateful aggregator",
            {"corner", "adversarial"},
            "Stateful aggregators must have at least one Corner test (concurrency / "
            "interleaving) OR Adversarial test (panic isolation / hostile input).",
        ))

    # 5. Builder pattern (router(), build()) → Negative or Corner test required
    if re.search(r"fn\s+(?:router|build)\s*\([^)]*\)\s*->", text):
        signals.append((
            "Builder pattern (router()/build() method)",
            {"negative", "corner"},
            "Builder methods must have at least one Negative test (misuse — double "
            "mount, missing prerequisite, etc.) OR Corner test (back-compat with "
            "legacy callers).",
        ))

    # 6. Cryptographic verify/sign → Adversarial test required
    if re.search(r"\b(verify|verify_strict|sign|signature)\b.*(?:Vec<u8>|&\[u8\])", text):
        signals.append((
            "Cryptographic verify / sign primitive",
            {"adversarial"},
            "Cryptographic primitives must have at least one Adversarial test "
            "(tampered signature rejected, malformed bytes rejected, replay "
            "rejected).",
        ))

    # 7. Bounded data structure → Edge test required
    if re.search(r"\b(?:capacity|max_size|max_capacity|bounded)\b", text, re.IGNORECASE):
        signals.append((
            "Bounded data structure (capacity / TTL eviction)",
            {"edge"},
            "Bounded structures must have at least one Edge test proving capacity "
            "limit is enforced and eviction (LRU/TTL) works correctly.",
        ))

    return signals


def validate(filepath: str, content: str) -> list:
    """Return a list of violations. Empty list = valid."""
    violations = []

    # 0. Filename must end with -v4.md
    if not filepath.endswith("-v4.md"):
        violations.append(
            f"Filename '{os.path.basename(filepath)}' must end with '-v4.md' "
            f"(v4 specs use this suffix to distinguish from v3)."
        )

    # 1. Required sections must all exist
    for section in REQUIRED_SECTIONS:
        if section not in content:
            violations.append(f"Missing required section: '{section}'")

    # If foundational sections are missing, downstream checks are pointless
    if violations:
        return violations

    # 2. Team Members must have at least one builder, one validator, one spec-updater
    team = section_text(content, "### Team Members")
    builder_count = len(re.findall(r"^\s*-\s*Builder\s*$", team, re.MULTILINE | re.IGNORECASE))
    if builder_count < MIN_BUILDER_AGENTS:
        violations.append(
            f"### Team Members must list at least {MIN_BUILDER_AGENTS} Builder "
            f"(found {builder_count}). Each builder needs a unique Name and Agent Type."
        )
    if "Validator" not in team:
        violations.append("### Team Members must list a Validator entry.")
    if "Spec Updater" not in team and "spec-updater" not in team:
        violations.append("### Team Members must list a Spec Updater entry.")

    # Each builder must have Name, Role, Agent Type
    builder_blocks = re.findall(
        r"^-\s*Builder\s*$(.*?)(?=^-\s+\w|\Z)",
        team,
        re.MULTILINE | re.IGNORECASE | re.DOTALL,
    )
    for i, block in enumerate(builder_blocks):
        if "Name:" not in block:
            violations.append(f"Builder #{i+1} missing 'Name:' field.")
        if "Role:" not in block:
            violations.append(f"Builder #{i+1} missing 'Role:' field.")
        if "Agent Type:" not in block:
            violations.append(f"Builder #{i+1} missing 'Agent Type:' field.")
        if "Model Class:" not in block:
            violations.append(
                f"Builder #{i+1} missing 'Model Class:' field "
                f"(v4 requires REASONING | STANDARD | MECHANICAL per agent)."
            )

    # 3. Type Surface section must have at least one ```rust code block
    type_surface = section_text(content, "## Type Surface")
    rust_blocks = re.findall(r"```rust\n.*?\n```", type_surface, re.DOTALL)
    if len(rust_blocks) < MIN_TYPE_SURFACE_CODE_BLOCKS:
        violations.append(
            f"## Type Surface must contain at least {MIN_TYPE_SURFACE_CODE_BLOCKS} "
            f"```rust code block (found {len(rust_blocks)}). Each new type needs a "
            f"full Rust signature, not prose."
        )

    # 4. Test Promises must have named test rows in tables
    test_promises = section_text(content, "## Test Promises")
    # Match table rows that look like test entries: `| <name> | <file> | <description> |`
    # Drop header rows (those with '---')
    test_rows = re.findall(r"^\|\s*[`a-z][a-z0-9_]+(?:\s*[|`]).*\|.*\|", test_promises, re.MULTILINE)
    # Filter out separator rows
    test_rows = [r for r in test_rows if "---" not in r]
    if len(test_rows) < MIN_TEST_PROMISE_ROWS:
        violations.append(
            f"## Test Promises must list at least {MIN_TEST_PROMISE_ROWS} named tests "
            f"in markdown tables (found {len(test_rows)}). Each test gets a row: "
            f"`| test_name | target_file | what it proves |`"
        )

    # 5. Step by Step Tasks — every task must have all required fields
    tasks_section = section_text(content, "## Step by Step Tasks")
    # Find all h3 task headers in this section
    task_headers = re.findall(r"^### \d+\.\s+.+$", tasks_section, re.MULTILINE)
    if len(task_headers) < MIN_TASKS:
        violations.append(
            f"## Step by Step Tasks must list at least {MIN_TASKS} tasks "
            f"(found {len(task_headers)}). Format: `### N. <Task Name>`. "
            f"At minimum, one builder task and one validator task."
        )

    # For each task, check required fields appear within its block
    task_blocks = re.split(r"^### \d+\.\s+", tasks_section, flags=re.MULTILINE)[1:]
    for i, block in enumerate(task_blocks):
        # Take only first ~50 lines per task (rough bound)
        block_text = block[:8000]
        task_name = block_text.split("\n", 1)[0].strip()
        required_fields = [
            "**Task ID**",
            "**Role**",
            "**Depends On**",
            "**Assigned To**",
            "**Model Class**",
            "**Description**",
        ]
        for field in required_fields:
            if field not in block_text:
                violations.append(
                    f"Task #{i+1} '{task_name}' missing required field: {field}"
                )

        # Each builder task description must include validation command and acceptance criteria
        if "**Role**: builder" in block_text or "**Role:** builder" in block_text:
            if "## Acceptance criteria" not in block_text and "## Acceptance Criteria" not in block_text:
                violations.append(
                    f"Builder task #{i+1} '{task_name}' description missing "
                    f"'## Acceptance criteria' subsection."
                )
            if "## Validation command" not in block_text and "## Validation Command" not in block_text:
                violations.append(
                    f"Builder task #{i+1} '{task_name}' description missing "
                    f"'## Validation command' subsection."
                )
            # v3 requires Type Surface Reference and Test Promises Reference
            if "## Type Surface Reference" not in block_text:
                violations.append(
                    f"Builder task #{i+1} '{task_name}' description missing "
                    f"'## Type Surface Reference' subsection (v3 requires every "
                    f"builder task to reference the spec's Type Surface section)."
                )
            if "## Test Promises Reference" not in block_text:
                violations.append(
                    f"Builder task #{i+1} '{task_name}' description missing "
                    f"'## Test Promises Reference' subsection (v3 requires every "
                    f"builder task to reference the spec's Test Promises section)."
                )

    # 6. At least one task with role: validator must exist
    if "**Role**: validator" not in tasks_section and "**Role:** validator" not in tasks_section:
        violations.append(
            "## Step by Step Tasks must include at least one task with "
            "'**Role**: validator' (typically the validate-all task at the end)."
        )

    # 7. Acceptance Criteria must have at least N numbered AC-N items
    ac_section = section_text(content, "## Acceptance Criteria")
    ac_items = re.findall(r"^\s*-\s*AC-\d+:", ac_section, re.MULTILINE)
    if len(ac_items) < MIN_ACCEPTANCE_CRITERIA:
        violations.append(
            f"## Acceptance Criteria must contain at least {MIN_ACCEPTANCE_CRITERIA} "
            f"numbered criteria labeled 'AC-N:' (found {len(ac_items)}). "
            f"Format: `- AC-1: <criterion>`"
        )

    # 8. Validation Commands must have at least one bash code block with content
    val_section = section_text(content, "## Validation Commands")
    bash_blocks = re.findall(r"```bash\n(.*?)\n```", val_section, re.DOTALL)
    non_empty_blocks = [b for b in bash_blocks if b.strip()]
    if len(non_empty_blocks) < MIN_VALIDATION_COMMANDS:
        # Also accept inline `commands` if no fenced block exists
        inline_commands = re.findall(r"`[a-z][a-z0-9_-]+\s+[^`]+`", val_section)
        if len(inline_commands) == 0:
            violations.append(
                f"## Validation Commands must contain at least one ```bash code block "
                f"with executable commands, OR inline `command` references "
                f"(found {len(non_empty_blocks)} bash blocks, {len(inline_commands)} inline)."
            )

    # 9. Design Grounding must cite at least one ADR or design doc
    grounding = section_text(content, "## Design Grounding")
    adr_refs = re.findall(r"docs/arch/adr/ADR-\d+", grounding, re.IGNORECASE)
    design_refs = re.findall(r"docs/design/[\w/-]+\.md", grounding, re.IGNORECASE)
    other_refs = re.findall(r"specs/[\w/-]+\.md", grounding, re.IGNORECASE)
    total_refs = len(adr_refs) + len(design_refs) + len(other_refs)
    if total_refs < MIN_DESIGN_GROUNDING_REFS:
        violations.append(
            f"## Design Grounding must cite at least {MIN_DESIGN_GROUNDING_REFS} "
            f"ADR (docs/arch/adr/ADR-NNN), design doc (docs/design/...), or "
            f"prior spec (specs/...). Found {total_refs} references."
        )

    # 10. Build Evidence section must contain a placeholder marker (DRAFT/empty)
    evidence = section_text(content, "## Build Evidence")
    # Acceptable markers: "DRAFT", "will be filled", or simply empty body
    has_placeholder_marker = (
        "DRAFT" in evidence
        or "will be filled" in evidence.lower()
        or "spec-updater" in evidence.lower()
    )
    # If section has substantive content (multiple lines beyond header), that's also fine
    # because spec-updater may have already populated it
    evidence_lines = [ln for ln in evidence.split("\n")[1:] if ln.strip()]
    has_real_content = len(evidence_lines) >= 5
    if not has_placeholder_marker and not has_real_content:
        violations.append(
            "## Build Evidence must contain either a placeholder marker "
            "('DRAFT', 'will be filled by spec-updater') OR real evidence content "
            "(if /build_v3 has already populated it). Section is empty."
        )

    # 11. Status line at the top must be present
    if not re.search(r"^>\s*\*\*Status:\*\*", content, re.MULTILINE):
        violations.append(
            "Spec must start with a `> **Status:**` line at the top "
            "(immediately after the # title)."
        )

    # 12. Failure-surface signal detection — coverage discipline (HARD GATE)
    #
    # Inspect `## Type Surface` for signals that imply specific test categories
    # are required. If a signal is present but the matching category has zero
    # tests, BLOCK the spec. This prevents happy-path-only authoring.
    signals = detect_failure_surface_signals(type_surface)
    category_counts = count_tests_per_category(test_promises)

    for signal_name, required_categories, hint in signals:
        # Pass if AT LEAST ONE of the required categories has tests
        satisfied = any(category_counts.get(cat, 0) > 0 for cat in required_categories)
        if not satisfied:
            cats_str = " / ".join(sorted(required_categories))
            violations.append(
                f"COVERAGE GAP: spec introduces {signal_name} but has zero tests "
                f"in [{cats_str}] categories. {hint}"
            )

    # 13. Failure Surface Inventory subsection check
    #
    # /plan_to_build_v3 instructs the author to enumerate failure modes per type
    # in `### <Type> — Failure Surface` blocks within `## Type Surface`. If any
    # signals were detected, we expect at least one such block to exist.
    if signals:
        has_failure_surface_block = bool(
            re.search(r"^###\s+\w[\w\s]*[—-]\s+Failure\s+Surface", type_surface, re.MULTILINE | re.IGNORECASE)
        )
        if not has_failure_surface_block:
            violations.append(
                f"COVERAGE DISCIPLINE: spec introduces "
                f"{len(signals)} failure-surface-bearing type(s) but has no "
                f"`### <TypeName> — Failure Surface` enumeration in `## Type Surface`. "
                f"Per /plan_to_build_v3 authoring rules, every type with a failure "
                f"surface must have an inventory block listing how it can fail. "
                f"Then `## Test Promises` must have one test per non-trivial failure mode."
            )

    return violations


def coverage_breakdown(content: str) -> tuple:
    """Return (counts_dict, total, failure_path_count, failure_path_fraction).

    Used by main() to print a coverage summary even when validation passes.
    """
    test_promises = section_text(content, "## Test Promises")
    counts = count_tests_per_category(test_promises)
    total = sum(counts.values())
    failure_path = sum(counts[k] for k in FAILURE_PATH_CATEGORIES if k in counts)
    fraction = (failure_path / total) if total > 0 else 0.0
    return (counts, total, failure_path, fraction)



VALID_MODEL_CLASSES = {"REASONING", "STANDARD", "MECHANICAL"}


def validate_model_routing(content: str) -> list:
    """v4-only checks: Model Class values are valid, the Model Routing section
    has an assignment table, and each agent's task set is class-homogeneous."""
    violations = []

    routing = section_text(content, "## Model Routing")
    if "| Agent" not in routing and "| agent" not in routing:
        violations.append(
            "## Model Routing must contain an assignment table with an "
            "'| Agent | Model Class | ...' header mapping every team member "
            "to a model class."
        )

    # Every **Model Class** value in tasks must be a valid class
    per_agent = {}
    tasks_section = section_text(content, "## Step by Step Tasks")
    task_blocks = re.split(r"^### \d+\.\s+", tasks_section, flags=re.MULTILINE)[1:]
    for i, block in enumerate(task_blocks):
        block_text = block[:8000]
        task_name = block_text.split("\n", 1)[0].strip()
        m = re.search(r"\*\*Model Class\*\*:?\s*`?([A-Za-z]+)`?", block_text)
        if not m:
            continue  # missing-field violation already reported by validate()
        cls = m.group(1).upper()
        if cls not in VALID_MODEL_CLASSES:
            violations.append(
                f"Task #{i+1} '{task_name}' has invalid Model Class '{m.group(1)}' "
                f"(must be one of {sorted(VALID_MODEL_CLASSES)})."
            )
            continue
        a = re.search(r"\*\*Assigned To\*\*:?\s*`?([\w-]+)`?", block_text)
        if a:
            per_agent.setdefault(a.group(1), set()).add(cls)

    # Homogeneity: one agent = one process = one model for its lifetime
    for agent, classes in sorted(per_agent.items()):
        if len(classes) > 1:
            violations.append(
                f"Agent '{agent}' is assigned tasks of mixed model classes "
                f"{sorted(classes)}. Each agent's task set must be homogeneous — "
                f"split the work across two agents or promote every task to the "
                f"highest class present (promote, never demote)."
            )

    return violations


def main():
    parser = argparse.ArgumentParser(description="Validate v4 spec structural TDD guarantees")
    parser.add_argument("--directory", required=True, help="Directory containing specs")
    parser.add_argument("--extension", default=".md", help="File extension (default .md)")
    args = parser.parse_args()

    # Read and discard stdin (hook protocol)
    try:
        sys.stdin.read()
    except Exception:
        pass

    pattern = os.path.join(args.directory, f"*{args.extension}")
    matching = glob.glob(pattern)

    if not matching:
        print(
            f"BLOCKED: No {args.extension} files found in '{args.directory}/'. "
            f"Cannot validate v4 spec — no spec file was written.",
            file=sys.stderr,
        )
        sys.exit(2)

    # Most recently modified file
    matching.sort(key=os.path.getmtime, reverse=True)
    target = matching[0]

    try:
        with open(target, "r") as f:
            content = f.read()
    except (OSError, IOError) as e:
        print(f"BLOCKED: Cannot read '{target}': {e}", file=sys.stderr)
        sys.exit(2)

    # The spec-format template marks required sections with a ★ (e.g.
    # '## ★ Scope'); authors sometimes carry that marker into real headings.
    # Normalize it away so both styles validate identically.
    content = re.sub(r"^(#{2,3})\s*★\s*", r"\1 ", content, flags=re.MULTILINE)

    violations = validate(target, content)
    if "## Model Routing" in content:
        violations.extend(validate_model_routing(content))

    # Always compute and print the coverage breakdown — visible whether
    # validation passes or fails. This makes happy-path-only specs noticeable
    # to a human reviewer even if the hard rules don't trip.
    counts, total, failure_path, fraction = coverage_breakdown(content)

    def render_breakdown() -> str:
        lines = [
            f"  Total tests: {total}",
            f"  Categories: "
            + ", ".join(f"{k}={counts.get(k, 0)}" for _, k in TEST_CATEGORIES),
        ]
        if total > 0:
            pct = int(fraction * 100)
            lines.append(
                f"  Failure-path coverage: {failure_path}/{total} = {pct}% "
                f"(target ≥{int(WARN_FAILURE_PATH_FRACTION * 100)}%)"
            )
        return "\n".join(lines)

    if violations:
        print(
            f"BLOCKED: v4 spec '{target}' fails structural TDD validation:\n",
            file=sys.stderr,
        )
        for i, v in enumerate(violations, 1):
            print(f"  {i}. {v}", file=sys.stderr)
        print(
            "\nCoverage breakdown:\n" + render_breakdown(),
            file=sys.stderr,
        )
        print(
            "\nFix these issues before completing. v4 specs must satisfy ALL of:\n"
            "  - Filename ends with -v4.md\n"
            "  - Model Routing section + valid, homogeneous Model Class fields\n"
            "  - All required sections present\n"
            "  - Team Members has Builder + Validator + Spec Updater\n"
            "  - Type Surface has full Rust signatures (not prose)\n"
            "  - Type Surface has `### <TypeName> — Failure Surface` block per "
            "failure-surface-bearing type\n"
            "  - Test Promises has named tests in tables (not prose)\n"
            "  - Test Promises covers failure-surface signals "
            "(error types → Negative tests, Config → Edge, etc.)\n"
            "  - Each builder task has Type Surface Reference, Test Promises Reference,\n"
            "    Acceptance criteria, and Validation command subsections\n"
            "  - Acceptance Criteria numbered as AC-N\n"
            "  - Validation Commands has executable bash\n"
            "  - Design Grounding cites ADR/design doc/spec by path\n"
            "  - Build Evidence has DRAFT placeholder or real content\n"
            "  - Status line at top",
            file=sys.stderr,
        )
        sys.exit(2)

    # Validation passed. Emit a coverage breakdown and a warning if the spec
    # is happy-path-skewed (under the failure-path threshold). The warning
    # does NOT block — but it surfaces the imbalance so the human notices.
    print(
        f"v4 spec '{target}' passes structural TDD guarantees.", file=sys.stderr
    )
    print("\nCoverage breakdown:\n" + render_breakdown(), file=sys.stderr)

    if total > 0 and fraction < WARN_FAILURE_PATH_FRACTION:
        pct = int(fraction * 100)
        target_pct = int(WARN_FAILURE_PATH_FRACTION * 100)
        print(
            f"\nWARNING: failure-path coverage is {pct}%, below the {target_pct}% "
            f"target. Consider adding Negative / Edge / Corner / Adversarial / "
            f"Property tests to exercise failure modes of the types in `## Type "
            f"Surface`. The hard failure-surface gates passed, but the overall "
            f"distribution is happy-path-skewed.",
            file=sys.stderr,
        )

    sys.exit(0)


if __name__ == "__main__":
    main()
