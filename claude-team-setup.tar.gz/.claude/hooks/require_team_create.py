#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.8"
# ///

"""
PreToolUse hook: Enforces that self-organizing teammates are spawned as
NAMED team members, not anonymous background agents.

Context (Claude Code >= 2.1.x): the explicit TeamCreate/Task tools were
removed. Teammates are now spawned via the `Agent` tool and join the
session's implicit team automatically. The old "call TeamCreate first"
rule is therefore obsolete. What still matters is the anti-pattern this
hook originally guarded against: launching anonymous background agents
that never appear as proper, addressable team members.

Rule (current):
  If `Agent` is called with run_in_background=true but WITHOUT a `name`
  → BLOCK with: "Give background agents a name so they join the team."

The legacy `Task` tool (with team_name) is still accepted if present, for
backward compatibility with older CLI builds.

Exit codes:
  0 = allow
  2 = block
"""

import json
import os
import sys
import glob

MARKER_FILE = os.path.expanduser("~/.claude/.team_lead_session")


def has_team_spec() -> bool:
    """Check if any ACTIVE spec file contains a Team Orchestration section.

    Skips specs that are completed/superseded by checking for:
    - Filename contains 'SUPERSEDED' or 'COMPLETE'
    - File starts with 'SUPERSEDED', 'COMPLETE', or 'DONE'
    - File contains '## Status: Complete' or '## Status: Done'
    - .bak extension
    """
    spec_files = glob.glob("specs/*.md")
    for spec_path in spec_files:
        basename = os.path.basename(spec_path).upper()
        # Skip files that look completed/superseded by name
        if any(marker in basename for marker in ["SUPERSEDED", "COMPLETE", "DONE", ".BAK"]):
            continue
        try:
            with open(spec_path, "r") as f:
                content = f.read(10000)  # Read first 10KB
                # Skip files marked complete/done in content
                if any(marker in content for marker in [
                    "## Status: Complete",
                    "## Status: Done",
                    "Status: COMPLETE",
                    "Status: DONE",
                    "Status:** COMPLETE",
                    "Status:** Done",
                    "SUPERSEDED",
                ]):
                    continue
                if "Team Orchestration" in content or "## Team Members" in content:
                    return True
        except (OSError, IOError):
            continue
    return False


def team_is_active() -> bool:
    """Check if a team has been created (marker file exists)."""
    return os.path.exists(MARKER_FILE)


def get_team_name() -> str:
    """Get the active team name from the marker file."""
    try:
        with open(MARKER_FILE) as f:
            marker = json.load(f)
            return marker.get("team_name", "")
    except (json.JSONDecodeError, OSError):
        return ""


def main():
    try:
        input_data = json.load(sys.stdin)
        tool_name = input_data.get("tool_name", "")
        tool_input = input_data.get("tool_input", {})
        session_id = input_data.get("session_id", "")

        # Only intercept agent-spawning tools. `Agent` is the current tool;
        # `Task` is the legacy name kept for older CLI builds.
        if tool_name not in ("Agent", "Task"):
            sys.exit(0)

        # Bug pipeline manages its own agent lifecycle — allow through
        bug_pipeline_state = os.path.expanduser("~/.claude/.bug_pipeline_state")
        if os.path.exists(bug_pipeline_state):
            sys.exit(0)

        # Legacy `Task` tool (older CLI builds): keep the original team_name
        # requirement so those flows still behave.
        if tool_name == "Task":
            if team_is_active():
                team_name_param = tool_input.get("team_name", "")
                if not team_name_param:
                    active_team = get_team_name()
                    print(
                        f"BLOCKED: Team '{active_team}' is active but your Task call is missing team_name.\n"
                        f"Add team_name='{active_team}' to spawn a proper team member.\n"
                        f"Anonymous background agents are not allowed when a team is active.",
                        file=sys.stderr,
                    )
                    sys.exit(2)
            sys.exit(0)

        # Current `Agent` tool: a background teammate MUST be named, so it
        # joins the implicit team as an addressable member instead of an
        # anonymous fire-and-forget agent. Foreground Agent calls (one-shot
        # helpers) are allowed unnamed.
        run_in_background = tool_input.get("run_in_background", False)
        name = (tool_input.get("name") or "").strip()
        if run_in_background and not name:
            print(
                "BLOCKED: Background Agent calls must include a `name`.\n"
                "A named teammate joins the session's implicit team and is\n"
                "addressable via SendMessage / TaskStop; an unnamed background\n"
                "agent is a fire-and-forget process with no team membership.\n"
                "Add name=\"<role-or-lens>\" to your Agent call.",
                file=sys.stderr,
            )
            sys.exit(2)

        sys.exit(0)

    except json.JSONDecodeError:
        sys.exit(0)
    except Exception:
        sys.exit(0)


if __name__ == "__main__":
    main()
