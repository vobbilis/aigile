# Claude Code Team Setup (v4)

A portable `~/.claude` package: the `/plan_to_build_v4` → `/build_v4` pipeline with
self-organizing agent teams in tmux panes, dynamic model routing, a plan-time red
team, and the `/bug_to_pr` pipeline. Earlier versions (`/plan_to_build`, `/build`,
`_v2`, `_v3`) ship alongside for older specs.

## Prerequisites

- [ ] [Claude Code CLI](https://claude.ai/download) installed
- [ ] `uv` installed — `brew install uv` or `curl -LsSf https://astral.sh/uv/install.sh | sh`
- [ ] `tmux` installed — `brew install tmux`
- [ ] `gh` CLI installed and authenticated — `brew install gh && gh auth login`
- [ ] `jq` installed — `brew install jq` (used by the build lead's shutdown backstop)

## Install

```bash
tar -xzf claude-team-setup.tar.gz -C ~/
```

> If you already have a `~/.claude` directory, use `--keep-old-files` to avoid overwriting existing config:
> ```bash
> tar -xzf claude-team-setup.tar.gz -C ~/ --keep-old-files
> ```

## First-time setup in any project

- `cd` into your project directory
- Create the output folders: `mkdir -p specs docs/design docs/arch/adr`
- Create `.github/bug-modules.json` to map modules to fixer agents (required for `/bug_to_pr`)
- Start tmux, then Claude Code: `tmux new-session -s work` then `claude`

## Key commands

| Command | What it does |
| --- | --- |
| `/plan_to_build_v4 "<design pointer + task>"` | Writes one TDD-grade spec to `specs/<name>-v4.md`: design grounding, Type Surface, named Test Promises, task graph, Model Routing. Medium/complex drafts are red-teamed by four read-only critics before the Stop hook lets the session end. |
| `/build_v4 specs/<name>-v4.md` | Team lead resolves each agent's Model Class to a model slot, verifies the binding, deploys builders + validator once, waits for `validate-all`, then deploys spec-updater + design-updater. Writes Build Evidence and a routing lesson back into the spec. |
| `/bug_to_pr "<bug description>"` | Six-phase bug pipeline: triage → route → fix with test evidence → PR → two isolated adversarial reviews → merge gate with your confirmation. |
| `/plan_to_build_v3` → `/build_v3` | Same unified spec without model routing. Use for existing `-v3.md` specs. |
| `/plan_to_build_v2` → `/build_v2`, `/plan_to_build` → `/build` | Earlier generations, kept for older specs. |

## How v4 works

1. **Plan.** `/plan_to_build_v4` reads the ADRs and design doc you point it at, verifies every
   `file:line` reference itself, and authors the spec in stages. Every type gets a Failure
   Surface; every failure bullet becomes a named test. Every task gets an `Assigned To` and a
   `Model Class`.
2. **Route.** Tasks are classified by shape, and the team is partitioned so each agent holds a
   single class:
   - `REASONING` → `opus` slot — design judgment, concurrency, crypto, dense failure surfaces
   - `STANDARD` → `sonnet` slot — the default; test construction, the validator
   - `MECHANICAL` → `haiku` slot — byte-specified diffs with a validation command that catches errors
   The spec never names a physical model. What each slot resolves to is decided by how you
   launch Claude Code (see *Model slots* below).
3. **Red team.** For medium/complex specs, four critics run in parallel: failure-surface
   adversary, grounding auditor, omissions critic, routing challenger. The author accepts or
   rejects each finding with a reason and records the panel in the spec.
4. **Build.** `/build_v4` checks it is inside tmux with `teammateMode: tmux`, creates the team
   and task graph, probes each slot with a one-shot teammate, reads the physical model from the
   teammate's transcript, applies promote-only fallback for dead slots, announces the routing
   table, and deploys Wave 1 (builders + validator) with `model: <slot>` on every agent.
5. **Validate.** The validator runs every command and acceptance criterion and checks each
   promised type and test exists. On failure it creates a fix task for the original builder and
   the lead wakes that builder. Max 2 fix cycles, then escalation.
6. **Evidence.** On `validate-all` PASS the lead composes a Model Routing Retro (RIGHT /
   OVER-PROVISIONED / UNDER-PROVISIONED per agent), then deploys Wave 2: spec-updater writes
   Build Evidence and appends the lesson to `~/.claude/model-routing-ledger.md`; design-updater
   rewrites `docs/design/<domain>.md` from the git diff.
7. **Shutdown.** Polite `shutdown_request` → `TeamDelete` retry → tmux pane kill backstop.

## Model slots

Slots are `opus`, `sonnet`, `haiku`. With a plain `claude` session they resolve to the
provider's stock models and the classes express cost tiering only — the flow works unchanged.
To route across backends, launch Claude Code through a proxy or launcher that binds
`ANTHROPIC_DEFAULT_OPUS_MODEL`, `ANTHROPIC_DEFAULT_SONNET_MODEL` and
`ANTHROPIC_DEFAULT_HAIKU_MODEL` to different models (for example Bedrock for `opus` and a local
vLLM or SGLang model for `haiku`). Teammates do not always inherit the launcher's environment;
that is why `/build_v4` verifies the binding from teammate transcripts before trusting it.

## The routing ledger

`~/.claude/model-routing-ledger.md` is append-only. Each `/build_v4` adds an `RL-NNN` entry
with the transcript-verified slot→model binding, a verdict per agent, and lessons with an
`apply when:` condition. `/plan_to_build_v4` reads it before classifying anything. The shipped
file contains the format header and one worked example (RL-001).

## Per-project config for the bug pipeline

Create `.github/bug-modules.json` in your project root to map modules to fixer agents:

```json
{
  "modules": {
    "frontend": {
      "fixer_agent": "bug-fixer-frontend",
      "paths": ["frontend/", "src/components/"]
    },
    "api": {
      "fixer_agent": "bug-fixer-api",
      "paths": ["backend/", "src/routes/"]
    }
  },
  "default_fixer": "bug-fixer-api"
}
```

See the `aigile` repo for a working example.

## tmux pane controls (once agents are running)

- `Ctrl+a |` — split pane vertically
- `Ctrl+a -` — split pane horizontally
- `Ctrl+a` + arrow keys — navigate between panes
- Mouse clicks also work for pane selection and scrolling

## What is in the package

- `commands/` — `plan_to_build{,_v2,_v3,_v4}.md`, `build{,_v2,_v3,_v4}.md`, `bug_to_pr.md`
- `agents/team/` — builder, validator, spec-updater, design-updater, and the bug pipeline agents
- `hooks/` — Python lifecycle hooks run with `uv run`; `hooks/validators/` includes
  `validate_v3_spec.py` and `validate_v4_spec.py`
- `skills/` — the engineering skills library
- `settings.json` — hook wiring, `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`, `teammateMode: tmux`
- `model-routing-ledger.md` — ledger header + RL-001
- `statusline-command.sh` — context-window status line

## Notes

- Specs are saved to `specs/` in your project root — commit them alongside your code
- Agent teams require an active tmux session; `/build_v4` stops and tells you if it is not in one
- The `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` env var is pre-configured in `~/.claude/settings.json`
- Full architecture and the v1→v4 evolution: https://vobbilis.github.io/aigile/arch/claude-local-architecture-v4.html
