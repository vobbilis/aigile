# claude-team-setup

Pre-built Claude Code configuration for multi-agent pipelines. Untar into `~/` and the full stack is immediately available in any project.

```bash
tar -xzf claude-team-setup.tar.gz -C ~/
```

Requires `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` — already set in the bundled `settings.json`.

---

## What's Included

### Commands (`~/.claude/commands/`)

| Command | Skill | Description |
|---------|-------|-------------|
| `/plan_to_build` | `plan_to_build.md` | Generate an implementation plan spec |
| `/plan_to_build_v2` | `plan_to_build_v2.md` | v2 plan with enforced task ownership |
| `/build` | `build.md` | Execute a plan spec with a self-organizing agent team |
| `/build_v2` | `build_v2.md` | v2 build with indefinite polling and liveness detection |
| `/bug_to_pr` | `bug_to_pr.md` | End-to-end bug pipeline: triage → fix → PR → adversarial review → merge |

### Team Agents (`~/.claude/agents/team/`)

| Agent | Role |
|-------|------|
| `builder` | Implements tasks from the task board |
| `validator` | Verifies acceptance criteria; creates fix tasks on failure |
| `spec-updater` | Writes build evidence back into the plan spec |
| `design-updater` | Updates design docs after implementation |
| `pr-agent` | Creates GitHub PRs with structured bodies and test evidence |
| `bug-creator` | Investigates bugs and produces JIRA-format reports |
| `bug-router` | Classifies bugs and routes to the correct fixer agent |
| `bug-fixer-api` | Fixes bugs in API/backend modules |
| `bug-fixer-frontend` | Fixes bugs in frontend modules |
| `bug-fixer-database` | Fixes bugs in database/migration modules |
| `bug-reviewer` | Adversarial read-only reviewer; deployed as alpha + beta in parallel |

### Hooks (`~/.claude/hooks/`)

Lifecycle hooks that enforce pipeline safety:

- `enforce_branch_discipline.py` — blocks commits to `main` directly
- `enforce_review_isolation.py` — prevents reviewers from reading each other's verdicts
- `enforce_team_lead.py` — ensures only the team lead runs orchestration commands
- `validate_bug_report.py` — blocks bug-creator stop if report is missing required sections
- `validate_bug_routing.py` — blocks bug-router stop if routing JSON is invalid or low-confidence
- `validate_pr_test_evidence.py` — blocks pr-agent stop if PR body lacks real test output
- `validate_plan_format.py` — enforces task graph structure in plan specs
- `merge_gate.py` — prevents merge without both reviewer verdicts
- `git-safety-guard.py` — blocks force pushes and dangerous git operations
- `audit_team_completion.py` — verifies all tasks completed before team teardown

### Skills (`~/.claude/skills/`)

48 skills covering backend guidelines, frontend guidelines, TDD, systematic debugging, brainstorming, architecture review, performance gating, k8s SRE investigation, and more.

---

## Quick Start

### Feature Development

```bash
# Plan
/plan_to_build "add a dark mode toggle that persists to localStorage"

# Build
/build_v2 specs/<generated-spec>.md
```

### Bug Fixing

```bash
/bug_to_pr "the export button downloads the full unfiltered dataset — active tag filters are ignored"
```

The `/bug_to_pr` pipeline runs 6 phases automatically:

1. **Bug Investigation** — `bug-creator` investigates, reproduces, and writes a JIRA-format report
2. **Routing** — `bug-router` classifies the bug to the correct module fixer
3. **Fix** — the fixer agent plans, implements, and captures test evidence
4. **PR Creation** — `pr-agent` opens a GitHub PR with structured body and test evidence
5. **Adversarial Review** — `reviewer-alpha` and `reviewer-beta` run in parallel, independently
6. **Merge Gate** — prompts you to confirm before merging; rejects loop back for another fix cycle

### Per-Project Setup

The bug pipeline requires one repo-specific file:

```bash
# Create .github/bug-modules.json in your project root
# Maps module names to fixer agents and path patterns
```

See `.github/bug-modules.json` in the `metrics-dashboard` repo for a working example.

---

## Pipeline Architecture

```
/bug_to_pr
  └── Phase 0: Setup (branch, team, state file)
  └── Phase 1a: bug-creator  ──► bugs/BUG-NNN/report.md
  └── Phase 1b: bug-router   ──► bugs/BUG-NNN/routing.json
  └── Phase 2:  bug-fixer-*  ──► code fix + bugs/BUG-NNN/test-results.md
  └── Phase 3:  pr-agent     ──► GitHub PR
  └── Phase 4:  reviewer-alpha  ─┐
                reviewer-beta   ─┴► parallel ──► bugs/BUG-NNN/reviews/
  └── Phase 5:  Merge Gate (user confirmation)
  └── Phase 6:  Shutdown + pane cleanup

/build_v2
  └── Phase 1: Parse plan spec → task graph
  └── Phase 2: Create team + populate task board (TaskCreate)
  └── Phase 3: Deploy builder(s) + validator + spec-updater (background)
  └── Phase 4: Monitor via SendMessage (no polling)
  └── Phase 5: Shutdown + TeamDelete
```

---

## Reliability Features (v2)

- **Pane tracking** — agent tmux panes are tracked in `bugs/BUG-NNN/panes.txt` and killed during shutdown; no idle panes left behind
- **Parallel adversarial review** — both reviewers run simultaneously (`run_in_background: true`); isolation enforced by `enforce_review_isolation.py` hook
- **Pipeline state file** — `bugs/BUG-NNN/pipeline-state.json` written after every phase; supports crash recovery with `resume`
- **Merge requires explicit confirmation** — `AskUserQuestion` gate before any `gh pr merge`; never auto-merges
- **verdict.json on fix branch** — committed before merge (not after), avoiding branch discipline hook conflicts
- **Shutdown timeout** — 60s timeout on agent shutdown responses; pipeline never blocks indefinitely
- **macOS grep compatibility** — uses `grep -o 'BUG-[0-9]*'` (not `-P` flag, which is unsupported on macOS)

---

## Requirements

- Claude Code CLI with `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`
- `tmux` (for agent pane management)
- `gh` CLI authenticated (`gh auth login`)
- `uv` (for Python hook runners)
- Git repo with a remote configured
