# Claude Code Team Setup

## Prerequisites

- [ ] [Claude Code CLI](https://claude.ai/download) installed
- [ ] `uv` installed — `brew install uv` or `curl -LsSf https://astral.sh/uv/install.sh | sh`
- [ ] `tmux` installed — `brew install tmux`

## Install

```bash
tar -xzf claude-team-setup.tar.gz -C ~/
```

> If you already have a `~/.claude` directory, use `--keep-old-files` to avoid overwriting existing config:
> ```bash
> tar -xzf claude-team-setup.tar.gz -C ~/ --keep-old-files
> ```

## First-time setup in any project

- `cd` into your project directory
- Create the specs output folder: `mkdir -p specs`
- Start Claude Code: `claude`

## Key commands

### v1 (original)

- `/plan_to_build <describe what you want to build>` — creates a detailed implementation plan in `specs/`
- `/build specs/<plan-name>.md` — executes the plan using a self-organizing agent team in tmux panes

### v2 (recommended — improved reliability)

- `/plan_to_build_v2 <describe what you want to build>` — same as v1, plus enforces `Assigned To` on every task
- `/build_v2 specs/<plan-name>.md` — executes with four reliability fixes over v1:
  - **Assigned To enforcement** — each builder only claims tasks explicitly assigned to their name
  - **Indefinite polling** — builders never self-terminate; they wait for an explicit shutdown from the leader
  - **Targeted wakeup** — when a validator creates a fix task, the leader immediately wakes the assigned builder
  - **Collision-safe team names** — team is named `<plan>-YYYYMMDD-HHMM`; re-running the same plan never collides
  - **Liveness detection** — leader pings agents silent for 10+ minutes and escalates to the user if no response

## How it works

1. `/plan_to_build_v2` analyzes your codebase and writes an exhaustive plan to `specs/`
2. `/build_v2` reads that plan, creates a timestamped team, and spins up agents in tmux split panes
3. Agents self-organize — each builder claims only tasks assigned to their name, executes, marks done, and loops
4. A validator runs when builder tasks complete; on failure it names the target builder and the leader sends a wakeup
5. Fix cycles repeat up to 2 times; if exceeded the leader escalates to you rather than silently stalling
6. A spec-updater writes build evidence back into the plan file when everything is complete

## tmux pane controls (once agents are running)

- `Ctrl+a |` — split pane vertically
- `Ctrl+a -` — split pane horizontally
- `Ctrl+a` + arrow keys — navigate between panes
- Mouse clicks also work for pane selection and scrolling

## Notes

- Plans are saved to `specs/` in your project root — commit them alongside your code
- Agent teams require an active tmux session — run `tmux` before starting Claude Code
- The `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` env var is pre-configured in `~/.claude/settings.json`
- v1 commands (`/plan_to_build`, `/build`) remain available for backwards compatibility
