# Claude Code Team Setup

## Prerequisites

- [ ] [Claude Code CLI](https://claude.ai/download) installed
- [ ] `uv` installed — `brew install uv` or `curl -LsSf https://astral.sh/uv/install.sh | sh`
- [ ] `tmux` installed — `brew install tmux`

## Install

```bash
tar -xzf claude-team-setup.tar.gz -C ~/
```

> If you already have a `~/.claude` directory, use `--keep-old-files` to avoid overwriting existing config:
> ```bash
> tar -xzf claude-team-setup.tar.gz -C ~/ --keep-old-files
> ```

## First-time setup in any project

- `cd` into your project directory
- Create the specs output folder: `mkdir -p specs`
- Start Claude Code: `claude`

## Key commands

- `/plan_to_build <describe what you want to build>` — creates a detailed implementation plan in `specs/`
- `/build specs/<plan-name>.md` — executes the plan using a self-organizing agent team in tmux panes

## How it works

1. `/plan_to_build` analyzes your codebase and writes an exhaustive plan to `specs/`
2. `/build` reads that plan, spins up a team of agents in tmux split panes, and they work autonomously
3. Agents self-organize — a builder claims tasks, executes them, marks done, and loops
4. A validator runs at the end and creates fix tasks if anything fails (up to 2 fix cycles)
5. A spec-updater writes build evidence back into the plan file when complete

## tmux pane controls (once agents are running)

- `Ctrl+a |` — split pane vertically
- `Ctrl+a -` — split pane horizontally
- `Ctrl+a` + arrow keys — navigate between panes
- Mouse clicks also work for pane selection and scrolling

## Notes

- Plans are saved to `specs/` in your project root — commit them alongside your code
- Agent teams require an active tmux session — run `tmux` before starting Claude Code
- The `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` env var is pre-configured in `~/.claude/settings.json`
